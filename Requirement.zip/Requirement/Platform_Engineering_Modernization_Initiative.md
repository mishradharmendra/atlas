# Platform Engineering Modernization Initiative

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [Current State Assessment](#current-state-assessment)
3. [Requirements Analysis](#requirements-analysis)
4. [Technical Implementation Strategy](#technical-implementation-strategy)
5. [Observability Enhancement](#observability-enhancement)
6. [Code Quality & CI/CD Improvements](#code-quality--cicd-improvements)
7. [Cost Management & Optimization](#cost-management--optimization)
8. [Infrastructure Modernization](#infrastructure-modernization)
9. [Compliance & Security](#compliance--security)
10. [Implementation Roadmap](#implementation-roadmap)
11. [Business Value & ROI](#business-value--roi)
12. [Risk Assessment](#risk-assessment)
13. [Success Metrics](#success-metrics)
14. [Conclusion](#conclusion)

---

## Executive Summary

This document outlines a comprehensive **Platform Engineering Modernization Initiative** designed to enhance observability, improve code quality, optimize costs, strengthen compliance, and modernize the technical infrastructure supporting Nike's assortment management ecosystem including the **av-experience** platform.

### **Strategic Objectives**
- **Operational Excellence:** Implement end-to-end observability and monitoring capabilities
- **Quality Assurance:** Establish robust testing frameworks and coverage standards
- **Cost Optimization:** Implement comprehensive cost tracking and infrastructure standardization
- **Security & Compliance:** Address CIS vulnerability requirements and maintain compliance standards
- **Technical Modernization:** Upgrade infrastructure components and data processing capabilities

### **Key Business Drivers**
- **Risk Mitigation:** Proactive monitoring and alerting to prevent business disruptions
- **Cost Control:** Enhanced visibility and control over cloud infrastructure costs
- **Quality Improvement:** Reduced production issues through comprehensive testing
- **Compliance Adherence:** Meeting security and regulatory requirements
- **Operational Efficiency:** Streamlined infrastructure management and deployment processes

### **Initiative Scope**
This modernization initiative encompasses **13 critical requirements** across **7 categories**:
- 4 Observability enhancements
- 4 Code Quality & CI/CD improvements
- 2 Cost tracking and optimization initiatives
- 1 Terraform infrastructure upgrade
- 1 Compliance and security enhancement
- 1 Data pipeline modernization

---

## Current State Assessment

### **Existing Infrastructure Challenges**

#### **Observability Gaps**
- **Limited End-to-End Visibility:** Lack of comprehensive payload and stage-level tracking
- **Manual Dashboard Management:** Splunk dashboards not integrated with Infrastructure as Code
- **Inconsistent Logging:** Unstructured logs making troubleshooting difficult
- **Reactive Monitoring:** Missing proactive alerts for critical business KPIs

#### **Code Quality & Testing Deficiencies**
- **Insufficient Test Coverage:** Low unit and integration test coverage across components
- **Manual Testing Processes:** Lack of automated testing in CI/CD pipelines
- **Quality Gate Gaps:** Missing quality gates in deployment processes
- **Technical Debt Accumulation:** Untested code leading to production issues

#### **Cost Management Limitations**
- **Poor Cost Visibility:** Inadequate cloud resource tagging for cost attribution
- **Infrastructure Inconsistencies:** Non-standardized configurations leading to cost inefficiencies
- **Resource Waste:** Unoptimized infrastructure configurations
- **Cost Allocation Challenges:** Difficulty attributing costs to specific business units

#### **Infrastructure & Compliance Issues**
- **Legacy Terraform Dependencies:** Dependency on outdated pmp-core modules
- **Security Vulnerabilities:** Outstanding CIS compliance issues
- **Data Pipeline Limitations:** Legacy data processing systems limiting scalability
- **Governance Gaps:** Inconsistent infrastructure standards and policies

### **Business Impact Assessment**

| Impact Area | Current State | Business Risk | Priority |
|-------------|---------------|---------------|----------|
| System Reliability | 95% uptime | Revenue loss during outages | High |
| Mean Time to Recovery | 45 minutes | Extended business disruption | High |
| Cost Visibility | 40% | Budget overruns | Medium |
| Security Compliance | 85% | Regulatory and audit risks | High |
| Development Velocity | Baseline | Slower feature delivery | Medium |
| Data Processing Efficiency | 60% | Delayed business insights | Medium |

---

## Requirements Analysis

### **Categorized Requirements Overview**

#### **1. Observability (4 Requirements)**
| Requirement | Business Value | Technical Complexity | Priority |
|------------|----------------|---------------------|----------|
| End-to-end Payload & Stage Tracking | High | Medium | P0 |
| Splunk Dashboard IaC | Medium | Low | P1 |
| Log Restructuring | High | Medium | P0 |
| Alarms & Notifications for KPIs/KRIs | High | Low | P0 |

#### **2. Code Quality & CI/CD (4 Requirements)**
| Requirement | Business Value | Technical Complexity | Priority |
|------------|----------------|---------------------|----------|
| Unit Testing Implementation | High | Medium | P1 |
| Unit Test Coverage | High | Low | P1 |
| Integration Testing | High | High | P1 |
| Integration Test Coverage | Medium | Low | P2 |

#### **3. Cost Management (2 Requirements)**
| Requirement | Business Value | Technical Complexity | Priority |
|------------|----------------|---------------------|----------|
| Cloud Resource Tagging | High | Low | P1 |
| Infrastructure Standardization | High | Medium | P1 |

#### **4. Infrastructure Modernization (2 Requirements)**
| Requirement | Business Value | Technical Complexity | Priority |
|------------|----------------|---------------------|----------|
| pmp-core Migration | Medium | High | P2 |
| Historical Data Pipeline with Glue | High | High | P1 |

#### **5. Compliance (1 Requirement)**
| Requirement | Business Value | Technical Complexity | Priority |
|------------|----------------|---------------------|----------|
| CIS Vulnerability Fixes | High | Medium | P0 |

---

## Technical Implementation Strategy

### **Architecture Overview**

```mermaid
graph TB
    subgraph "Observability Layer"
        A[End-to-End Tracking] --> B[Structured Logging]
        B --> C[Splunk Dashboards]
        C --> D[Alerts & Notifications]
    end
    
    subgraph "Quality Assurance Layer"
        E[Unit Tests] --> F[Integration Tests]
        F --> G[Coverage Reports]
        G --> H[Quality Gates]
    end
    
    subgraph "Infrastructure Layer"
        I[Terraform Modules] --> J[Standardized Configs]
        J --> K[Resource Tagging]
        K --> L[Cost Management]
    end
    
    subgraph "Data Processing Layer"
        M[Historical Data] --> N[AWS Glue Pipeline]
        N --> O[Data Lake]
        O --> P[Analytics]
    end
    
    subgraph "Security & Compliance"
        Q[CIS Controls] --> R[Vulnerability Scanning]
        R --> S[Compliance Reporting]
    end
```

### **Technology Stack Selection**

#### **Observability Stack**
- **Logging:** Structured JSON logging with correlation IDs
- **Monitoring:** Splunk with Infrastructure as Code (Terraform)
- **Alerting:** AWS CloudWatch + Splunk alerts with PagerDuty integration
- **Tracing:** AWS X-Ray for distributed tracing

#### **Testing & Quality Stack**
- **Unit Testing:** Jest for JavaScript/TypeScript, JUnit for Java
- **Integration Testing:** Postman/Newman, TestContainers
- **Coverage:** Istanbul/nyc for JavaScript, JaCoCo for Java
- **Quality Gates:** SonarQube integration in CI/CD pipelines

#### **Infrastructure & Cost Management**
- **Infrastructure as Code:** Terraform with standardized modules
- **Cost Management:** AWS Cost Explorer, custom tagging strategy
- **Resource Optimization:** AWS Trusted Advisor, custom monitoring

#### **Data Processing**
- **Data Pipeline:** AWS Glue with Apache Spark
- **Data Storage:** Amazon S3 data lake architecture
- **Data Catalog:** AWS Glue Data Catalog
- **Analytics:** Amazon Athena, QuickSight

---

## Observability Enhancement

### **1. End-to-End Payload and Stage Level Tracking**

#### **Implementation Strategy**
```javascript
// Correlation ID Generation and Tracking
class CorrelationTracker {
  constructor() {
    this.generateId = () => `${Date.now()}-${Math.random().toString(36)}`;
  }
  
  // Generate correlation ID for new requests
  initializeTracking(req, res, next) {
    req.correlationId = req.headers['x-correlation-id'] || this.generateId();
    res.setHeader('x-correlation-id', req.correlationId);
    
    // Initialize tracking context
    req.trackingContext = {
      correlationId: req.correlationId,
      timestamp: new Date().toISOString(),
      service: process.env.SERVICE_NAME,
      version: process.env.SERVICE_VERSION,
      stage: 'request_received'
    };
    
    next();
  }
  
  // Track stage progression
  trackStage(req, stage, payload = {}) {
    const trackingData = {
      ...req.trackingContext,
      stage,
      timestamp: new Date().toISOString(),
      payload: JSON.stringify(payload),
      duration: Date.now() - new Date(req.trackingContext.timestamp).getTime()
    };
    
    logger.info('STAGE_TRACKING', trackingData);
    return trackingData;
  }
}

// Usage in AV Product Search
app.use('/api/products/search', (req, res, next) => {
  tracker.trackStage(req, 'search_initiated', {
    searchTerm: req.body.searchTerm,
    filters: req.body.filters
  });
  
  next();
});
```

#### **Payload Tracking Schema**
```json
{
  "correlationId": "1694889600000-abc123",
  "timestamp": "2025-09-16T10:30:00Z",
  "service": "av-product-search",
  "version": "1.2.3",
  "stage": "database_query",
  "duration": 150,
  "payload": {
    "query": "SELECT * FROM products WHERE...",
    "resultCount": 45,
    "executionTime": "145ms"
  },
  "metadata": {
    "userId": "user123",
    "sessionId": "session456",
    "region": "us-west-2"
  }
}
```

### **2. Splunk Dashboard Infrastructure as Code**

#### **Terraform Dashboard Configuration**
```hcl
# Splunk Dashboard as Code
resource "splunk_saved_searches" "av_performance_metrics" {
  name         = "AV Performance Metrics"
  search       = <<-EOT
    index=av-experience sourcetype="application_logs" 
    | stats avg(response_time) as avg_response, 
            count as total_requests, 
            count(eval(status_code >= 400)) as error_count 
    by service, _time 
    | eval error_rate = round((error_count/total_requests)*100, 2)
  EOT
  dispatch_earliest_time = "-15m"
  dispatch_latest_time   = "now"
  cron_schedule         = "*/5 * * * *"
}

resource "splunk_dashboard" "av_operational_dashboard" {
  name = "AV Operational Dashboard"
  
  dashboard_xml = templatefile("${path.module}/dashboards/av_operations.xml", {
    search_name = splunk_saved_searches.av_performance_metrics.name
  })
  
  tags = {
    Environment = var.environment
    Service     = "av-experience"
    Owner       = "platform-engineering"
  }
}

# Dashboard Panel Configuration
resource "splunk_dashboard_panel" "response_time_trend" {
  dashboard_id = splunk_dashboard.av_operational_dashboard.id
  
  panel_config = {
    title = "Response Time Trend"
    type  = "line_chart"
    search = "| savedsearch \"${splunk_saved_searches.av_performance_metrics.name}\""
    refresh_interval = "5m"
  }
}
```

### **3. Log Restructuring Strategy**

#### **Structured Logging Implementation**
```javascript
// Enhanced Logging Framework
const winston = require('winston');

class StructuredLogger {
  constructor(service) {
    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          return JSON.stringify({
            timestamp,
            level: level.toUpperCase(),
            service,
            message,
            correlationId: meta.correlationId,
            userId: meta.userId,
            sessionId: meta.sessionId,
            ...meta
          });
        })
      ),
      transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'application.log' })
      ]
    });
  }
  
  // Business Event Logging
  logBusinessEvent(eventType, eventData, context = {}) {
    this.logger.info({
      eventType,
      category: 'BUSINESS_EVENT',
      data: eventData,
      ...context
    });
  }
  
  // Performance Logging
  logPerformance(operation, duration, metadata = {}) {
    this.logger.info({
      operation,
      category: 'PERFORMANCE',
      duration,
      unit: 'ms',
      ...metadata
    });
  }
  
  // Error Logging with Context
  logError(error, context = {}) {
    this.logger.error({
      category: 'ERROR',
      message: error.message,
      stack: error.stack,
      ...context
    });
  }
}

// Usage Examples
const logger = new StructuredLogger('av-product-search');

// Business event logging
logger.logBusinessEvent('PRODUCT_SEARCH', {
  searchTerm: 'running shoes',
  resultCount: 156,
  filters: ['size:10', 'color:blue']
}, { correlationId: req.correlationId, userId: req.user.id });

// Performance logging
logger.logPerformance('DATABASE_QUERY', 145, {
  query: 'product_search',
  resultCount: 156,
  correlationId: req.correlationId
});
```

### **4. KPI/KRI Alarms and Notifications**

#### **CloudWatch Alarms Configuration**
```hcl
# Critical Business KPIs
resource "aws_cloudwatch_metric_alarm" "av_search_response_time" {
  alarm_name          = "av-search-response-time-high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "ResponseTime"
  namespace           = "AV/ProductSearch"
  period             = "300"
  statistic          = "Average"
  threshold          = "3000"  # 3 seconds
  alarm_description  = "AV Product Search response time is too high"
  alarm_actions      = [aws_sns_topic.alerts.arn]
  
  dimensions = {
    Service = "av-product-search"
  }
  
  tags = {
    Severity = "High"
    Category = "Performance"
  }
}

resource "aws_cloudwatch_metric_alarm" "av_error_rate" {
  alarm_name          = "av-search-error-rate-high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "3"
  metric_name         = "ErrorRate"
  namespace           = "AV/ProductSearch"
  period             = "300"
  statistic          = "Average"
  threshold          = "5"  # 5% error rate
  alarm_description  = "AV Product Search error rate is too high"
  alarm_actions      = [aws_sns_topic.critical_alerts.arn]
}

# Business KRI Monitoring
resource "aws_cloudwatch_metric_alarm" "concurrent_users_limit" {
  alarm_name          = "av-concurrent-users-approaching-limit"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "1"
  metric_name         = "ConcurrentUsers"
  namespace           = "AV/Usage"
  period             = "60"
  statistic          = "Maximum"
  threshold          = "80"  # 80% of capacity
  alarm_description  = "AV concurrent users approaching system limit"
  alarm_actions      = [aws_sns_topic.capacity_alerts.arn]
}
```

#### **Notification Integration**
```javascript
// SNS Integration for Alerts
const AWS = require('aws-sdk');
const sns = new AWS.SNS();

class AlertManager {
  constructor() {
    this.topicArn = process.env.ALERT_TOPIC_ARN;
  }
  
  async sendBusinessAlert(alertType, severity, message, metadata = {}) {
    const alertPayload = {
      alertType,
      severity,
      message,
      timestamp: new Date().toISOString(),
      service: 'av-experience',
      metadata,
      runbook: this.getRunbookUrl(alertType)
    };
    
    const params = {
      TopicArn: this.topicArn,
      Subject: `[${severity}] AV Platform Alert: ${alertType}`,
      Message: JSON.stringify(alertPayload, null, 2),
      MessageAttributes: {
        severity: {
          DataType: 'String',
          StringValue: severity
        },
        alertType: {
          DataType: 'String',
          StringValue: alertType
        }
      }
    };
    
    return sns.publish(params).promise();
  }
  
  getRunbookUrl(alertType) {
    const runbooks = {
      'HIGH_RESPONSE_TIME': 'https://wiki.nike.com/runbooks/av-performance',
      'HIGH_ERROR_RATE': 'https://wiki.nike.com/runbooks/av-errors',
      'CAPACITY_WARNING': 'https://wiki.nike.com/runbooks/av-scaling'
    };
    
    return runbooks[alertType] || 'https://wiki.nike.com/runbooks/general';
  }
}
```

---

## Code Quality & CI/CD Improvements

### **1. Unit Testing Implementation**

#### **Testing Framework Setup**
```javascript
// Jest Configuration for AV Components
module.exports = {
  testEnvironment: 'node',
  collectCoverageFrom: [
    'src/**/*.{js,ts}',
    '!src/**/*.d.ts',
    '!src/index.js',
    '!src/**/__tests__/**',
    '!src/**/__mocks__/**'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  setupFilesAfterEnv: ['<rootDir>/src/setupTests.js'],
  testMatch: [
    '<rootDir>/src/**/__tests__/**/*.{js,ts}',
    '<rootDir>/src/**/*.{test,spec}.{js,ts}'
  ]
};

// Unit Test Example for Product Search Service
describe('ProductSearchService', () => {
  let searchService;
  let mockRepository;
  let mockTaggingService;
  
  beforeEach(() => {
    mockRepository = {
      searchProducts: jest.fn(),
      getProductById: jest.fn()
    };
    mockTaggingService = {
      getProductTags: jest.fn()
    };
    
    searchService = new ProductSearchService(mockRepository, mockTaggingService);
  });
  
  describe('searchProducts', () => {
    test('should return paginated results with correlation tracking', async () => {
      // Arrange
      const searchQuery = {
        term: 'running shoes',
        filters: { category: 'footwear' }
      };
      const mockProducts = [
        { id: 1, name: 'Nike Air Max', category: 'footwear' },
        { id: 2, name: 'Nike React', category: 'footwear' }
      ];
      const correlationId = 'test-correlation-123';
      
      mockRepository.searchProducts.mockResolvedValue({
        products: mockProducts,
        totalCount: 156
      });
      
      mockTaggingService.getProductTags.mockResolvedValue({
        1: ['performance', 'casual'],
        2: ['performance', 'running']
      });
      
      // Act
      const result = await searchService.searchProducts(searchQuery, 1, 20, correlationId);
      
      // Assert
      expect(result.products).toHaveLength(2);
      expect(result.pagination.totalCount).toBe(156);
      expect(result.products[0].tags).toContain('performance');
      expect(mockRepository.searchProducts).toHaveBeenCalledWith(
        searchQuery, 0, 20, correlationId
      );
    });
    
    test('should handle tagging service failures gracefully', async () => {
      // Arrange
      mockRepository.searchProducts.mockResolvedValue({
        products: [{ id: 1, name: 'Test Product' }],
        totalCount: 1
      });
      mockTaggingService.getProductTags.mockRejectedValue(new Error('Service unavailable'));
      
      // Act
      const result = await searchService.searchProducts({}, 1, 20, 'test-id');
      
      // Assert
      expect(result.products).toHaveLength(1);
      expect(result.products[0].tags).toEqual([]);
      // Should log error but not fail the search
    });
  });
});
```

### **2. Integration Testing Framework**

#### **API Integration Tests**
```javascript
// Integration Test Setup with TestContainers
const { GenericContainer } = require('testcontainers');
const request = require('supertest');
const app = require('../src/app');

describe('AV Product Search API Integration Tests', () => {
  let container;
  let database;
  
  beforeAll(async () => {
    // Start test database container
    container = await new GenericContainer('postgres:13')
      .withExposedPorts(5432)
      .withEnvironment({
        POSTGRES_DB: 'av_test',
        POSTGRES_USER: 'test',
        POSTGRES_PASSWORD: 'test'
      })
      .start();
    
    // Initialize test database
    database = new Database({
      host: container.getHost(),
      port: container.getMappedPort(5432),
      database: 'av_test',
      username: 'test',
      password: 'test'
    });
    
    await database.initialize();
    await database.seedTestData();
  }, 60000);
  
  afterAll(async () => {
    await database.close();
    await container.stop();
  });
  
  describe('POST /api/products/search', () => {
    test('should return search results with proper pagination', async () => {
      const searchPayload = {
        searchTerm: 'running',
        filters: {
          category: 'footwear',
          size: ['10', '11']
        },
        page: 1,
        limit: 20
      };
      
      const response = await request(app)
        .post('/api/products/search')
        .send(searchPayload)
        .set('Accept', 'application/json')
        .set('x-correlation-id', 'integration-test-123')
        .expect(200);
      
      expect(response.body).toMatchObject({
        products: expect.any(Array),
        pagination: {
          currentPage: 1,
          totalPages: expect.any(Number),
          totalCount: expect.any(Number),
          hasNext: expect.any(Boolean),
          hasPrev: false
        },
        metadata: {
          searchTerm: 'running',
          responseTime: expect.any(Number),
          correlationId: 'integration-test-123'
        }
      });
      
      expect(response.body.products.length).toBeLessThanOrEqual(20);
    });
    
    test('should handle high concurrent load', async () => {
      const concurrentRequests = 50;
      const promises = [];
      
      for (let i = 0; i < concurrentRequests; i++) {
        promises.push(
          request(app)
            .post('/api/products/search')
            .send({ searchTerm: 'test', page: 1, limit: 10 })
            .set('x-correlation-id', `load-test-${i}`)
        );
      }
      
      const responses = await Promise.all(promises);
      
      // All requests should succeed
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body.products).toBeDefined();
      });
      
      // Response times should be reasonable
      const responseTimes = responses.map(r => r.body.metadata.responseTime);
      const averageResponseTime = responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length;
      expect(averageResponseTime).toBeLessThan(2000); // 2 seconds average
    });
  });
});
```

### **3. Coverage Reporting and Quality Gates**

#### **CI/CD Pipeline with Coverage**
```yaml
# .github/workflows/quality-gates.yml
name: Code Quality Gates

on:
  pull_request:
    branches: [main, develop]
  push:
    branches: [main]

jobs:
  test-and-coverage:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: test
          POSTGRES_DB: av_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run unit tests with coverage
      run: npm run test:coverage
      env:
        DATABASE_URL: postgres://postgres:test@localhost:5432/av_test
    
    - name: Run integration tests
      run: npm run test:integration
      env:
        DATABASE_URL: postgres://postgres:test@localhost:5432/av_test
    
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage/lcov.info
        flags: unittests
        name: av-experience-coverage
    
    - name: SonarQube Quality Gate
      uses: sonarqube-quality-gate-action@master
      env:
        SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
    
    - name: Comment PR with coverage
      uses: marocchino/sticky-pull-request-comment@v2
      if: github.event_name == 'pull_request'
      with:
        recreate: true
        path: coverage/coverage-summary.md

  quality-gates:
    needs: test-and-coverage
    runs-on: ubuntu-latest
    
    steps:
    - name: Check quality thresholds
      run: |
        echo "Checking quality gates..."
        if [ ${{ needs.test-and-coverage.outputs.coverage }} -lt 80 ]; then
          echo "Coverage below 80% threshold"
          exit 1
        fi
        if [ ${{ needs.test-and-coverage.outputs.test-failures }} -gt 0 ]; then
          echo "Test failures detected"
          exit 1
        fi
        echo "All quality gates passed!"
```

---

## Cost Management & Optimization

### **1. Comprehensive Cloud Resource Tagging Strategy**

#### **Standardized Tagging Framework**
```hcl
# Terraform Tagging Module
variable "common_tags" {
  description = "Common tags applied to all resources"
  type = map(string)
  default = {
    Project         = "av-experience"
    Owner          = "platform-engineering"
    Environment    = "production"
    CostCenter     = "nike-digital"
    BusinessUnit   = "assortment-management"
    Application    = "av-product-search"
    ManagedBy      = "terraform"
    BackupPolicy   = "daily"
    MonitoringTier = "standard"
    Compliance     = "sox-compliant"
  }
}

# Enhanced Resource Tagging
resource "aws_instance" "av_application_server" {
  ami           = var.ami_id
  instance_type = var.instance_type
  
  tags = merge(var.common_tags, {
    Name           = "av-app-server-${var.environment}"
    InstanceRole   = "application-server"
    AutoScaling    = "enabled"
    PatchGroup     = "prod-apps"
    DataClass      = "internal"
    Schedule       = "business-hours"
  })
  
  # Cost allocation tags
  volume_tags = merge(var.common_tags, {
    VolumeType = "application-data"
    BackupTier = "standard"
  })
}

# RDS Tagging with Cost Allocation
resource "aws_db_instance" "av_database" {
  identifier = "av-production-db"
  
  tags = merge(var.common_tags, {
    DatabaseEngine = "postgres"
    DataRetention  = "7-years"
    HighAvailability = "multi-az"
    PerformanceTier = "high"
    BackupWindow   = "03:00-04:00"
    MaintenanceWindow = "sun:04:00-sun:05:00"
  })
}

# Cost Management Lambda for Tag Enforcement
resource "aws_lambda_function" "tag_compliance_checker" {
  filename         = "tag-compliance.zip"
  function_name    = "av-tag-compliance-checker"
  role            = aws_iam_role.lambda_role.arn
  handler         = "index.handler"
  runtime         = "python3.9"
  
  tags = merge(var.common_tags, {
    Function = "cost-compliance"
    Schedule = "daily"
  })
  
  environment {
    variables = {
      REQUIRED_TAGS = "Project,Owner,Environment,CostCenter,BusinessUnit"
      SNS_TOPIC_ARN = aws_sns_topic.compliance_alerts.arn
    }
  }
}
```

#### **Cost Allocation and Reporting**
```python
# Tag Compliance and Cost Reporting Lambda
import boto3
import json
from datetime import datetime, timedelta

def lambda_handler(event, context):
    """
    Check resource tag compliance and generate cost reports
    """
    ec2 = boto3.client('ec2')
    ce = boto3.client('ce')
    sns = boto3.client('sns')
    
    required_tags = ['Project', 'Owner', 'Environment', 'CostCenter', 'BusinessUnit']
    
    # Check tag compliance
    non_compliant_resources = check_tag_compliance(ec2, required_tags)
    
    # Generate cost report
    cost_report = generate_cost_report(ce)
    
    # Send alerts if needed
    if non_compliant_resources:
        send_compliance_alert(sns, non_compliant_resources)
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'non_compliant_count': len(non_compliant_resources),
            'cost_summary': cost_report
        })
    }

def check_tag_compliance(ec2_client, required_tags):
    """Check if resources have required tags"""
    non_compliant = []
    
    # Check EC2 instances
    instances = ec2_client.describe_instances()
    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            instance_tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
            missing_tags = [tag for tag in required_tags if tag not in instance_tags]
            
            if missing_tags:
                non_compliant.append({
                    'ResourceId': instance['InstanceId'],
                    'ResourceType': 'EC2Instance',
                    'MissingTags': missing_tags,
                    'CurrentTags': instance_tags
                })
    
    return non_compliant

def generate_cost_report(ce_client):
    """Generate cost report by tags"""
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=30)
    
    response = ce_client.get_cost_and_usage(
        TimePeriod={
            'Start': start_date.strftime('%Y-%m-%d'),
            'End': end_date.strftime('%Y-%m-%d')
        },
        Granularity='MONTHLY',
        Metrics=['BlendedCost'],
        GroupBy=[
            {'Type': 'TAG', 'Key': 'Project'},
            {'Type': 'TAG', 'Key': 'Environment'},
            {'Type': 'TAG', 'Key': 'BusinessUnit'}
        ]
    )
    
    return {
        'period': f"{start_date} to {end_date}",
        'total_cost': sum(float(group['Metrics']['BlendedCost']['Amount']) 
                         for result in response['ResultsByTime'] 
                         for group in result['Groups']),
        'cost_by_project': response['ResultsByTime']
    }
```

### **2. Infrastructure Standardization**

#### **Standardized Terraform Modules**
```hcl
# modules/standardized-ecs/main.tf
variable "application_name" {
  description = "Name of the application"
  type        = string
}

variable "environment" {
  description = "Environment (dev, staging, prod)"
  type        = string
}

variable "cpu_units" {
  description = "CPU units for the task"
  type        = number
  default     = 1024
}

variable "memory_mb" {
  description = "Memory in MB"
  type        = number
  default     = 2048
}

# Standardized ECS Task Definition
resource "aws_ecs_task_definition" "app" {
  family                   = "${var.application_name}-${var.environment}"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.cpu_units
  memory                   = var.memory_mb
  execution_role_arn       = aws_iam_role.execution_role.arn
  task_role_arn           = aws_iam_role.task_role.arn
  
  container_definitions = jsonencode([{
    name  = var.application_name
    image = "${var.ecr_repository_url}:${var.image_tag}"
    
    # Standardized logging configuration
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.app.name
        awslogs-region        = data.aws_region.current.name
        awslogs-stream-prefix = "ecs"
      }
    }
    
    # Standardized health check
    healthCheck = {
      command     = ["CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 60
    }
    
    # Standardized environment variables
    environment = [
      {
        name  = "NODE_ENV"
        value = var.environment
      },
      {
        name  = "LOG_LEVEL"
        value = var.environment == "prod" ? "info" : "debug"
      },
      {
        name  = "SERVICE_NAME"
        value = var.application_name
      }
    ]
    
    portMappings = [{
      containerPort = 8080
      protocol      = "tcp"
    }]
  }])
  
  tags = merge(local.common_tags, {
    Component = "ecs-task"
    Standard  = "nike-ecs-v2"
  })
}

# Standardized Auto Scaling
resource "aws_appautoscaling_target" "ecs_target" {
  max_capacity       = var.max_capacity
  min_capacity       = var.min_capacity
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.app.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "cpu_scaling" {
  name               = "${var.application_name}-cpu-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs_target.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs_target.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs_target.service_namespace
  
  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value = 70.0
    scale_in_cooldown  = 300
    scale_out_cooldown = 300
  }
}

# Cost optimization - Spot instances for non-prod
resource "aws_ecs_capacity_provider" "spot" {
  count = var.environment != "prod" ? 1 : 0
  name  = "${var.application_name}-spot"
  
  auto_scaling_group_provider {
    auto_scaling_group_arn = aws_autoscaling_group.spot[0].arn
    
    managed_scaling {
      maximum_scaling_step_size = 10
      minimum_scaling_step_size = 1
      status                    = "ENABLED"
      target_capacity          = 100
    }
    
    managed_termination_protection = "DISABLED"
  }
}
```

---

## Infrastructure Modernization

### **1. pmp-core Migration Strategy**

#### **Legacy Dependency Assessment**
```hcl
# Current pmp-core Dependencies (Legacy)
module "legacy_vpc" {
  source = "git::https://github.com/nike/pmp-core//modules/vpc?ref=v1.2.0"
  # Outdated, security vulnerabilities, no longer maintained
}

module "legacy_security_groups" {
  source = "git::https://github.com/nike/pmp-core//modules/security?ref=v1.2.0"
  # Non-compliant with current security standards
}

# Migration to Standardized Modules
module "standardized_vpc" {
  source = "./modules/vpc-standard"
  
  cidr_block           = "10.0.0.0/16"
  availability_zones   = ["us-west-2a", "us-west-2b", "us-west-2c"]
  enable_nat_gateway   = true
  enable_vpn_gateway   = false
  enable_dns_hostnames = true
  enable_dns_support   = true
  
  # Enhanced tagging
  tags = merge(local.common_tags, {
    Module  = "vpc-standard-v2"
    Network = "production"
  })
}

module "security_groups_standard" {
  source = "./modules/security-groups-standard"
  
  vpc_id = module.standardized_vpc.vpc_id
  
  # CIS-compliant security group rules
  application_ports = [8080, 8443]
  database_ports    = [5432]
  
  # Restrict SSH access
  ssh_cidr_blocks = ["10.0.0.0/16"]
  
  tags = merge(local.common_tags, {
    SecurityStandard = "cis-compliant"
    Module          = "security-groups-v2"
  })
}
```

#### **Migration Automation Script**
```python
#!/usr/bin/env python3
"""
pmp-core to standardized modules migration script
"""

import subprocess
import json
import sys
from pathlib import Path

class TerraformMigration:
    def __init__(self, terraform_dir):
        self.terraform_dir = Path(terraform_dir)
        self.state_backup_dir = self.terraform_dir / "migration-backups"
        
    def backup_current_state(self):
        """Backup current Terraform state"""
        print("Backing up current Terraform state...")
        self.state_backup_dir.mkdir(exist_ok=True)
        
        subprocess.run([
            "terraform", "state", "pull"
        ], cwd=self.terraform_dir, 
           stdout=open(self.state_backup_dir / "terraform.tfstate.backup", "w"))
        
    def identify_pmp_core_resources(self):
        """Identify resources using pmp-core modules"""
        result = subprocess.run([
            "terraform", "state", "list"
        ], cwd=self.terraform_dir, capture_output=True, text=True)
        
        pmp_core_resources = []
        for resource in result.stdout.strip().split('\n'):
            if 'pmp_core' in resource or 'pmp-core' in resource:
                pmp_core_resources.append(resource)
        
        return pmp_core_resources
    
    def migrate_resource(self, old_resource, new_resource):
        """Migrate a resource to new module"""
        print(f"Migrating {old_resource} to {new_resource}")
        
        # Move resource in state
        subprocess.run([
            "terraform", "state", "mv", old_resource, new_resource
        ], cwd=self.terraform_dir)
        
    def validate_migration(self):
        """Validate migration was successful"""
        print("Validating migration...")
        
        result = subprocess.run([
            "terraform", "plan", "-detailed-exitcode"
        ], cwd=self.terraform_dir, capture_output=True)
        
        if result.returncode == 0:
            print("✅ Migration successful - no changes required")
            return True
        elif result.returncode == 2:
            print("⚠️  Migration incomplete - changes still required")
            print(result.stdout.decode())
            return False
        else:
            print("❌ Migration validation failed")
            print(result.stderr.decode())
            return False
    
    def run_migration(self):
        """Execute full migration process"""
        print("Starting pmp-core migration...")
        
        # Step 1: Backup
        self.backup_current_state()
        
        # Step 2: Identify resources
        pmp_resources = self.identify_pmp_core_resources()
        print(f"Found {len(pmp_resources)} pmp-core resources to migrate")
        
        # Step 3: Plan migration
        migration_map = self.plan_resource_migration(pmp_resources)
        
        # Step 4: Execute migration
        for old, new in migration_map.items():
            self.migrate_resource(old, new)
        
        # Step 5: Validate
        if self.validate_migration():
            print("🎉 Migration completed successfully!")
        else:
            print("💥 Migration needs manual intervention")
            sys.exit(1)

if __name__ == "__main__":
    migration = TerraformMigration("./terraform")
    migration.run_migration()
```

### **2. Historical Data Pipeline with AWS Glue**

#### **Data Pipeline Architecture**
```python
# AWS Glue Job for Historical Data Processing
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime, timedelta

# Initialize Glue context
args = getResolvedOptions(sys.argv, [
    'JOB_NAME',
    'source_database',
    'target_s3_path',
    'partition_date'
])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

class HistoricalDataProcessor:
    def __init__(self, glue_context):
        self.glue_context = glue_context
        self.spark = glue_context.spark_session
        
    def extract_product_data(self, database_name, table_name, partition_date):
        """Extract historical product data"""
        print(f"Extracting data from {database_name}.{table_name} for {partition_date}")
        
        # Create dynamic frame from catalog
        product_data = self.glue_context.create_dynamic_frame.from_catalog(
            database=database_name,
            table_name=table_name,
            additional_options={
                "compressionType": "gzip",
                "optimizePerformance": "true"
            }
        )
        
        # Convert to Spark DataFrame for complex transformations
        df = product_data.toDF()
        
        # Filter by partition date if specified
        if partition_date:
            df = df.filter(F.col("created_date") == partition_date)
        
        return df
    
    def transform_assortment_data(self, df):
        """Transform assortment data for analytics"""
        print("Applying data transformations...")
        
        # Add derived columns
        transformed_df = df \
            .withColumn("processing_timestamp", F.current_timestamp()) \
            .withColumn("season_year", F.year(F.col("season_start_date"))) \
            .withColumn("days_in_season", 
                       F.datediff(F.col("season_end_date"), F.col("season_start_date"))) \
            .withColumn("product_category_group", 
                       F.when(F.col("category").isin(["footwear", "shoes"]), "footwear")
                        .when(F.col("category").isin(["apparel", "clothing"]), "apparel")
                        .otherwise("accessories"))
        
        # Clean and standardize data
        cleaned_df = transformed_df \
            .filter(F.col("product_id").isNotNull()) \
            .filter(F.col("season_start_date").isNotNull()) \
            .withColumn("product_name", F.trim(F.col("product_name"))) \
            .withColumn("sku", F.upper(F.trim(F.col("sku"))))
        
        # Add data quality metrics
        quality_df = cleaned_df \
            .withColumn("data_completeness_score",
                       (F.when(F.col("product_name").isNotNull(), 1).otherwise(0) +
                        F.when(F.col("category").isNotNull(), 1).otherwise(0) +
                        F.when(F.col("price").isNotNull(), 1).otherwise(0)) / 3)
        
        return quality_df
    
    def load_to_data_lake(self, df, target_path, partition_columns=None):
        """Load transformed data to S3 data lake"""
        print(f"Loading data to {target_path}")
        
        # Optimize for analytics - use Parquet with compression
        writer = df.write \
            .mode("overwrite") \
            .option("compression", "snappy") \
            .option("maxRecordsPerFile", 1000000)
        
        if partition_columns:
            writer = writer.partitionBy(*partition_columns)
        
        writer.parquet(target_path)
        
    def create_data_catalog_table(self, database_name, table_name, s3_location):
        """Create or update Glue Data Catalog table"""
        print(f"Creating catalog table {database_name}.{table_name}")
        
        # Define table schema
        table_schema = [
            {"Name": "product_id", "Type": "string"},
            {"Name": "product_name", "Type": "string"},
            {"Name": "sku", "Type": "string"},
            {"Name": "category", "Type": "string"},
            {"Name": "price", "Type": "decimal(10,2)"},
            {"Name": "season_start_date", "Type": "date"},
            {"Name": "season_end_date", "Type": "date"},
            {"Name": "processing_timestamp", "Type": "timestamp"},
            {"Name": "season_year", "Type": "int"},
            {"Name": "days_in_season", "Type": "int"},
            {"Name": "product_category_group", "Type": "string"},
            {"Name": "data_completeness_score", "Type": "decimal(3,2)"}
        ]
        
        # Create table using Glue API
        table_input = {
            'Name': table_name,
            'StorageDescriptor': {
                'Columns': [{"Name": col["Name"], "Type": col["Type"]} 
                           for col in table_schema],
                'Location': s3_location,
                'InputFormat': 'org.apache.hadoop.mapred.TextInputFormat',
                'OutputFormat': 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat',
                'SerdeInfo': {
                    'SerializationLibrary': 'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
                }
            },
            'PartitionKeys': [
                {"Name": "year", "Type": "string"},
                {"Name": "month", "Type": "string"},
                {"Name": "day", "Type": "string"}
            ]
        }
        
        # Note: In actual implementation, use Glue API to create table
        print("Table schema defined - would create via Glue API in production")

# Main processing logic
def main():
    processor = HistoricalDataProcessor(glueContext)
    
    # Extract historical data
    product_df = processor.extract_product_data(
        args['source_database'], 
        'products', 
        args.get('partition_date')
    )
    
    assortment_df = processor.extract_product_data(
        args['source_database'], 
        'assortments', 
        args.get('partition_date')
    )
    
    # Join and transform data
    joined_df = product_df.alias("p") \
        .join(assortment_df.alias("a"), 
              F.col("p.product_id") == F.col("a.product_id"), 
              "left_outer")
    
    transformed_df = processor.transform_assortment_data(joined_df)
    
    # Load to data lake with partitioning
    processor.load_to_data_lake(
        transformed_df,
        args['target_s3_path'],
        partition_columns=["season_year", "product_category_group"]
    )
    
    # Update data catalog
    processor.create_data_catalog_table(
        "av_analytics", 
        "historical_product_assortments",
        args['target_s3_path']
    )
    
    print("Historical data processing completed successfully!")

if __name__ == "__main__":
    main()
    job.commit()
```

#### **Glue Job Infrastructure**
```hcl
# AWS Glue Resources for Historical Data Pipeline
resource "aws_glue_catalog_database" "av_analytics" {
  name        = "av_analytics"
  description = "AV Historical Data Analytics Database"
  
  create_table_default_permission {
    permissions = ["SELECT"]
    
    principal {
      data_lake_principal_identifier = "IAM_ALLOWED_PRINCIPALS"
    }
  }
}

resource "aws_glue_job" "historical_data_processor" {
  name     = "av-historical-data-processor"
  role_arn = aws_iam_role.glue_job_role.arn
  
  glue_version      = "4.0"
  max_retries       = 1
  timeout           = 2880  # 48 hours
  worker_type       = "G.2X"
  number_of_workers = 10
  
  command {
    script_location = "s3://${aws_s3_bucket.glue_scripts.bucket}/historical-data-processor.py"
    python_version  = "3"
  }
  
  default_arguments = {
    "--job-language"                     = "python"
    "--job-bookmark-option"              = "job-bookmark-enable"
    "--enable-metrics"                   = "true"
    "--enable-continuous-cloudwatch-log" = "true"
    "--enable-spark-ui"                  = "true"
    "--spark-event-logs-path"            = "s3://${aws_s3_bucket.glue_logs.bucket}/spark-logs/"
    
    # Custom arguments
    "--source_database"  = aws_glue_catalog_database.source.name
    "--target_s3_path"   = "s3://${aws_s3_bucket.data_lake.bucket}/historical-data/"
    "--partition_date"   = ""
  }
  
  execution_property {
    max_concurrent_runs = 2
  }
  
  tags = merge(local.common_tags, {
    Component = "data-processing"
    DataType  = "historical"
  })
}

# Glue Trigger for Scheduled Execution
resource "aws_glue_trigger" "historical_data_schedule" {
  name     = "av-historical-data-daily"
  type     = "SCHEDULED"
  schedule = "cron(0 2 * * ? *)"  # Daily at 2 AM
  
  actions {
    job_name = aws_glue_job.historical_data_processor.name
    
    arguments = {
      "--partition_date" = "$${format(subtract(now(), duration(\"24h\")), \"2006-01-02\")}"
    }
  }
  
  tags = local.common_tags
}
```

---

## Compliance & Security

### **CIS Vulnerability Fixes Implementation**

#### **CIS Controls Assessment**
```python
# CIS Compliance Checker Script
import boto3
import json
from datetime import datetime

class CISComplianceChecker:
    def __init__(self):
        self.ec2 = boto3.client('ec2')
        self.iam = boto3.client('iam')
        self.s3 = boto3.client('s3')
        self.cloudtrail = boto3.client('cloudtrail')
        
    def check_cis_controls(self):
        """Check major CIS controls compliance"""
        results = {
            'timestamp': datetime.utcnow().isoformat(),
            'controls': {}
        }
        
        # CIS 2.1 - Ensure CloudTrail is enabled
        results['controls']['2.1'] = self.check_cloudtrail_enabled()
        
        # CIS 2.2 - Ensure CloudTrail log file validation is enabled
        results['controls']['2.2'] = self.check_cloudtrail_validation()
        
        # CIS 2.3 - Ensure S3 bucket access logging is enabled
        results['controls']['2.3'] = self.check_s3_access_logging()
        
        # CIS 4.1 - Ensure no security groups allow 0.0.0.0/0 on port 22
        results['controls']['4.1'] = self.check_ssh_restrictions()
        
        # CIS 4.2 - Ensure no security groups allow 0.0.0.0/0 on port 3389
        results['controls']['4.2'] = self.check_rdp_restrictions()
        
        return results
    
    def check_cloudtrail_enabled(self):
        """CIS 2.1 - CloudTrail enabled in all regions"""
        try:
            trails = self.cloudtrail.describe_trails()['trailList']
            
            compliant_trails = []
            for trail in trails:
                if trail.get('IsMultiRegionTrail', False):
                    compliant_trails.append(trail['Name'])
            
            return {
                'compliant': len(compliant_trails) > 0,
                'details': {
                    'multi_region_trails': compliant_trails,
                    'total_trails': len(trails)
                },
                'remediation': 'Enable multi-region CloudTrail' if len(compliant_trails) == 0 else None
            }
        except Exception as e:
            return {'compliant': False, 'error': str(e)}
    
    def check_ssh_restrictions(self):
        """CIS 4.1 - No unrestricted SSH access"""
        try:
            security_groups = self.ec2.describe_security_groups()['SecurityGroups']
            violations = []
            
            for sg in security_groups:
                for rule in sg.get('IpPermissions', []):
                    if rule.get('FromPort') == 22 or rule.get('ToPort') == 22:
                        for ip_range in rule.get('IpRanges', []):
                            if ip_range.get('CidrIp') == '0.0.0.0/0':
                                violations.append({
                                    'security_group_id': sg['GroupId'],
                                    'group_name': sg['GroupName'],
                                    'rule': rule
                                })
            
            return {
                'compliant': len(violations) == 0,
                'details': {
                    'violations': violations,
                    'violation_count': len(violations)
                },
                'remediation': 'Restrict SSH access to specific IP ranges' if violations else None
            }
        except Exception as e:
            return {'compliant': False, 'error': str(e)}
    
    def generate_remediation_plan(self, compliance_results):
        """Generate automated remediation plan"""
        remediation_actions = []
        
        for control_id, result in compliance_results['controls'].items():
            if not result.get('compliant', True) and result.get('remediation'):
                remediation_actions.append({
                    'control': control_id,
                    'action': result['remediation'],
                    'priority': self.get_priority(control_id),
                    'automation': self.get_automation_script(control_id)
                })
        
        return remediation_actions
    
    def get_priority(self, control_id):
        """Get priority level for CIS control"""
        high_priority = ['4.1', '4.2', '2.1']
        return 'HIGH' if control_id in high_priority else 'MEDIUM'
    
    def get_automation_script(self, control_id):
        """Get automation script for remediation"""
        scripts = {
            '4.1': 'terraform/security/restrict-ssh-access.tf',
            '4.2': 'terraform/security/restrict-rdp-access.tf',
            '2.1': 'terraform/logging/enable-cloudtrail.tf'
        }
        return scripts.get(control_id, 'manual-remediation-required')
```

#### **Automated Security Hardening**
```hcl
# CIS-Compliant Security Group Rules
resource "aws_security_group" "av_application_sg" {
  name_prefix = "av-app-sg-"
  description = "CIS-compliant security group for AV application"
  vpc_id      = module.vpc.vpc_id
  
  # CIS 4.1 & 4.2 - Restrict administrative access
  ingress {
    description = "HTTP from Load Balancer"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    security_groups = [aws_security_group.alb_sg.id]
  }
  
  ingress {
    description = "HTTPS from Load Balancer"
    from_port   = 8443
    to_port     = 8443
    protocol    = "tcp"
    security_groups = [aws_security_group.alb_sg.id]
  }
  
  # SSH access restricted to bastion host
  ingress {
    description = "SSH from Bastion"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    security_groups = [aws_security_group.bastion_sg.id]
  }
  
  egress {
    description = "All outbound traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  
  tags = merge(local.common_tags, {
    Name = "av-application-sg"
    CISCompliant = "true"
    SecurityLevel = "high"
  })
}

# CIS 2.1 - CloudTrail Configuration
resource "aws_cloudtrail" "av_audit_trail" {
  name           = "av-experience-audit-trail"
  s3_bucket_name = aws_s3_bucket.cloudtrail_logs.bucket
  
  # CIS 2.1 - Multi-region trail
  is_multi_region_trail = true
  
  # CIS 2.2 - Log file validation
  enable_log_file_validation = true
  
  # CIS 2.4 - CloudTrail logs encrypted
  kms_key_id = aws_kms_key.cloudtrail_key.arn
  
  # CIS 2.5 - CloudWatch Logs integration
  cloud_watch_logs_group_arn = "${aws_cloudwatch_log_group.cloudtrail.arn}:*"
  cloud_watch_logs_role_arn  = aws_iam_role.cloudtrail_logs_role.arn
  
  event_selector {
    read_write_type                 = "All"
    include_management_events       = true
    
    data_resource {
      type   = "AWS::S3::Object"
      values = ["${aws_s3_bucket.sensitive_data.arn}/*"]
    }
  }
  
  tags = merge(local.common_tags, {
    CISControl = "2.1,2.2,2.4,2.5"
    Purpose = "audit-compliance"
  })
}

# CIS-compliant S3 bucket for CloudTrail logs
resource "aws_s3_bucket" "cloudtrail_logs" {
  bucket        = "av-experience-cloudtrail-logs-${random_id.bucket_suffix.hex}"
  force_destroy = false
  
  tags = merge(local.common_tags, {
    DataClassification = "audit-logs"
    CISCompliant = "true"
  })
}

resource "aws_s3_bucket_encryption" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default {
        kms_master_key_id = aws_kms_key.s3_key.arn
        sse_algorithm     = "aws:kms"
      }
      bucket_key_enabled = true
    }
  }
}

resource "aws_s3_bucket_versioning" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "cloudtrail_logs" {
  bucket = aws_s3_bucket.cloudtrail_logs.id
  
  rule {
    id     = "cloudtrail_log_retention"
    status = "Enabled"
    
    expiration {
      days = 2555  # 7 years retention for compliance
    }
    
    noncurrent_version_expiration {
      noncurrent_days = 90
    }
  }
}
```

---

## Implementation Roadmap

### 📋 **20-Week Implementation Timeline**

#### **Phase 1: Foundation & Observability (Weeks 1-6)**

**Week 1-2: Infrastructure Assessment & Planning**
- [ ] Complete current state infrastructure audit
- [ ] Identify all pmp-core dependencies and migration requirements  
- [ ] Establish baseline metrics for all systems (AV, NDAT)
- [ ] Set up project governance and communication channels
- [ ] Create detailed technical specifications for each requirement

**Week 3-4: Observability Foundation**
- [ ] Implement end-to-end tracking with correlation IDs across AV product search
- [ ] Deploy structured logging framework for all services
- [ ] Set up centralized log aggregation and processing pipeline
- [ ] Create initial Splunk dashboards using Infrastructure as Code

**Week 5-6: Monitoring & Alerting**
- [ ] Implement comprehensive KPI/KRI monitoring and alerting
- [ ] Set up PagerDuty integration for critical business alerts
- [ ] Create operational runbooks for common alert scenarios
- [ ] Performance testing and validation of observability stack

#### **Phase 2: Code Quality & Testing (Weeks 7-10)**

**Week 7-8: Testing Framework Implementation**
- [ ] Set up unit testing frameworks for all AV components
- [ ] Implement integration testing infrastructure with TestContainers
- [ ] Create code coverage reporting and tracking systems
- [ ] Establish quality gates in CI/CD pipelines

**Week 9-10: Testing Coverage & Automation**
- [ ] Achieve 80%+ unit test coverage for critical business logic
- [ ] Implement automated integration tests for product search workflows
- [ ] Set up continuous testing in deployment pipelines
- [ ] Create performance testing suites for load validation

#### **Phase 3: Cost Management & Standardization (Weeks 11-14)**

**Week 11-12: Resource Tagging & Cost Visibility**
- [ ] Implement comprehensive cloud resource tagging strategy
- [ ] Deploy automated tag compliance checking and enforcement
- [ ] Set up cost allocation reporting by business unit and project
- [ ] Create cost optimization recommendations engine

**Week 13-14: Infrastructure Standardization**
- [ ] Develop standardized Terraform modules for common patterns
- [ ] Migrate existing resources to standardized configurations
- [ ] Implement infrastructure drift detection and correction
- [ ] Optimize resource configurations for cost and performance

#### **Phase 4: Modernization & Security (Weeks 15-18)**

**Week 15-16: pmp-core Migration**
- [ ] Execute pmp-core to standardized modules migration
- [ ] Validate all infrastructure components post-migration
- [ ] Update CI/CD pipelines for new module structure
- [ ] Complete regression testing across all environments

**Week 17-18: Security & Compliance**
- [ ] Implement CIS vulnerability fixes and security hardening
- [ ] Deploy automated security compliance monitoring
- [ ] Set up security scanning in CI/CD pipelines
- [ ] Complete security audit and penetration testing

#### **Phase 5: Data Pipeline & Optimization (Weeks 19-20)**

**Week 19: Historical Data Pipeline**
- [ ] Deploy AWS Glue historical data processing pipeline
- [ ] Set up data lake architecture with proper partitioning
- [ ] Implement data catalog and discovery capabilities
- [ ] Create initial analytics dashboards for historical insights

**Week 20: Final Integration & Optimization**
- [ ] Complete end-to-end system integration testing
- [ ] Perform final performance optimization and tuning
- [ ] Complete documentation and team training
- [ ] Go-live preparation and production deployment

---

## Business Value & ROI

### 💰 **Financial Impact Analysis**

#### **Tech Modernization Cost Savings (Annual)**
| Category | Current Cost | Optimized Cost | Annual Savings | ROI% | Engineering Hours Saved |
|----------|-------------|----------------|----------------|------|------------------------|
| AV Bot Deprecation | $85K | $0K | $85K | 100% | 520 hours |
| LPDF Legacy System | $65K | $0K | $65K | 100% | 380 hours |
| Infrastructure | $240K | $180K | $60K | 25% | 450 hours |
| Operations/Support | $180K | $120K | $60K | 33% | 600 hours |
| Development Productivity | $480K | $360K | $120K | 25% | 750 hours |
| Security/Compliance | $120K | $80K | $40K | 33% | 280 hours |
| **Total Annual Savings** | **$1.17M** | **$740K** | **$430K** | **37%** | **2,980 hours** |

#### **Legacy System Deprecation Benefits**
- **AV Bots Deprecation:** Expected to save ~$85K in annual maintenance costs and ~520 engineering hours by eliminating legacy automation systems
- **LPDF (Legacy Product Data Framework):** Expected to save ~$65K in annual maintenance and ~380 engineering hours by retiring outdated data processing components

#### **Business Value Quantification**

**1. Operational Excellence**
- **Mean Time to Detection (MTTD):** Reduce from 25 minutes to 5 minutes (80% improvement)
- **Mean Time to Recovery (MTTR):** Reduce from 45 minutes to 15 minutes (67% improvement)  
- **System Availability:** Improve from 99.5% to 99.9% uptime
- **False Alert Reduction:** Decrease by 70% through intelligent monitoring

**2. Development Productivity**
- **Deployment Frequency:** Increase from weekly to daily (600% improvement)
- **Lead Time:** Reduce feature delivery time by 40%
- **Defect Rate:** Reduce production defects by 60% through comprehensive testing
- **Developer Satisfaction:** Target 85%+ satisfaction with improved tooling

**3. Cost Optimization**
- **Infrastructure Cost Visibility:** Achieve 95% cost attribution accuracy
- **Resource Optimization:** Reduce over-provisioning by 30%
- **Automated Cost Management:** Save 20 hours/week of manual cost analysis
- **Cloud Waste Reduction:** Eliminate 25% of unused/underutilized resources

**4. Security & Compliance**
- **Security Posture:** Achieve 98% CIS compliance rating
- **Vulnerability Response:** Reduce security vulnerability resolution time by 50%
- **Audit Efficiency:** Reduce compliance audit preparation time by 60%
- **Risk Mitigation:** Eliminate 5 critical security risk areas

**5. Data & Analytics Value**
- **Historical Data Access:** Enable 7-year historical analysis capability
- **Data Processing Efficiency:** Improve data pipeline performance by 75%
- **Business Intelligence:** Reduce time-to-insight by 50%
- **Data Quality:** Achieve 95% data completeness and accuracy scores

**6. Data Integration through Domain Services**
- **Data Reliability Improvement:** Expected to improve data reliability and reduce latency by 35% through modernized domain services architecture
- **Legacy Component Reduction:** Reduce operational risk by eliminating 12 legacy components and consolidating data pipelines from 8 separate systems to 3 unified services
- **Decision-Making Enhancement:** Enable faster decision-making across Merchandising, Assortment Planning, and downstream partners by reducing data processing time from 45 minutes to 15 minutes (67% improvement)
- **Platform Strategy Alignment:** Standardized domain services approach reduces integration complexity by 60% and improves cross-system data consistency to 98%

### 🎯 **Strategic Business Benefits**

#### **Enhanced Nike Assortment Management**
- **Faster Decision Making:** Reduced search response times enable quicker assortment decisions
- **Improved Planning Accuracy:** Better observability leads to more informed merchandise planning
- **Risk Mitigation:** Comprehensive monitoring prevents disruptions during critical planning seasons
- **Scalability:** Infrastructure can support Nike's growing global assortment operations

#### **Competitive Advantages**
- **Market Responsiveness:** Faster deployment cycles enable quicker response to market changes
- **Innovation Velocity:** Standardized infrastructure accelerates new feature development
- **Operational Excellence:** Best-in-class monitoring and quality practices
- **Cost Leadership:** Optimized infrastructure costs support competitive pricing

---

## Risk Assessment

### 🚨 **Critical Risks**

#### **1. Implementation Complexity Risk**
- **Risk:** Multiple concurrent modernization initiatives may overwhelm teams
- **Impact:** Delayed timeline, quality issues, team burnout
- **Probability:** Medium (40%)
- **Mitigation:**
  - Phased approach with clear priorities
  - Dedicated platform engineering team
  - Regular checkpoint reviews and scope adjustment
  - External consulting support for specialized areas
- **Monitoring:** Weekly progress reviews, team velocity tracking

#### **2. Business Continuity Risk**
- **Risk:** Infrastructure changes may impact critical assortment planning processes
- **Impact:** Disruption to Nike's seasonal planning cycles
- **Probability:** Low (15%)
- **Mitigation:**
  - Blue-green deployments with instant rollback capability
  - Comprehensive testing in non-production environments
  - Change freezes during critical business periods
  - 24/7 support during major deployments
- **Monitoring:** Real-time system health monitoring, automated rollback triggers

#### **3. Data Migration Risk**
- **Risk:** Historical data migration may result in data loss or corruption
- **Impact:** Loss of critical business analytics and reporting capabilities
- **Probability:** Low (20%)
- **Mitigation:**
  - Complete data backup before migration
  - Parallel processing validation
  - Incremental migration with validation checkpoints
  - Data integrity monitoring throughout process
- **Monitoring:** Automated data quality checks, reconciliation reports

### ⚠️ **Medium Priority Risks**

#### **4. Team Adoption Risk**
- **Risk:** Development teams may resist new tools and processes
- **Impact:** Slower adoption, reduced effectiveness of improvements
- **Probability:** Medium (35%)
- **Mitigation:**
  - Comprehensive training programs
  - Champion/advocate program within teams
  - Gradual rollout with early wins demonstration
  - Regular feedback collection and process improvement
- **Monitoring:** Adoption metrics, feedback surveys, usage analytics

#### **5. Cost Overrun Risk**
- **Risk:** Implementation costs may exceed budget due to scope creep
- **Impact:** Reduced ROI, budget constraints for future initiatives
- **Probability:** Medium (30%)
- **Mitigation:**
  - Fixed-scope phases with clear deliverables
  - Regular cost tracking and variance analysis
  - Change control process for scope modifications
  - Contingency budget allocation (15% of total)
- **Monitoring:** Weekly budget reviews, earned value analysis

#### **6. Security Compliance Risk**
- **Risk:** New implementations may introduce security vulnerabilities
- **Impact:** Compliance violations, security audit findings
- **Probability:** Low (25%)
- **Mitigation:**
  - Security reviews at each phase gate
  - Automated security scanning in CI/CD
  - Compliance validation before production deployment
  - Regular penetration testing
- **Monitoring:** Continuous security monitoring, compliance dashboards

### 📊 **Risk Mitigation Matrix**

| Risk Category | Probability | Impact | Risk Score | Mitigation Status | Owner |
|---------------|------------|--------|------------|-------------------|-------|
| Implementation Complexity | Medium | High | 8 | In Progress | Platform Engineering |
| Business Continuity | Low | Critical | 7 | Planned | Operations Team |
| Data Migration | Low | High | 6 | Planned | Data Engineering |
| Team Adoption | Medium | Medium | 5 | Planned | Engineering Management |
| Cost Overrun | Medium | Medium | 5 | In Progress | Project Management |
| Security Compliance | Low | High | 6 | Planned | Security Team |

---

## Success Metrics

### 📈 **Key Performance Indicators**

#### **Operational Excellence Metrics**

**System Reliability**
- **Availability Target:** 99.9% uptime for AV platform
- **MTTD Target:** < 5 minutes for critical issues  
- **MTTR Target:** < 15 minutes for system recovery
- **Error Rate:** < 0.1% for product search operations

**Performance Metrics**
- **Search Response Time:** < 1 second average response
- **Page Load Time:** < 3 seconds for AV interfaces
- **Concurrent Users:** Support 200+ simultaneous users
- **Database Performance:** < 200ms average query time

#### **Quality & Testing Metrics**

**Code Quality Standards**
- **Unit Test Coverage:** ≥ 80% for all components
- **Integration Test Coverage:** ≥ 70% for critical workflows
- **Code Quality Score:** ≥ 8.0/10 on SonarQube
- **Security Scan Pass Rate:** 100% critical vulnerabilities resolved

**CI/CD Efficiency**
- **Deployment Frequency:** Daily deployments capability
- **Deployment Success Rate:** ≥ 98%
- **Build Time:** < 10 minutes for full pipeline
- **Rollback Time:** < 5 minutes when needed

#### **Cost Management Metrics**

**Infrastructure Optimization**
- **Cost Attribution Accuracy:** 95% of costs properly tagged
- **Resource Utilization:** 70-85% average utilization
- **Cost Variance:** < 10% monthly budget variance
- **Waste Reduction:** 25% reduction in unused resources

**Operational Efficiency**
- **Manual Intervention Reduction:** 60% fewer manual operations
- **Alert Noise Reduction:** 70% fewer false positive alerts
- **Time to Resolution:** 50% faster incident resolution
- **Process Automation:** 80% of routine tasks automated

#### **Security & Compliance Metrics**

**Compliance Standards**
- **CIS Compliance Score:** ≥ 98%
- **Vulnerability Remediation:** < 7 days for high-severity issues
- **Security Audit Pass Rate:** 100% for quarterly audits
- **Access Review Compliance:** 100% quarterly access reviews completed

**Data Protection**
- **Data Classification:** 100% of data properly classified
- **Backup Success Rate:** 100% for critical data
- **Encryption Coverage:** 100% for data at rest and in transit
- **Incident Response Time:** < 1 hour for security incidents

### 🎯 **Business Impact Metrics**

#### **Assortment Management Efficiency**
- **Planning Cycle Time:** 25% reduction in time-to-assortment
- **Decision Speed:** 40% faster product selection processes
- **Data Accuracy:** 95% accuracy in assortment analytics
- **User Productivity:** 35% improvement in merchandiser efficiency

#### **Platform Scalability**
- **User Growth Support:** 300% increase in concurrent user capacity
- **Geographic Expansion:** Support for 3 additional regions
- **Feature Velocity:** 50% faster new feature delivery
- **System Elasticity:** Auto-scaling to 5x normal load

### 📊 **Success Tracking Dashboard**

```javascript
// Success Metrics Dashboard Configuration
const successMetrics = {
  operational: {
    availability: {
      target: 99.9,
      current: 0,
      trend: 'improving',
      alert_threshold: 99.5
    },
    response_time: {
      target: 1000,
      current: 0,
      unit: 'ms',
      trend: 'improving'
    },
    error_rate: {
      target: 0.1,
      current: 0,
      unit: '%',
      trend: 'stable'
    }
  },
  
  quality: {
    test_coverage: {
      unit: { target: 80, current: 0 },
      integration: { target: 70, current: 0 },
      overall_quality: { target: 8.0, current: 0 }
    },
    deployment: {
      frequency: { target: 'daily', current: 'weekly' },
      success_rate: { target: 98, current: 0 },
      rollback_rate: { target: '<2%', current: 0 }
    }
  },
  
  cost: {
    attribution_accuracy: { target: 95, current: 0 },
    utilization: { target: '70-85%', current: 0 },
    variance: { target: '<10%', current: 0 },
    waste_reduction: { target: 25, current: 0 }
  },
  
  security: {
    cis_compliance: { target: 98, current: 0 },
    vulnerability_resolution: { target: 7, current: 0, unit: 'days' },
    audit_pass_rate: { target: 100, current: 0 }
  },
  
  business: {
    planning_cycle_improvement: { target: 25, current: 0, unit: '%' },
    decision_speed_improvement: { target: 40, current: 0, unit: '%' },
    user_productivity: { target: 35, current: 0, unit: '%' },
    capacity_growth: { target: 300, current: 0, unit: '%' }
  }
};
```

### 🏆 **Success Validation Process**

#### **Weekly Reviews**
- Metric collection and dashboard updates
- Trend analysis and early warning detection
- Action item tracking and resolution
- Stakeholder communication and reporting

#### **Monthly Assessments**
- Comprehensive metric review against targets
- Business impact analysis and ROI calculation
- Risk assessment and mitigation effectiveness
- Process improvement recommendations

#### **Quarterly Business Reviews**
- Strategic alignment validation
- Budget and resource allocation review
- Success story documentation and sharing
- Future roadmap planning and prioritization

---

## Conclusion

The **Platform Engineering Modernization Initiative** represents a comprehensive transformation of Nike's technology infrastructure supporting the critical AV (Assortment Visual) and broader assortment management ecosystem. This initiative addresses fundamental gaps in observability, quality assurance, cost management, security, and technical modernization that are essential for Nike's continued digital leadership.

### **Strategic Impact**

**Operational Excellence Achievement**
This modernization directly supports Nike's operational excellence goals by implementing world-class observability, monitoring, and quality practices. The end-to-end tracking and structured logging will provide unprecedented visibility into system performance and business processes, enabling proactive issue resolution and continuous optimization.

**Business Value Realization**  
With projected annual savings of **$280K** and a **27% ROI**, this initiative delivers measurable financial returns while significantly improving operational capabilities. The enhanced infrastructure will support Nike's growing global assortment operations and enable faster response to market opportunities.

**Risk Mitigation & Compliance**
The comprehensive approach to security hardening, CIS compliance, and infrastructure standardization reduces Nike's operational and regulatory risks while establishing a foundation for future growth and expansion.

### **Key Success Factors**

1. **Phased Implementation Approach:** The 20-week timeline with clear phase gates minimizes business disruption while ensuring systematic progress
2. **Business Continuity Focus:** All changes prioritize maintaining critical assortment planning operations
3. **Comprehensive Testing Strategy:** Extensive unit and integration testing ensures quality and reliability
4. **Cost Optimization:** Systematic approach to cost visibility and resource optimization
5. **Security-First Design:** CIS compliance and security hardening built into every component

### **Long-term Benefits**

**Scalability Foundation**
The standardized infrastructure and modernized data pipeline provide the foundation for Nike's continued growth, supporting expanded geographic operations and increased user base without proportional infrastructure costs.

**Innovation Enablement**
Improved CI/CD practices, comprehensive testing, and standardized infrastructure will accelerate Nike's ability to deliver new assortment management capabilities and respond to market changes.

**Competitive Advantage**
The combination of operational excellence, cost optimization, and technical modernization positions Nike with industry-leading assortment management capabilities that drive competitive advantage in the marketplace.

### **Next Steps**

1. **Executive Approval & Budget Authorization:** Secure leadership approval and budget allocation for the full 20-week initiative
2. **Team Formation & Resource Allocation:** Assemble dedicated platform engineering team with necessary skills and authority
3. **Stakeholder Alignment:** Ensure business stakeholders understand timeline and potential impacts
4. **Vendor & Partner Engagement:** Engage necessary technology partners and vendors for specialized requirements
5. **Phase 1 Kickoff:** Begin immediate implementation of observability and infrastructure assessment

### **Commitment to Excellence**

This initiative reflects Nike's commitment to technological excellence and operational efficiency in support of its core business objectives. The comprehensive approach addresses not just current needs but establishes a foundation for continued innovation and growth in Nike's assortment management capabilities.

The successful completion of this modernization initiative will position Nike's platform engineering capabilities as best-in-class, supporting the company's mission to serve athletes and drive innovation in the global marketplace.

---

*This document represents a comprehensive platform engineering modernization strategy designed to transform Nike's technical infrastructure while maintaining business continuity and driving measurable value.*

**Document Version:** 1.0  
**Last Updated:** September 16, 2025  
**Next Review Date:** October 1, 2025  
**Document Owner:** Platform Engineering Team  
**Business Stakeholder:** Nike Technology Leadership  
**Implementation Timeline:** 20 weeks (January 2026 - May 2026)

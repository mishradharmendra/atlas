-- liquibase formatted sql

-- changeset acme:001-dev-test-data labels:v1.0,v1.1,v1.2 context:dev
-- comment: Insert test data for development environment only

SET search_path TO acme_schema;

-- Insert test users
INSERT INTO users (username, email, password_hash, first_name, last_name, is_active, is_verified)
VALUES 
    ('john.doe', 'john.doe@test.com', crypt('password123', gen_salt('bf')), 'John', 'Doe', true, true),
    ('jane.smith', 'jane.smith@test.com', crypt('password123', gen_salt('bf')), 'Jane', 'Smith', true, true),
    ('bob.wilson', 'bob.wilson@test.com', crypt('password123', gen_salt('bf')), 'Bob', 'Wilson', true, false),
    ('alice.brown', 'alice.brown@test.com', crypt('password123', gen_salt('bf')), 'Alice', 'Brown', false, true)
ON CONFLICT (username) DO NOTHING;

-- Insert additional test products
INSERT INTO products (sku, name, description, price, cost, weight, is_active, stock_quantity, min_stock_level)
VALUES 
    ('TEST-001', 'Test Widget Alpha', 'Test widget for development testing', 9.99, 5.00, 0.1, true, 1000, 50),
    ('TEST-002', 'Test Widget Beta', 'Another test widget for development', 14.99, 7.50, 0.2, true, 500, 25),
    ('TEST-003', 'Test Digital Product', 'Digital test product', 4.99, 1.00, null, true, 999, 0),
    ('TEST-004', 'Test Heavy Item', 'Heavy test item for shipping tests', 199.99, 100.00, 10.0, true, 10, 2),
    ('TEST-005', 'Test Inactive Product', 'Inactive product for testing', 29.99, 15.00, 0.5, false, 0, 0)
ON CONFLICT (sku) DO NOTHING;

-- Insert test orders
DO $$
DECLARE
    user_john_id BIGINT;
    user_jane_id BIGINT;
    product_test1_id BIGINT;
    product_test2_id BIGINT;
    order1_id BIGINT;
    order2_id BIGINT;
BEGIN
    -- Get user IDs
    SELECT id INTO user_john_id FROM users WHERE username = 'john.doe';
    SELECT id INTO user_jane_id FROM users WHERE username = 'jane.smith';
    
    -- Get product IDs
    SELECT id INTO product_test1_id FROM products WHERE sku = 'TEST-001';
    SELECT id INTO product_test2_id FROM products WHERE sku = 'TEST-002';
    
    -- Insert test orders if users and products exist
    IF user_john_id IS NOT NULL AND product_test1_id IS NOT NULL THEN
        INSERT INTO orders (order_number, user_id, status, subtotal, tax_amount, total_amount, shipping_address, billing_address)
        VALUES (
            generate_order_number(),
            user_john_id,
            'confirmed',
            19.98,
            1.60,
            21.58,
            '{"street": "123 Test St", "city": "Test City", "state": "TS", "zip": "12345", "country": "US"}',
            '{"street": "123 Test St", "city": "Test City", "state": "TS", "zip": "12345", "country": "US"}'
        ) RETURNING id INTO order1_id;
        
        -- Insert order items for first order
        INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
        VALUES 
            (order1_id, product_test1_id, 2, 9.99, 19.98);
    END IF;
    
    IF user_jane_id IS NOT NULL AND product_test2_id IS NOT NULL THEN
        INSERT INTO orders (order_number, user_id, status, subtotal, tax_amount, total_amount, shipping_address, billing_address)
        VALUES (
            generate_order_number(),
            user_jane_id,
            'processing',
            29.98,
            2.40,
            32.38,
            '{"street": "456 Demo Ave", "city": "Demo City", "state": "DM", "zip": "67890", "country": "US"}',
            '{"street": "456 Demo Ave", "city": "Demo City", "state": "DM", "zip": "67890", "country": "US"}'
        ) RETURNING id INTO order2_id;
        
        -- Insert order items for second order
        INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
        VALUES 
            (order2_id, product_test2_id, 2, 14.99, 29.98);
    END IF;
END $$;

-- Insert test user profiles (if user_profiles table exists)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'user_profiles' AND table_schema = 'acme_schema') THEN
        INSERT INTO user_profiles (user_id, bio, country, timezone, language, preferences)
        SELECT 
            u.id,
            'Test user profile for ' || u.first_name || ' ' || u.last_name,
            'US',
            'America/New_York',
            'en',
            '{"notifications": {"email": true, "sms": false}, "theme": "light"}'
        FROM users u
        WHERE u.username IN ('john.doe', 'jane.smith', 'bob.wilson', 'alice.brown')
        ON CONFLICT (user_id) DO NOTHING;
    END IF;
END $$;

-- Insert test system events for development
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'system_event_logs' AND table_schema = 'acme_schema') THEN
        PERFORM log_system_event(
            'SYSTEM_STARTUP',
            'INFO',
            'LOW',
            'Development environment initialized with test data',
            '{"environment": "development", "data_loaded": true}',
            'data-loader',
            uuid_generate_v4()
        );
    END IF;
END $$;

-- Update system configuration for development
UPDATE system_config 
SET value = 'ACME Corp Development System'
WHERE key = 'app.name';

INSERT INTO system_config (key, value, description)
VALUES 
    ('dev.test_mode', 'true', 'Development test mode enabled'),
    ('dev.debug_logging', 'true', 'Enable debug logging in development'),
    ('dev.mock_payments', 'true', 'Use mock payment processor'),
    ('dev.email_override', 'dev-team@acme.com', 'Override all emails to dev team')
ON CONFLICT (key) DO UPDATE SET 
    value = EXCLUDED.value,
    updated_at = CURRENT_TIMESTAMP;

-- rollback DELETE FROM system_config WHERE key LIKE 'dev.%';
-- rollback UPDATE system_config SET value = 'ACME Corp System' WHERE key = 'app.name';
-- rollback DELETE FROM order_items WHERE order_id IN (SELECT id FROM orders WHERE user_id IN (SELECT id FROM users WHERE username IN ('john.doe', 'jane.smith')));
-- rollback DELETE FROM orders WHERE user_id IN (SELECT id FROM users WHERE username IN ('john.doe', 'jane.smith', 'bob.wilson', 'alice.brown'));
-- rollback DELETE FROM user_profiles WHERE user_id IN (SELECT id FROM users WHERE username IN ('john.doe', 'jane.smith', 'bob.wilson', 'alice.brown'));
-- rollback DELETE FROM products WHERE sku LIKE 'TEST-%';
-- rollback DELETE FROM users WHERE username IN ('john.doe', 'jane.smith', 'bob.wilson', 'alice.brown');

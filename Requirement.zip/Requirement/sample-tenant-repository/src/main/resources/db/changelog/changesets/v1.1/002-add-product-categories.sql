-- liquibase formatted sql

-- changeset acme:002-add-product-categories labels:v1.1 context:common
-- comment: Add product categories and tags for better organization

SET search_path TO acme_schema;

-- Create product categories table
CREATE TABLE product_categories (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID DEFAULT uuid_generate_v4() UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_id BIGINT REFERENCES product_categories(id) ON DELETE SET NULL,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT product_categories_name_not_empty CHECK (length(trim(name)) > 0),
    CONSTRAINT product_categories_slug_format CHECK (slug ~* '^[a-z0-9-]+$')
);

-- Create product tags table
CREATE TABLE product_tags (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    color VARCHAR(7) DEFAULT '#007bff', -- Hex color code
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT product_tags_name_not_empty CHECK (length(trim(name)) > 0),
    CONSTRAINT product_tags_color_hex CHECK (color ~* '^#[0-9a-f]{6}$')
);

-- Create junction table for product-category relationships
CREATE TABLE product_category_mappings (
    product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    category_id BIGINT NOT NULL REFERENCES product_categories(id) ON DELETE CASCADE,
    is_primary BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (product_id, category_id)
);

-- Create junction table for product-tag relationships
CREATE TABLE product_tag_mappings (
    product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    tag_id BIGINT NOT NULL REFERENCES product_tags(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (product_id, tag_id)
);

-- Create indexes
CREATE INDEX idx_product_categories_parent_id ON product_categories(parent_id);
CREATE INDEX idx_product_categories_slug ON product_categories(slug);
CREATE INDEX idx_product_categories_active ON product_categories(is_active);
CREATE INDEX idx_product_category_mappings_category_id ON product_category_mappings(category_id);
CREATE INDEX idx_product_category_mappings_primary ON product_category_mappings(is_primary);
CREATE INDEX idx_product_tag_mappings_tag_id ON product_tag_mappings(tag_id);

-- Create triggers for updated_at
CREATE TRIGGER update_product_categories_updated_at 
    BEFORE UPDATE ON product_categories 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insert default categories
INSERT INTO product_categories (name, slug, description, sort_order) VALUES
    ('Electronics', 'electronics', 'Electronic devices and accessories', 1),
    ('Widgets', 'widgets', 'Various types of widgets', 2),
    ('Digital Services', 'digital-services', 'Software and digital products', 3),
    ('Accessories', 'accessories', 'Product accessories and add-ons', 4);

-- Insert default tags
INSERT INTO product_tags (name, color) VALUES
    ('Premium', '#ffd700'),
    ('Bestseller', '#ff6b6b'),
    ('New', '#4ecdc4'),
    ('Sale', '#ff9f43'),
    ('Digital', '#6c5ce7');

-- Assign categories to existing products
INSERT INTO product_category_mappings (product_id, category_id, is_primary)
SELECT p.id, c.id, true
FROM products p, product_categories c
WHERE (p.sku = 'ACME-001' AND c.slug = 'widgets')
   OR (p.sku = 'ACME-002' AND c.slug = 'widgets')
   OR (p.sku = 'ACME-003' AND c.slug = 'digital-services')
   OR (p.sku = 'ACME-004' AND c.slug = 'accessories');

-- Assign tags to existing products
INSERT INTO product_tag_mappings (product_id, tag_id)
SELECT p.id, t.id
FROM products p, product_tags t
WHERE (p.sku = 'ACME-001' AND t.name = 'Premium')
   OR (p.sku = 'ACME-002' AND t.name = 'Bestseller')
   OR (p.sku = 'ACME-003' AND t.name = 'Digital')
   OR (p.sku = 'ACME-004' AND t.name = 'New');

-- rollback DROP TRIGGER IF EXISTS update_product_categories_updated_at ON product_categories;
-- rollback DROP TABLE IF EXISTS product_tag_mappings CASCADE;
-- rollback DROP TABLE IF EXISTS product_category_mappings CASCADE;
-- rollback DROP TABLE IF EXISTS product_tags CASCADE;
-- rollback DROP TABLE IF EXISTS product_categories CASCADE;

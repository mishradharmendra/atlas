-- liquibase formatted sql

-- changeset acme:001-initial-schema labels:v1.0 context:common
-- comment: Create initial database schema and basic structure

-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS acme_schema;

-- Set search path
SET search_path TO acme_schema;

-- Create sequences
CREATE SEQUENCE IF NOT EXISTS user_id_seq START 1000;
CREATE SEQUENCE IF NOT EXISTS product_id_seq START 2000;
CREATE SEQUENCE IF NOT EXISTS order_id_seq START 3000;

-- Create extensions if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- rollback CREATE SCHEMA IF NOT EXISTS acme_schema;
-- rollback DROP SEQUENCE IF EXISTS acme_schema.user_id_seq CASCADE;
-- rollback DROP SEQUENCE IF EXISTS acme_schema.product_id_seq CASCADE;
-- rollback DROP SEQUENCE IF EXISTS acme_schema.order_id_seq CASCADE;
-- rollback DROP EXTENSION IF EXISTS "uuid-ossp";
-- rollback DROP EXTENSION IF EXISTS "pgcrypto";
-- rollback DROP SCHEMA IF EXISTS acme_schema CASCADE;

-- liquibase formatted sql

-- changeset acme:001-add-audit-tables labels:v1.2 context:common
-- comment: Add comprehensive audit logging tables for data tracking

SET search_path TO acme_schema;

-- Create audit log table for tracking all data changes
CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    record_id BIGINT NOT NULL,
    operation VARCHAR(10) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[],
    user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
    user_ip INET,
    user_agent TEXT,
    session_id VARCHAR(100),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT audit_logs_operation_valid CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE'))
);

-- Create user activity log table
CREATE TABLE user_activity_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
    activity_type VARCHAR(50) NOT NULL,
    activity_description TEXT,
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(100),
    metadata JSONB DEFAULT '{}',
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create system event logs table
CREATE TABLE system_event_logs (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    event_category VARCHAR(30) NOT NULL, -- SECURITY, PERFORMANCE, ERROR, INFO
    severity VARCHAR(10) NOT NULL, -- LOW, MEDIUM, HIGH, CRITICAL
    message TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    source_component VARCHAR(100),
    correlation_id UUID,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT system_event_logs_category_valid CHECK (event_category IN ('SECURITY', 'PERFORMANCE', 'ERROR', 'INFO')),
    CONSTRAINT system_event_logs_severity_valid CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'))
);

-- Create indexes for performance
CREATE INDEX idx_audit_logs_table_record ON audit_logs(table_name, record_id);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_operation ON audit_logs(operation);

CREATE INDEX idx_user_activity_logs_user_id ON user_activity_logs(user_id);
CREATE INDEX idx_user_activity_logs_activity_type ON user_activity_logs(activity_type);
CREATE INDEX idx_user_activity_logs_timestamp ON user_activity_logs(timestamp);

CREATE INDEX idx_system_event_logs_event_type ON system_event_logs(event_type);
CREATE INDEX idx_system_event_logs_category ON system_event_logs(event_category);
CREATE INDEX idx_system_event_logs_severity ON system_event_logs(severity);
CREATE INDEX idx_system_event_logs_timestamp ON system_event_logs(timestamp);
CREATE INDEX idx_system_event_logs_correlation_id ON system_event_logs(correlation_id);

-- Create function to log audit events
CREATE OR REPLACE FUNCTION log_audit_event()
RETURNS TRIGGER AS $$
DECLARE
    old_data JSONB;
    new_data JSONB;
    changed_fields TEXT[] := '{}';
    field_name TEXT;
BEGIN
    -- Convert OLD and NEW to JSONB
    IF TG_OP = 'DELETE' THEN
        old_data := to_jsonb(OLD);
        new_data := NULL;
    ELSIF TG_OP = 'INSERT' THEN
        old_data := NULL;
        new_data := to_jsonb(NEW);
    ELSE -- UPDATE
        old_data := to_jsonb(OLD);
        new_data := to_jsonb(NEW);
        
        -- Find changed fields
        FOR field_name IN SELECT key FROM jsonb_each(new_data) LOOP
            IF old_data->field_name IS DISTINCT FROM new_data->field_name THEN
                changed_fields := array_append(changed_fields, field_name);
            END IF;
        END LOOP;
    END IF;
    
    -- Insert audit log
    INSERT INTO audit_logs (
        table_name,
        record_id,
        operation,
        old_values,
        new_values,
        changed_fields,
        user_id,
        timestamp
    ) VALUES (
        TG_TABLE_NAME,
        CASE 
            WHEN TG_OP = 'DELETE' THEN (old_data->>'id')::BIGINT
            ELSE (new_data->>'id')::BIGINT
        END,
        TG_OP,
        old_data,
        new_data,
        changed_fields,
        NULLIF(current_setting('app.current_user_id', true), '')::BIGINT,
        CURRENT_TIMESTAMP
    );
    
    RETURN CASE 
        WHEN TG_OP = 'DELETE' THEN OLD
        ELSE NEW
    END;
END;
$$ LANGUAGE plpgsql;

-- Create audit triggers for main tables
CREATE TRIGGER audit_users_trigger
    AFTER INSERT OR UPDATE OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION log_audit_event();

CREATE TRIGGER audit_products_trigger
    AFTER INSERT OR UPDATE OR DELETE ON products
    FOR EACH ROW EXECUTE FUNCTION log_audit_event();

CREATE TRIGGER audit_orders_trigger
    AFTER INSERT OR UPDATE OR DELETE ON orders
    FOR EACH ROW EXECUTE FUNCTION log_audit_event();

-- Function to log user activity
CREATE OR REPLACE FUNCTION log_user_activity(
    p_user_id BIGINT,
    p_activity_type VARCHAR(50),
    p_description TEXT DEFAULT NULL,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL,
    p_session_id VARCHAR(100) DEFAULT NULL,
    p_metadata JSONB DEFAULT '{}'
) RETURNS VOID AS $$
BEGIN
    INSERT INTO user_activity_logs (
        user_id,
        activity_type,
        activity_description,
        ip_address,
        user_agent,
        session_id,
        metadata
    ) VALUES (
        p_user_id,
        p_activity_type,
        p_description,
        p_ip_address,
        p_user_agent,
        p_session_id,
        p_metadata
    );
END;
$$ LANGUAGE plpgsql;

-- Function to log system events
CREATE OR REPLACE FUNCTION log_system_event(
    p_event_type VARCHAR(50),
    p_category VARCHAR(30),
    p_severity VARCHAR(10),
    p_message TEXT,
    p_details JSONB DEFAULT '{}',
    p_source_component VARCHAR(100) DEFAULT NULL,
    p_correlation_id UUID DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
    INSERT INTO system_event_logs (
        event_type,
        event_category,
        severity,
        message,
        details,
        source_component,
        correlation_id
    ) VALUES (
        p_event_type,
        p_category,
        p_severity,
        p_message,
        p_details,
        p_source_component,
        p_correlation_id
    );
END;
$$ LANGUAGE plpgsql;

-- rollback DROP FUNCTION IF EXISTS log_system_event(VARCHAR, VARCHAR, VARCHAR, TEXT, JSONB, VARCHAR, UUID);
-- rollback DROP FUNCTION IF EXISTS log_user_activity(BIGINT, VARCHAR, TEXT, INET, TEXT, VARCHAR, JSONB);
-- rollback DROP TRIGGER IF EXISTS audit_orders_trigger ON orders;
-- rollback DROP TRIGGER IF EXISTS audit_products_trigger ON products;
-- rollback DROP TRIGGER IF EXISTS audit_users_trigger ON users;
-- rollback DROP FUNCTION IF EXISTS log_audit_event();
-- rollback DROP TABLE IF EXISTS system_event_logs CASCADE;
-- rollback DROP TABLE IF EXISTS user_activity_logs CASCADE;
-- rollback DROP TABLE IF EXISTS audit_logs CASCADE;

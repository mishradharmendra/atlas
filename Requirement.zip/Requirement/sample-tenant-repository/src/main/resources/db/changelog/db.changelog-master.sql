-- liquibase formatted sql

-- Master changelog file for ACME Corp database schema
-- This file includes all version-specific changesets

-- changeset acme:master-1.0.0 labels:v1.0 context:common
-- include file:changesets/v1.0/001-initial-schema.sql
-- include file:changesets/v1.0/002-users-table.sql
-- include file:changesets/v1.0/003-products-table.sql
-- include file:changesets/v1.0/004-orders-table.sql
-- include file:changesets/v1.0/005-initial-data.sql

-- changeset acme:master-1.1.0 labels:v1.1 context:common
-- include file:changesets/v1.1/001-add-user-profiles.sql
-- include file:changesets/v1.1/002-add-product-categories.sql
-- include file:changesets/v1.1/003-add-order-status-tracking.sql
-- include file:changesets/v1.1/004-add-indexes.sql

-- changeset acme:master-1.2.0 labels:v1.2 context:common
-- include file:changesets/v1.2/001-add-audit-tables.sql
-- include file:changesets/v1.2/002-add-payment-methods.sql
-- include file:changesets/v1.2/003-add-inventory-tracking.sql
-- include file:changesets/v1.2/004-performance-optimizations.sql

-- Development-specific changesets
-- changeset acme:dev-data labels:v1.0,v1.1,v1.2 context:dev
-- include file:changesets/dev/001-dev-test-data.sql

-- Production-specific changesets  
-- changeset acme:prod-config labels:v1.0,v1.1,v1.2 context:prod
-- include file:changesets/prod/001-prod-configurations.sql

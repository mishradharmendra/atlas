-- liquibase formatted sql

-- changeset acme:001-add-user-profiles labels:v1.1 context:common
-- comment: Add user profiles table for extended user information

SET search_path TO acme_schema;

-- Create user profiles table
CREATE TABLE user_profiles (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    avatar_url VARCHAR(500),
    bio TEXT,
    date_of_birth DATE,
    gender VARCHAR(20),
    country VARCHAR(2), -- ISO country code
    timezone VARCHAR(50),
    language VARCHAR(10) DEFAULT 'en',
    preferences JSONB DEFAULT '{}',
    social_links JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT user_profiles_user_unique UNIQUE (user_id),
    CONSTRAINT user_profiles_language_format CHECK (language ~* '^[a-z]{2}(-[A-Z]{2})?$')
);

-- Create indexes
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_country ON user_profiles(country);
CREATE INDEX idx_user_profiles_language ON user_profiles(language);

-- Create trigger for updated_at
CREATE TRIGGER update_user_profiles_updated_at 
    BEFORE UPDATE ON user_profiles 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Add profile columns to users table
ALTER TABLE users 
ADD COLUMN profile_completed BOOLEAN DEFAULT false,
ADD COLUMN marketing_consent BOOLEAN DEFAULT false,
ADD COLUMN terms_accepted_at TIMESTAMP WITH TIME ZONE;

-- Create index for new columns
CREATE INDEX idx_users_profile_completed ON users(profile_completed);

-- Insert default profiles for existing users
INSERT INTO user_profiles (user_id, preferences, social_links)
SELECT id, '{"notifications": {"email": true, "sms": false}}', '{}'
FROM users
WHERE id NOT IN (SELECT user_id FROM user_profiles);

-- rollback DROP INDEX IF EXISTS idx_users_profile_completed;
-- rollback ALTER TABLE users DROP COLUMN IF EXISTS profile_completed, DROP COLUMN IF EXISTS marketing_consent, DROP COLUMN IF EXISTS terms_accepted_at;
-- rollback DROP TRIGGER IF EXISTS update_user_profiles_updated_at ON user_profiles;
-- rollback DROP TABLE IF EXISTS user_profiles CASCADE;

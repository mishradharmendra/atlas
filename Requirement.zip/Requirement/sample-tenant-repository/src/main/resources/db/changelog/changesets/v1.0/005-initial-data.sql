-- liquibase formatted sql

-- changeset acme:005-initial-data labels:v1.0 context:common
-- comment: Insert initial reference data and system configurations

SET search_path TO acme_schema;

-- Insert system admin user
INSERT INTO users (username, email, password_hash, first_name, last_name, is_active, is_verified)
VALUES (
    'admin',
    'admin@acme.com',
    crypt('admin123', gen_salt('bf')),
    'System',
    'Administrator',
    true,
    true
) ON CONFLICT (username) DO NOTHING;

-- Insert sample products
INSERT INTO products (sku, name, description, price, cost, weight, is_active, stock_quantity, min_stock_level)
VALUES 
    ('ACME-001', 'Premium Widget', 'High-quality widget for professional use', 29.99, 15.00, 0.5, true, 100, 10),
    ('ACME-002', 'Standard Widget', 'Standard widget for everyday use', 19.99, 10.00, 0.3, true, 200, 20),
    ('ACME-003', 'Digital Service', 'Premium digital service subscription', 99.99, 5.00, null, true, 999, 0),
    ('ACME-004', 'Starter Kit', 'Complete starter kit with accessories', 49.99, 25.00, 2.0, true, 50, 5)
ON CONFLICT (sku) DO NOTHING;

-- Create system configuration table for application settings
CREATE TABLE IF NOT EXISTS system_config (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insert system configurations
INSERT INTO system_config (key, value, description)
VALUES 
    ('app.name', 'ACME Corp System', 'Application name'),
    ('app.version', '1.0.0', 'Current application version'),
    ('order.default_currency', 'USD', 'Default currency for orders'),
    ('order.tax_rate', '0.08', 'Default tax rate (8%)'),
    ('inventory.low_stock_threshold', '10', 'Threshold for low stock alerts'),
    ('email.from_address', 'noreply@acme.com', 'Default from email address'),
    ('maintenance.enabled', 'false', 'Maintenance mode flag')
ON CONFLICT (key) DO UPDATE SET 
    value = EXCLUDED.value,
    updated_at = CURRENT_TIMESTAMP;

-- Create trigger for system_config updated_at
CREATE TRIGGER update_system_config_updated_at 
    BEFORE UPDATE ON system_config 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- rollback DROP TRIGGER IF EXISTS update_system_config_updated_at ON system_config;
-- rollback DROP TABLE IF EXISTS system_config CASCADE;
-- rollback DELETE FROM products WHERE sku IN ('ACME-001', 'ACME-002', 'ACME-003', 'ACME-004');
-- rollback DELETE FROM users WHERE username = 'admin';

# ACME Corp Database Schema Repository

This repository contains the database schema and changesets for ACME Corp tenant in the DBSerenity platform.

## Repository Structure

```
├── config/
│   └── tenant-config.json          # Tenant-specific configuration
├── src/
│   ├── main/resources/
│   │   ├── db/changelog/
│   │   │   ├── db.changelog-master.sql    # Master changelog file
│   │   │   └── changesets/                # Version-specific changesets
│   │   │       ├── v1.0/                  # Initial schema (v1.0)
│   │   │       ├── v1.1/                  # User profiles & categories (v1.1)
│   │   │       ├── v1.2/                  # Audit & payments (v1.2)
│   │   │       ├── dev/                   # Development-only data
│   │   │       └── prod/                  # Production-only configs
│   │   └── liquibase.properties           # Liquibase configuration
│   └── assembly/
│       └── changeset-bundle.xml           # Maven assembly descriptor
├── .github/workflows/
│   ├── dev-deploy.yml                     # Development deployment
│   └── release.yml                        # Production release
├── pom.xml                                # Maven project configuration
└── README.md                              # This file
```

## Database Schema Overview

### Version 1.0 - Initial Schema
- **Users**: User accounts and authentication
- **Products**: Product catalog with pricing
- **Orders**: Order management and order items
- **System Config**: Application configuration

### Version 1.1 - Enhanced Features
- **User Profiles**: Extended user information
- **Product Categories**: Hierarchical product organization
- **Product Tags**: Flexible product tagging system

### Version 1.2 - Audit & Compliance
- **Audit Logs**: Comprehensive data change tracking
- **User Activity**: User action logging
- **System Events**: System-wide event logging

## Development Workflow

### Local Development

1. **Prerequisites**
   - Java 21+
   - Maven 3.8+
   - PostgreSQL 13+ (for local testing)

2. **Setup Local Database**
   ```bash
   # Create local development database
   createdb acme_dev
   
   # Update liquibase.properties with local settings
   cp src/main/resources/liquibase.properties.example src/main/resources/liquibase.properties
   ```

3. **Run Liquibase Locally**
   ```bash
   # Validate changesets
   mvn liquibase:validate
   
   # Update database
   mvn liquibase:update -Dliquibase.contexts=common,dev
   
   # Generate documentation
   mvn liquibase:dbDoc
   ```

### Branch Strategy

- **main**: Production-ready releases
- **dev**: Development integration branch
- **feature/***: Feature development branches

### Making Changes

1. Create feature branch from `dev`
2. Add new changesets in appropriate version directory
3. Update `db.changelog-master.sql` to include new changesets
4. Test locally with `mvn liquibase:validate`
5. Create PR to `dev` branch
6. After PR merge, GitHub Actions will build and deploy to dev environment

## Changeset Guidelines

### Naming Convention
```
changesets/v{major.minor}/{sequence}-{description}.sql
```

Example: `changesets/v1.3/001-add-payment-methods.sql`

### Changeset Structure
```sql
-- liquibase formatted sql

-- changeset author:changeset-id labels:version context:environment
-- comment: Description of what this changeset does

-- Your SQL changes here

-- rollback SQL to undo the changes
```

### Best Practices

1. **Always include rollback statements**
2. **Use appropriate contexts** (`common`, `dev`, `prod`)
3. **Add meaningful comments**
4. **Test changesets locally before committing**
5. **Keep changesets atomic and focused**
6. **Use proper constraints and indexes**

## Deployment Process

### Development Deployment
- Triggered on PR merge to `dev` branch
- Builds artifact and uploads to artifact registry
- Notifies DBSerenity platform
- Runs security scans and validations

### Production Release
- Triggered on push to `main` branch
- Creates GitHub release with artifacts
- Comprehensive testing and validation
- Notifies stakeholders via Slack/Teams

## Configuration

### Tenant Configuration (`config/tenant-config.json`)
Contains environment-specific database connection details and Liquibase settings. **Never include passwords in this file.**

### Liquibase Properties (`src/main/resources/liquibase.properties`)
Standard Liquibase configuration file. Database passwords are injected by the DBSerenity platform during execution.

## Contexts and Labels

### Contexts
- `common`: Applied to all environments
- `dev`: Development environment only
- `staging`: Staging environment only  
- `prod`: Production environment only

### Labels
- `v1.0`, `v1.1`, `v1.2`: Version-specific labels
- Used for selective deployment of specific versions

## Monitoring and Observability

The DBSerenity platform provides:
- Real-time execution monitoring
- Comprehensive audit trails
- Email notifications on success/failure
- Rollback capabilities
- Performance metrics

## Security Considerations

1. **No sensitive data in repository**
2. **Database passwords provided at runtime**
3. **SQL injection prevention in changesets**
4. **Proper access controls via DBSerenity platform**
5. **Audit logging for all changes**

## Support and Troubleshooting

### Common Issues

1. **Changeset validation fails**
   - Check SQL syntax
   - Verify rollback statements
   - Ensure proper changeset format

2. **Context/label issues**
   - Verify context spelling in changesets
   - Check tenant-config.json for correct contexts

3. **Dependency issues**
   - Ensure changesets are in correct order
   - Check foreign key dependencies

### Getting Help

- **DBSerenity Platform**: Contact platform administrators
- **Database Issues**: Contact DBA team at dba@acme.com
- **CI/CD Issues**: Contact DevOps team at devops@acme.com

## License

This repository contains proprietary database schema for ACME Corp. Unauthorized access or distribution is prohibited.

---

**Last Updated**: $(date)
**Schema Version**: 1.2.0
**Tenant ID**: acme-corp-001

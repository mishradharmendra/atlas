# DBSerenity Platform Development Prompt

## Project Overview
Build **DBSerenity** - a comprehensive schema versioning platform using Liquibase that enables multi-tenant database change management with automated CI/CD integration.

## Core Requirements

### 1. Platform Architecture
- **Tech Stack**: Java 24, Spring Boot, Liquibase (SQL-based changesets), GitHub Actions
- **Database**: Choose appropriate database for platform metadata (PostgreSQL recommended)
- **Authentication**: JWT-based with client ID/secret generation
- **Artifact Storage**: Integration with artifact repository (Nexus/Artifactory)

### 2. Tenant Management System

#### Tenant Onboarding
- Create REST APIs for tenant registration and management
- Generate unique client ID and secret for each tenant
- Store tenant metadata securely
- Provide tenant dashboard for self-service operations

#### Client Authentication
- Implement OAuth2/JWT authentication using client credentials flow
- Secure API endpoints with proper authorization
- Token management and refresh capabilities

### 3. GitHub Repository Integration

#### Repository Structure (Per Tenant)
Create a Maven-based template repository with:
```
tenant-repo/
├── pom.xml
├── src/main/resources/
│   ├── db/changelog/
│   │   ├── db.changelog-master.sql
│   │   ├── changesets/
│   │   │   ├── v1.0/
│   │   │   └── v1.1/
│   └── liquibase.properties
├── config/
│   └── tenant-config.json
├── .github/workflows/
│   ├── dev-deploy.yml
│   └── release.yml
└── README.md
```

#### Configuration File (tenant-config.json)
```json
{
  "tenantId": "tenant-123",
  "environments": {
    "dev": {
      "jdbcUrl": "jdbc:postgresql://dev-db:5432/tenant_dev",
      "username": "tenant_user",
      "schema": "tenant_schema"
    },
    "prod": {
      "jdbcUrl": "jdbc:postgresql://prod-db:5432/tenant_prod", 
      "username": "tenant_user",
      "schema": "tenant_schema"
    }
  },
  "liquibaseConfig": {
    "changeLogFile": "db/changelog/db.changelog-master.sql",
    "defaultSchemaName": "tenant_schema"
  }
}
```

### 4. GitHub Actions Workflows

#### Development Workflow (on PR merge to dev)
- Trigger Maven build and test
- Run Liquibase validation
- Create development artifact (ZIP)
- Push to artifact repository with dev tag
- Run integration tests

#### Release Workflow (on merge to main)
- Create production-ready artifact
- Generate release notes
- Tag release version
- Push to artifact repository with release tag

### 5. Core Platform APIs

#### Changeset Execution API
```
POST /api/v1/changesets/execute
```

**Request Payload:**
```json
{
  "clientId": "client-123",
  "clientSecret": "secret-456",
  "artifactUrl": "https://artifacts.company.com/tenant-123/v1.2.0/changesets.zip",
  "environment": "dev|prod",
  "mode": "dry-run|execute",
  "databasePassword": "encrypted-password",
  "executionOptions": {
    "rollbackOnFailure": true,
    "notificationEmail": "admin@tenant.com"
  }
}
```

#### Additional Required APIs
- `GET /api/v1/tenants/{tenantId}/executions` - Execution history
- `POST /api/v1/changesets/rollback` - Rollback functionality  
- `GET /api/v1/changesets/status/{executionId}` - Execution status
- `GET /api/v1/audit/logs` - Audit trail access

### 6. Observability & Monitoring

#### Logging Requirements
- Structured logging with correlation IDs
- Liquibase execution logs capture
- Security audit logs
- Performance metrics logging

#### Monitoring & Alerting
- Health checks for all services
- Database connection monitoring  
- Execution success/failure rates
- Performance dashboards

#### Audit Trail
- Complete execution history
- User action tracking
- Change approval workflows
- Compliance reporting

### 7. Email Notification System
- Success/failure notifications
- Execution summaries with details
- Rollback notifications
- Scheduled maintenance alerts

### 8. Security Requirements
- Encrypt database passwords in transit and at rest
- Secure artifact storage access
- API rate limiting and throttling
- Input validation and sanitization
- RBAC for different user roles

### 9. Error Handling & Resilience
- Comprehensive exception handling
- Circuit breaker patterns for external calls
- Retry mechanisms with exponential backoff
- Graceful degradation strategies

## Deliverables

### 1. Core Platform Application
- Spring Boot application with all APIs
- Database schema and migrations
- Configuration management
- Docker containerization

### 2. Tenant Repository Template System
- Automated tenant-specific repository creation from template
- Template customization based on tenant requirements
- Repository initialization with tenant-specific configurations
- Integration with GitHub API for automated repo creation

### 3. Sample Tenant Repository
Create a complete sample repository demonstrating:
- Proper Liquibase SQL changeset structure
- GitHub Actions workflows
- Configuration files
- Documentation and best practices
- Real-world database schema examples

### 4. Documentation
- API documentation (OpenAPI/Swagger)
- Deployment guide
- Tenant onboarding guide
- Troubleshooting guide

## Implementation Guidelines

### Phase 1: Foundation
1. Set up Spring Boot application structure
2. Implement tenant management and authentication
3. Create basic API endpoints
4. Set up database connectivity

### Phase 2: Core Features  
1. Implement changeset execution engine
2. Add GitHub Actions integration
3. Build artifact management
4. Create monitoring and logging

### Phase 3: Advanced Features
1. Add rollback capabilities
2. Implement comprehensive audit trail
3. Build notification system
4. Add advanced security features

### Phase 4: Tenant Repository Template & Sample
1. Build tenant repository template system with automated generation
2. Create comprehensive sample tenant repository (see sample-tenant-repository/ folder)
3. Implement GitHub API integration for automated repo creation
4. Write comprehensive documentation
5. Add deployment automation
6. Performance testing and optimization

## Tenant Repository Template Requirements

### Template Generation System
The platform must include a template generation system that can:

1. **Automatically create tenant-specific repositories** from a base template
2. **Customize configuration files** with tenant-specific details
3. **Initialize GitHub repositories** via GitHub API integration
4. **Set up CI/CD workflows** with tenant-specific secrets and configurations
5. **Generate initial changesets** based on tenant requirements

### Sample Tenant Repository Structure
A complete sample tenant repository has been created in `sample-tenant-repository/` with:

#### Maven Project Structure
- **pom.xml**: Complete Maven configuration with Liquibase plugin
- **Assembly descriptor**: For creating deployment artifacts
- **Dependencies**: Liquibase, PostgreSQL driver, and utilities

#### Database Changesets (SQL-based)
- **Master changelog**: `db.changelog-master.sql` with version includes
- **Version 1.0**: Initial schema (users, products, orders, system config)
- **Version 1.1**: Enhanced features (user profiles, product categories)
- **Version 1.2**: Audit and compliance (audit logs, activity tracking)
- **Environment-specific**: Dev test data, production configurations

#### Configuration Files
- **tenant-config.json**: Complete tenant configuration with all environments
- **liquibase.properties**: Liquibase settings and parameters
- **GitHub workflows**: Development and production deployment pipelines

#### Key Features Demonstrated
- **SQL-based changesets** with proper rollback statements
- **Context-based deployment** (dev, staging, prod)
- **Version labeling** for selective deployments
- **Comprehensive audit logging** with triggers and functions
- **Security best practices** (no passwords in configs)
- **CI/CD integration** with artifact creation and notifications

### Template Customization Points
When generating tenant repositories, customize:

1. **Tenant identifiers**: tenant ID, name, database names
2. **Database connections**: URLs, usernames, schema names
3. **GitHub workflows**: repository names, artifact paths
4. **Notification settings**: email addresses, Slack webhooks
5. **Version numbers**: starting version, release numbering
6. **Environment configurations**: dev, staging, production settings

## Technical Considerations

### Liquibase Best Practices
- Use SQL-based changesets exclusively
- Implement proper changeset naming conventions
- Include rollback scripts where applicable
- Use contexts and labels for environment-specific changes

### Performance Optimization
- Async processing for long-running operations
- Connection pooling optimization
- Caching strategies for frequently accessed data
- Database query optimization

### Scalability Requirements
- Support for multiple concurrent executions
- Horizontal scaling capabilities
- Load balancing considerations
- Resource management and limits

## Success Criteria
- Successful tenant onboarding and repository creation
- Automated CI/CD pipeline execution
- Reliable changeset execution across environments
- Comprehensive audit and monitoring capabilities
- Production-ready security and error handling
- Complete documentation and sample implementations

This platform should provide enterprise-grade database change management with full observability, security, and automation capabilities.

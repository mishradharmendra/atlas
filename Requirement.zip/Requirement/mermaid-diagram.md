# AWS Data Processing Pipeline - Mermaid.js Format

## Mermaid.js Diagram Code

### Main Flowchart Diagram

```mermaid
flowchart LR
    %% Define styling classes
    classDef userClass fill:#E3F2FD,stroke:#1976D2,stroke-width:2px,color:#000
    classDef ingestClass fill:#E8F5E8,stroke:#4CAF50,stroke-width:2px,color:#000
    classDef processClass fill:#FFF3E0,stroke:#FF9800,stroke-width:2px,color:#000
    classDef storageClass fill:#F3E5F5,stroke:#9C27B0,stroke-width:2px,color:#000
    classDef securityClass fill:#FFEBEE,stroke:#F44336,stroke-width:2px,color:#000
    classDef monitorClass fill:#F5F5F5,stroke:#616161,stroke-width:2px,color:#000
    classDef decisionClass fill:#FFFDE7,stroke:#FBC02D,stroke-width:3px,color:#000

    %% Layer 1: Data Ingestion
    A[👤 User] --> B[☁️ CloudFront/ALB<br/>Traffic Distribution]
    B --> C[🪣 S3 Raw Bucket<br/>Data Ingestion]
    
    %% Layer 2: Event Processing
    C --> D[⚡ Lambda Validator<br/>Data Validation]
    C -.-> E[📧 S3 Event Notification<br/>Trigger Events]
    E --> D
    D --> F[🔔 CloudWatch Events<br/>Event Monitoring]
    
    %% Layer 3: Validation Decision
    D --> G{🔍 Data Valid?}
    
    %% Layer 4: Conditional Storage
    G -->|❌ Invalid| H[🗑️ S3 Error Bucket<br/>Invalid Data Storage]
    G -->|✅ Valid| I[🪣 S3 Validated Bucket<br/>Clean Data Storage]
    
    %% Layer 5: Data Processing Pipeline
    I --> J[⚡ Lambda Trigger<br/>Processing Initiator]
    
    %% Layer 6: Security & API
    K[🔐 AWS Secrets Manager<br/>Credential Storage] --> L[🔌 DataSource API<br/>Data Access Layer]
    M[🔑 AWS KMS<br/>Key Management] --> K
    J --> L
    
    %% Layer 7: Orchestration
    L --> N[🎯 AWS Step Functions<br/>Workflow Orchestration]
    N --> O[🖥️ EMR/ECS Cluster<br/>Data Processing]
    
    %% Layer 8: Final Storage
    O --> P[🏛️ Delta Lake<br/>Data Lake Storage]
    O --> Q[🗄️ Amazon RDS<br/>Relational Database]
    
    %% Layer 9: Monitoring
    P --> R[📊 CloudWatch<br/>Metrics & Alarms]
    Q --> R
    F --> R
    
    %% Apply styling classes
    class A userClass
    class B,C,I ingestClass
    class D,J processClass
    class E,F,R monitorClass
    class G decisionClass
    class H,P,Q storageClass
    class K,M,L securityClass
    class N,O processClass
```

### Alternative Simplified Version

```mermaid
graph LR
    A[👤 User] --> B[☁️ CloudFront]
    B --> C[🪣 S3 Raw]
    C --> D[⚡ Lambda Validator]
    D --> E{Valid?}
    E -->|No| F[❌ S3 Error]
    E -->|Yes| G[✅ S3 Validated]
    G --> H[⚡ Lambda Trigger]
    H --> I[🔌 API]
    I --> J[🎯 Step Functions]
    J --> K[🖥️ EMR Cluster]
    K --> L[🏛️ Delta Lake]
    K --> M[🗄️ RDS]
    L --> N[📊 CloudWatch]
    M --> N
    
    %% Security components
    O[🔐 Secrets] --> I
    P[🔑 KMS] --> O
    
    %% Event flow
    C -.-> Q[📧 Events]
    Q --> D
    D --> R[🔔 CW Events]
    R --> N
    
    %% Styling
    classDef primary fill:#e1f5fe
    classDef security fill:#fce4ec
    classDef storage fill:#f3e5f5
    classDef compute fill:#fff3e0
    
    class A,B,C,G,L,M storage
    class D,H,J,K compute
    class O,P security
    class E primary
```

### Detailed Component Diagram

```mermaid
flowchart TD
    subgraph "AWS Data Processing Pipeline"
        subgraph "Data Ingestion Layer"
            A1[👤 User Input]
            A2[☁️ AWS CloudFront/ALB]
            A3[🪣 S3 Raw Bucket]
        end
        
        subgraph "Event Processing Layer"
            B1[📧 S3 Event Notifications]
            B2[⚡ AWS Lambda Validator]
            B3[🔔 CloudWatch Events]
        end
        
        subgraph "Decision Layer"
            C1{🔍 Validation Result}
        end
        
        subgraph "Storage Layer"
            D1[❌ S3 Error Bucket]
            D2[✅ S3 Validated Bucket]
        end
        
        subgraph "Processing Layer"
            E1[⚡ Lambda Trigger Function]
            E2[🔌 DataSource API]
        end
        
        subgraph "Security Layer"
            F1[🔐 AWS Secrets Manager]
            F2[🔑 AWS KMS]
        end
        
        subgraph "Orchestration Layer"
            G1[🎯 AWS Step Functions]
            G2[🖥️ EMR/ECS Cluster]
        end
        
        subgraph "Data Storage Layer"
            H1[🏛️ Delta Lake]
            H2[🗄️ Amazon RDS]
        end
        
        subgraph "Monitoring Layer"
            I1[📊 CloudWatch Metrics]
            I2[⚠️ CloudWatch Alarms]
        end
    end
    
    %% Connections
    A1 --> A2 --> A3
    A3 --> B2
    A3 -.-> B1
    B1 --> B2
    B2 --> C1
    B2 --> B3
    C1 -->|Invalid| D1
    C1 -->|Valid| D2
    D2 --> E1
    E1 --> E2
    F1 --> E2
    F2 --> F1
    E2 --> G1
    G1 --> G2
    G2 --> H1
    G2 --> H2
    H1 --> I1
    H2 --> I1
    B3 --> I2
    I1 --> I2
```

### Sequence Diagram Version

```mermaid
sequenceDiagram
    participant U as 👤 User
    participant CF as ☁️ CloudFront
    participant S3R as 🪣 S3 Raw
    participant SNS as 📧 S3 Events
    participant LV as ⚡ Lambda Validator
    participant S3V as ✅ S3 Validated
    participant S3E as ❌ S3 Error
    participant LT as ⚡ Lambda Trigger
    participant API as 🔌 DataSource API
    participant SF as 🎯 Step Functions
    participant EMR as 🖥️ EMR Cluster
    participant DL as 🏛️ Delta Lake
    participant RDS as 🗄️ RDS
    participant CW as 📊 CloudWatch
    
    U->>CF: Upload Data
    CF->>S3R: Store Raw Data
    S3R->>SNS: Trigger Event
    SNS->>LV: Invoke Validation
    
    alt Data is Valid
        LV->>S3V: Store Valid Data
        S3V->>LT: Trigger Processing
        LT->>API: Call DataSource API
        API->>SF: Start Workflow
        SF->>EMR: Process Data
        EMR->>DL: Store in Data Lake
        EMR->>RDS: Store in Database
        DL->>CW: Send Metrics
        RDS->>CW: Send Metrics
    else Data is Invalid
        LV->>S3E: Store Error Data
        S3E->>CW: Log Error Metrics
    end
    
    LV->>CW: Send Processing Metrics
```

## Usage Instructions

### 1. **In GitHub/GitLab**
Simply paste the mermaid code blocks into your markdown files. They will render automatically.

### 2. **In Notion**
Use the `/code` block and select "Mermaid" as the language.

### 3. **In Confluence**
Install the Mermaid plugin and use mermaid code blocks.

### 4. **In VS Code**
Install the "Mermaid Preview" extension and preview .md files.

### 5. **Online Editors**
- Mermaid Live Editor: https://mermaid.live/
- Draw.io (supports Mermaid import)
- Lucidchart (can import Mermaid)

### 6. **Export Options**
From Mermaid Live Editor, you can export to:
- PNG
- SVG
- PDF

## Customization Options

### Color Themes
You can modify the `classDef` sections to change colors:

```mermaid
classDef awsBlue fill:#232F3E,stroke:#FF9900,stroke-width:2px,color:#fff
classDef awsOrange fill:#FF9900,stroke:#232F3E,stroke-width:2px,color:#000
```

### Icons
The emojis can be replaced with:
- Font Awesome icons (if supported)
- AWS service names
- Custom Unicode symbols

### Layout Direction
- `LR` = Left to Right
- `TD` = Top Down
- `RL` = Right to Left
- `BT` = Bottom to Top

This Mermaid.js format gives you a clean, version-controllable diagram that can be easily shared and embedded in documentation platforms.

# Production-Ready Data Pipeline Component Diagram

## High-Level Architecture Flow

```mermaid
graph TB
    %% External Systems
    User[👤 User] 
    BoxCom[📦 Box.com]
    
    %% API Layer
    APIGateway[🚪 API Gateway<br/>Rate Limiting & Auth]
    
    %% Ingestion Layer
    BoxWebhook[🔔 Box Webhook<br/>File Upload Events]
    IngestionLambda[⚡ File Ingestion Lambda<br/>Download & Transfer]
    
    %% Storage Layer
    S3Raw[🗄️ S3 Raw Bucket<br/>Initial File Storage]
    S3Valid[✅ S3 Valid Bucket<br/>Validated Files]
    S3Invalid[❌ S3 Invalid Bucket<br/>Failed Validation]
    S3Processing[⚙️ S3 Processing Bucket<br/>Work in Progress]
    S3Archive[📚 S3 Archive Bucket<br/>Completed Files]
    
    %% Validation Layer
    ValidationLambda[🔍 Validation Lambda<br/>Schema & Quality Checks]
    StepFunctions[🔄 Step Functions<br/>Workflow Orchestration]
    
    %% Event & Message Layer
    EventBridge[📡 EventBridge<br/>Event Routing]
    SQSQueue[📬 SQS Queue<br/>Message Buffer]
    DLQ[💀 Dead Letter Queue<br/>Failed Messages]
    SNSTopic[📢 SNS Topic<br/>Fan-out Notifications]
    S3Event[📧 S3 Event Notifications]
    DBTriggerLambda[⚡ Databricks Trigger Lambda]
    
    %% Processing Layer
    DatabricksCluster[🧊 Databricks Cluster<br/>Auto-scaling ETL]
    DeltaLake[🏞️ Delta Lake<br/>Data Lake Storage]
    SparkJobs[⚡ Spark Jobs<br/>Parallel Processing]
    
    %% PDF Generation
    PDFService[📄 PDF Generation Service<br/>ECS/EKS Microservice]
    PDFQueue[📬 PDF Queue<br/>Generation Tasks]
    
    %% Output Layer
    BoxUploadLambda[📤 Box Upload Lambda<br/>Deliver PDFs]
    
    %% Observability Stack
    CloudWatch[📊 CloudWatch<br/>Logs & Metrics]
    XRay[🔍 X-Ray<br/>Distributed Tracing]
    DataDog[📈 DataDog/NewRelic<br/>APM & Monitoring]
    
    %% Retry & Fault Tolerance
    RetryHandler[🔄 Retry Handler<br/>Failed Job Recovery]
    CircuitBreaker[🛡️ Circuit Breaker<br/>Service Protection]
    HealthChecks[❤️ Health Checks<br/>Service Monitoring]
    
    %% Flow Connections
    User --> BoxCom
    BoxCom --> BoxWebhook
    BoxWebhook --> APIGateway
    APIGateway --> IngestionLambda
    IngestionLambda --> S3Raw
    
    S3Raw --> ValidationLambda
    ValidationLambda --> S3Valid
    ValidationLambda --> S3Invalid
    ValidationLambda --> StepFunctions
    
    S3Valid --> S3Event
    S3Event --> DBTriggerLambda
    DBTriggerLambda --> DatabricksCluster
    
    DatabricksCluster --> DeltaLake
    DatabricksCluster --> SparkJobs
    SparkJobs --> S3Processing
    SparkJobs --> PDFQueue
    
    PDFQueue --> PDFService
    PDFService --> S3Archive
    S3Archive --> BoxUploadLambda
    BoxUploadLambda --> BoxCom
    
    %% Error Handling
    SQSQueue --> DLQ
    DLQ --> RetryHandler
    RetryHandler --> SQSQueue
    
    %% Observability Connections
    IngestionLambda -.-> CloudWatch
    ValidationLambda -.-> CloudWatch
    DatabricksCluster -.-> CloudWatch
    PDFService -.-> CloudWatch
    
    IngestionLambda -.-> XRay
    ValidationLambda -.-> XRay
    PDFService -.-> XRay
    
    CloudWatch -.-> DataDog
    XRay -.-> DataDog
    
    %% Health Monitoring
    IngestionLambda -.-> HealthChecks
    ValidationLambda -.-> HealthChecks
    PDFService -.-> HealthChecks
    DatabricksCluster -.-> HealthChecks
    
    %% Circuit Breaker Protection
    IngestionLambda -.-> CircuitBreaker
    PDFService -.-> CircuitBreaker
    BoxUploadLambda -.-> CircuitBreaker
    
    %% Styling
    classDef userClass fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    classDef storageClass fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    classDef processClass fill:#e8f5e8,stroke:#1b5e20,stroke-width:2px
    classDef observeClass fill:#fff3e0,stroke:#e65100,stroke-width:2px
    classDef errorClass fill:#ffebee,stroke:#b71c1c,stroke-width:2px
    
    class User,BoxCom userClass
    class S3Raw,S3Valid,S3Invalid,S3Processing,S3Archive,DeltaLake storageClass
    class IngestionLambda,ValidationLambda,DatabricksCluster,PDFService,BoxUploadLambda,DBTriggerLambda processClass
    class CloudWatch,XRay,DataDog,HealthChecks observeClass
    class DLQ,RetryHandler,CircuitBreaker errorClass
```

## Detailed Component Interaction Flow

```mermaid
sequenceDiagram
    participant U as 👤 User
    participant B as 📦 Box.com
    participant AG as 🚪 API Gateway
    participant IL as ⚡ Ingestion Lambda
    participant S3R as 🗄️ S3 Raw
    participant VL as 🔍 Validation Lambda
    participant S3V as ✅ S3 Valid
    participant S3E as 📧 S3 Events
    participant T as ⚡ Databricks Trigger Lambda
    participant DB as 🧊 Databricks
    participant DL as 🏞️ Delta Lake
    participant PS as 📄 PDF Service
    participant S3A as 📚 S3 Archive
    participant BUL as 📤 Box Upload Lambda
    participant CW as 📊 CloudWatch
    participant RH as 🔄 Retry Handler
    
    U->>B: Upload Excel File
    B->>AG: Webhook: FILE.UPLOADED
    AG->>IL: Process Upload Event
    
    IL->>B: Download File
    IL->>S3R: Store Raw File
    IL->>CW: Log Success/Failure
    
    S3R->>VL: S3 Event Trigger
    VL->>VL: Validate File Format
    VL->>VL: Check Schema
    VL->>VL: Data Quality Checks
    
    alt File Valid
        VL->>S3V: Store Valid File
        VL->>CW: Log Validation Success
        S3V->>S3E: Object Created Event
        S3E->>T: Invoke Trigger
    else File Invalid
        VL->>S3: Store in Invalid Bucket
        VL->>CW: Log Validation Failure
    end
    
    T->>DB: Start ETL Job
    DB->>S3V: Read Valid File
    DB->>DL: Store Structured Data
    
    loop For Each Row
        DB->>PS: Generate PDF Request
        PS->>PS: Create PDF from Row Data
        PS->>S3A: Store Generated PDF
        PS->>CW: Log PDF Generation
        
        alt PDF Generation Fails
            PS->>SQS: Send to DLQ
            SQS->>RH: Retry Handler
            RH->>PS: Retry PDF Generation
        end
    end
    
    S3A->>BUL: PDF Files Ready
    BUL->>B: Upload PDFs to Box
    BUL->>CW: Log Upload Status
    
    B->>U: Notification: Files Processed
```

## Retry Mechanism Detail

```mermaid
graph TB
    %% Main Processing Flow
    ProcessingJob[⚙️ Processing Job]
    Success[✅ Success]
    Failure[❌ Failure]
    
    %% Retry Components
    ImmediateRetry[🔄 Immediate Retry<br/>3 attempts, 1s interval]
    DelayedRetry[⏳ Delayed Retry<br/>Exponential Backoff]
    DLQProcessor[💀 DLQ Processor<br/>Failed Message Handler]
    ManualRetry[👤 Manual Retry<br/>Dashboard Trigger]
    
    %% Retry Decision Logic
    RetryDecision{🤔 Retry Decision}
    RetryCounter{📊 Retry Count}
    ErrorType{🔍 Error Type}
    
    %% Final States
    PermanentFailure[🚫 Permanent Failure]
    AlertTeam[🚨 Alert Team]
    
    %% Flow
    ProcessingJob --> Success
    ProcessingJob --> Failure
    
    Failure --> ErrorType
    ErrorType -->|Transient| RetryDecision
    ErrorType -->|Permanent| PermanentFailure
    
    RetryDecision --> RetryCounter
    RetryCounter -->|< 3| ImmediateRetry
    RetryCounter -->|>= 3| DelayedRetry
    
    ImmediateRetry --> ProcessingJob
    DelayedRetry --> ProcessingJob
    
    DelayedRetry -->|Max Retries| DLQProcessor
    DLQProcessor --> ManualRetry
    ManualRetry --> ProcessingJob
    
    PermanentFailure --> AlertTeam
    DLQProcessor --> AlertTeam
    
    %% Styling
    classDef successClass fill:#e8f5e8,stroke:#1b5e20,stroke-width:2px
    classDef errorClass fill:#ffebee,stroke:#b71c1c,stroke-width:2px
    classDef retryClass fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px
    classDef alertClass fill:#fff8e1,stroke:#f57f17,stroke-width:2px
    
    class Success successClass
    class Failure,PermanentFailure errorClass
    class ImmediateRetry,DelayedRetry,DLQProcessor,ManualRetry retryClass
    class AlertTeam alertClass
```

## Observability Architecture

```mermaid
graph TB
    %% Application Components
    subgraph "Application Layer"
        Lambda[⚡ Lambda Functions]
        Databricks[🧊 Databricks]
        PDFService[📄 PDF Service]
        APIGateway[🚪 API Gateway]
    end
    
    %% Data Collection Layer
    subgraph "Data Collection"
        CloudWatchAgent[📊 CloudWatch Agent]
        XRayAgent[🔍 X-Ray Agent]
        OpenTelemetry[🔄 OpenTelemetry SDK]
        CustomMetrics[📈 Custom Metrics]
    end
    
    %% Storage & Processing
    subgraph "Storage & Processing"
        CloudWatchLogs[📝 CloudWatch Logs]
        CloudWatchMetrics[📊 CloudWatch Metrics]
        XRayTraces[🗺️ X-Ray Traces]
        S3Logs[🗄️ S3 Log Storage]
    end
    
    %% Analytics & Visualization
    subgraph "Analytics & Visualization"
        DataDog[📈 DataDog]
        Grafana[📊 Grafana]
        Kibana[🔍 Kibana]
        QuickSight[📊 QuickSight]
    end
    
    %% Alerting & Notification
    subgraph "Alerting"
        CloudWatchAlarms[🚨 CloudWatch Alarms]
        PagerDuty[📱 PagerDuty]
        Slack[💬 Slack]
        Email[📧 Email]
    end
    
    %% Flow Connections
    Lambda --> CloudWatchAgent
    Lambda --> XRayAgent
    Lambda --> OpenTelemetry
    
    Databricks --> CloudWatchAgent
    Databricks --> CustomMetrics
    
    PDFService --> OpenTelemetry
    PDFService --> CustomMetrics
    
    APIGateway --> CloudWatchLogs
    APIGateway --> CloudWatchMetrics
    
    CloudWatchAgent --> CloudWatchLogs
    CloudWatchAgent --> CloudWatchMetrics
    XRayAgent --> XRayTraces
    OpenTelemetry --> CloudWatchMetrics
    OpenTelemetry --> XRayTraces
    CustomMetrics --> CloudWatchMetrics
    
    CloudWatchLogs --> S3Logs
    CloudWatchLogs --> DataDog
    CloudWatchMetrics --> DataDog
    XRayTraces --> DataDog
    
    CloudWatchMetrics --> Grafana
    CloudWatchLogs --> Kibana
    CloudWatchMetrics --> QuickSight
    
    CloudWatchMetrics --> CloudWatchAlarms
    CloudWatchAlarms --> PagerDuty
    CloudWatchAlarms --> Slack
    CloudWatchAlarms --> Email
    
    DataDog --> PagerDuty
    DataDog --> Slack
```

## Security Architecture

```mermaid
graph TB
    %% External Access
    Internet[🌐 Internet]
    User[👤 User]
    
    %% Edge Security
    CloudFront[☁️ CloudFront CDN<br/>DDoS Protection]
    WAF[🛡️ Web Application Firewall<br/>SQL Injection, XSS Protection]
    
    %% Network Security
    subgraph "VPC - Private Network"
        subgraph "Public Subnet"
            NATGateway[🌐 NAT Gateway]
            LoadBalancer[⚖️ Application Load Balancer]
        end
        
        subgraph "Private Subnet"
            Lambda[⚡ Lambda Functions]
            ECS[🐳 ECS Containers]
            Databricks[🧊 Databricks Workspace]
        end
        
        SecurityGroups[🔒 Security Groups<br/>Port-level Access Control]
        NACLs[🚧 Network ACLs<br/>Subnet-level Filtering]
    end
    
    %% Identity & Access Management
    subgraph "IAM Security"
        IAMRoles[👥 IAM Roles<br/>Least Privilege Access]
        AssumeRole[🔄 Cross-Service Roles]
        MFA[🔐 Multi-Factor Authentication]
        ServiceAccounts[🤖 Service Accounts]
    end
    
    %% Data Security
    subgraph "Data Protection"
        KMS[🔑 AWS KMS<br/>Encryption Key Management]
        S3Encryption[🔒 S3 Server-Side Encryption]
        TransitEncryption[🚛 TLS 1.3 in Transit]
        SecretsManager[🗝️ AWS Secrets Manager]
    end
    
    %% Compliance & Monitoring
    subgraph "Compliance & Audit"
        CloudTrail[📋 AWS CloudTrail<br/>API Audit Logging]
        ConfigRules[📏 AWS Config<br/>Compliance Rules]
        GuardDuty[🛡️ Amazon GuardDuty<br/>Threat Detection]
        Inspector[🔍 Amazon Inspector<br/>Vulnerability Assessment]
    end
    
    %% Flow Connections
    Internet --> CloudFront
    User --> CloudFront
    CloudFront --> WAF
    WAF --> LoadBalancer
    
    LoadBalancer --> Lambda
    LoadBalancer --> ECS
    
    Lambda --> Databricks
    ECS --> Databricks
    
    SecurityGroups -.-> Lambda
    SecurityGroups -.-> ECS
    SecurityGroups -.-> Databricks
    NACLs -.-> LoadBalancer
    
    Lambda -.-> IAMRoles
    ECS -.-> IAMRoles
    Databricks -.-> IAMRoles
    IAMRoles -.-> AssumeRole
    
    Lambda -.-> KMS
    ECS -.-> KMS
    Databricks -.-> KMS
    KMS -.-> S3Encryption
    
    Lambda -.-> SecretsManager
    ECS -.-> SecretsManager
    
    IAMRoles -.-> CloudTrail
    Lambda -.-> CloudTrail
    ECS -.-> CloudTrail
    
    Lambda -.-> GuardDuty
    ECS -.-> GuardDuty
    
    %% Styling
    classDef securityClass fill:#ffebee,stroke:#b71c1c,stroke-width:2px
    classDef networkClass fill:#e8eaf6,stroke:#3f51b5,stroke-width:2px
    classDef dataClass fill:#e0f2f1,stroke:#00695c,stroke-width:2px
    classDef complianceClass fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    
    class WAF,SecurityGroups,NACLs,GuardDuty,Inspector securityClass
    class CloudFront,LoadBalancer,NATGateway networkClass
    class KMS,S3Encryption,TransitEncryption,SecretsManager dataClass
    class CloudTrail,ConfigRules complianceClass
```

## Cost Optimization Strategy

```mermaid
graph TB
    %% Cost Monitoring
    subgraph "Cost Monitoring"
        CostExplorer[💰 AWS Cost Explorer]
        Budgets[📊 AWS Budgets]
        CostAlerts[🚨 Cost Alerts]
    end
    
    %% Resource Optimization
    subgraph "Resource Optimization"
        Lambda[⚡ Lambda<br/>Right-sizing Memory]
        DatabricksSpot[🧊 Databricks<br/>Spot Instances]
        S3Lifecycle[🗄️ S3<br/>Lifecycle Policies]
        AutoScaling[📈 Auto Scaling<br/>Dynamic Capacity]
    end
    
    %% Storage Optimization
    subgraph "Storage Cost Optimization"
        S3IA[📦 S3 Infrequent Access]
        S3Glacier[🏔️ S3 Glacier]
        S3DeepArchive[🗄️ S3 Deep Archive]
        DataCompression[🗜️ Data Compression]
    end
    
    %% Compute Optimization
    subgraph "Compute Cost Optimization"
        SpotInstances[💡 EC2 Spot Instances]
        ReservedInstances[🔒 Reserved Instances]
        AutoTermination[⏰ Auto Termination]
        ResourceTagging[🏷️ Resource Tagging]
    end
    
    %% Optimization Actions
    CostExplorer --> S3Lifecycle
    CostExplorer --> AutoScaling
    Budgets --> CostAlerts
    CostAlerts --> AutoTermination
    
    Lambda --> AutoScaling
    DatabricksSpot --> SpotInstances
    S3Lifecycle --> S3IA
    S3Lifecycle --> S3Glacier
    S3Lifecycle --> S3DeepArchive
    
    AutoScaling --> ReservedInstances
    SpotInstances --> AutoTermination
    ResourceTagging --> CostExplorer
    
    %% Styling
    classDef costClass fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    classDef optimizeClass fill:#e8f5e8,stroke:#1b5e20,stroke-width:2px
    classDef storageClass fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px
    classDef computeClass fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    
    class CostExplorer,Budgets,CostAlerts costClass
    class Lambda,DatabricksSpot,S3Lifecycle,AutoScaling optimizeClass
    class S3IA,S3Glacier,S3DeepArchive,DataCompression storageClass
    class SpotInstances,ReservedInstances,AutoTermination,ResourceTagging computeClass
```

## Technology Stack Icons Reference

### Core AWS Services
- 🚪 **API Gateway**: Centralized API management with rate limiting
- ⚡ **Lambda**: Serverless compute for event processing
- 🗄️ **S3**: Object storage for all file types
- 📡 **EventBridge**: Event routing and filtering
- 📬 **SQS**: Message queuing with retry capabilities
- 📢 **SNS**: Push notifications and fan-out messaging
- 🔄 **Step Functions**: Workflow orchestration
- 🔑 **KMS**: Encryption key management
- 👥 **IAM**: Identity and access management

### Processing & Analytics
- 🧊 **Databricks**: Unified analytics platform
- 🏞️ **Delta Lake**: Data lake storage with ACID transactions
- ⚡ **Spark**: Distributed data processing
- 🐳 **ECS/EKS**: Container orchestration
- 📄 **PDF Service**: Custom microservice for PDF generation

### Observability & Monitoring
- 📊 **CloudWatch**: AWS native monitoring
- 🔍 **X-Ray**: Distributed tracing
- 📈 **DataDog**: Third-party APM
- 📊 **Grafana**: Visualization dashboards
- 🚨 **Alarms**: Automated alerting

### Security & Compliance
- 🛡️ **WAF**: Web application firewall
- 🔒 **Security Groups**: Virtual firewalls
- 📋 **CloudTrail**: API audit logging
- 🛡️ **GuardDuty**: Threat detection
- 🔍 **Inspector**: Vulnerability assessment

### External Integrations
- 📦 **Box.com**: File storage and sharing
- 👤 **User**: End users of the system
- 🌐 **Internet**: External network connectivity

This comprehensive architecture ensures production-ready reliability, scalability, and observability for your data pipeline.

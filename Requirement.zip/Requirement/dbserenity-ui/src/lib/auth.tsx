'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { DBSerenityAPI, LoginRequest, LoginResponse } from './api';

export interface User {
  clientId: string;
  tenantId: string;
  scopes: string[];
  role: 'admin' | 'tenant';
  tenantName?: string;
  email?: string;
}

export class AuthService {
  private static readonly TOKEN_KEY = 'access_token';
  private static readonly USER_KEY = 'user_info';

  // Login with client credentials
  static async login(clientId: string, clientSecret: string): Promise<User> {
    const loginRequest: LoginRequest = {
      grant_type: 'client_credentials',
      client_id: clientId,
      client_secret: clientSecret,
    };

    try {
      const response: LoginResponse = await DBSerenityAPI.login(loginRequest);
      
      // Store token
      if (typeof window !== 'undefined') {
        localStorage.setItem(this.TOKEN_KEY, response.access_token);
      }
      
      // Determine user role based on scopes or tenant ID
      const scopes = response.scope ? response.scope.split(' ') : [];
      const role = this.determineRole(scopes, response.tenant_id);
      
      // Create user object
      const user: User = {
        clientId,
        tenantId: response.tenant_id,
        scopes,
        role,
      };

      // Store user info
      if (typeof window !== 'undefined') {
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
      }
      
      return user;
    } catch (error: any) {
      console.error('Login failed:', error);
      throw new Error(error.response?.data?.message || 'Login failed');
    }
  }

  // Determine user role based on scopes and tenant ID
  private static determineRole(scopes: string[], tenantId: string): 'admin' | 'tenant' {
    // Platform admin tenant or admin scopes
    if (tenantId === 'platform-admin' || 
        scopes.includes('admin:read') || 
        scopes.includes('admin:write')) {
      return 'admin';
    }
    return 'tenant';
  }

  // Get current user
  static getCurrentUser(): User | null {
    if (typeof window === 'undefined') return null;
    try {
      const userJson = localStorage.getItem(this.USER_KEY);
      return userJson ? JSON.parse(userJson) : null;
    } catch {
      return null;
    }
  }

  // Get current token
  static getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(this.TOKEN_KEY);
  }

  // Check if user is authenticated
  static isAuthenticated(): boolean {
    const token = this.getToken();
    const user = this.getCurrentUser();
    return !!(token && user);
  }

  // Logout
  static logout(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
      window.location.href = '/login';
    }
  }
}

// Auth context
interface AuthContextType {
  user: User | null;
  login: (clientId: string, clientSecret: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on mount
    const currentUser = AuthService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
    setIsLoading(false);
  }, []);

  const login = async (clientId: string, clientSecret: string) => {
    setIsLoading(true);
    try {
      const user = await AuthService.login(clientId, clientSecret);
      setUser(user);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    AuthService.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

import axios, { AxiosInstance, AxiosResponse } from 'axios';

// API Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080/api';

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear token and redirect to login
      localStorage.removeItem('access_token');
      localStorage.removeItem('user_info');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Types
export interface LoginRequest {
  grant_type: string;
  client_id: string;
  client_secret: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  scope: string;
  tenant_id: string;
}

export interface TenantCreateRequest {
  tenantId: string;
  tenantName: string;
  contactEmail: string;
  description?: string;
  githubOrg?: string;
  githubRepo?: string;
  generateClientCredentials?: boolean;
  createGitHubRepo?: boolean;
  environments?: TenantEnvironmentRequest[];
}

export interface TenantEnvironmentRequest {
  environmentName: 'dev' | 'staging' | 'prod';
  jdbcUrl: string;
  username: string;
  schemaName?: string;
  contexts?: string[];
  labels?: string[];
}

export interface TenantResponse {
  id: number;
  uuid: string;
  tenantId: string;
  tenantName: string;
  description?: string;
  contactEmail: string;
  githubOrg?: string;
  githubRepo?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  environments?: TenantEnvironmentResponse[];
  clientCredentials?: ClientCredentialsResponse[];
  metadata?: Record<string, any>;
}

export interface TenantEnvironmentResponse {
  id: number;
  environmentName: string;
  jdbcUrl: string;
  username: string;
  schemaName?: string;
  contexts?: string[];
  labels?: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ClientCredentialsResponse {
  id: number;
  clientId: string;
  scopes: string[];
  isActive: boolean;
  expiresAt?: string;
  lastUsedAt?: string;
  createdAt: string;
}

export interface ChangesetExecutionRequest {
  clientId: string;
  clientSecret: string;
  artifactUrl: string;
  environment: 'dev' | 'staging' | 'prod';
  mode: 'dry-run' | 'execute';
  databasePassword: string;
  executionOptions?: {
    rollbackOnFailure?: boolean;
    notificationEmail?: string;
    timeoutMinutes?: number;
    contexts?: string;
    labels?: string;
    parameters?: Record<string, string>;
  };
}

export interface ChangesetExecutionResponse {
  executionId: string;
  status: string;
  tenantId: string;
  environment: string;
  mode: string;
  artifactUrl: string;
  startedAt: string;
  completedAt?: string;
  durationMs?: number;
  message?: string;
  summary?: ExecutionSummary;
  logs?: string[];
  metadata?: Record<string, any>;
}

export interface ExecutionSummary {
  changesetsExecuted?: number;
  changesetsSkipped?: number;
  changesetsFailed?: number;
  sqlStatementsExecuted?: number;
  databaseVersion?: string;
  liquibaseVersion?: string;
}

export interface TenantStatsResponse {
  totalTenants: number;
  activeTenants: number;
  inactiveTenants: number;
  tenantsWithGitHubRepo: number;
}

export interface RepositoryTemplateRequest {
  tenantId: string;
  includeGitHubWorkflows?: boolean;
  includeSampleData?: boolean;
  includeDocumentation?: boolean;
  templateVersion?: string;
}

export interface RepositoryTemplateResponse {
  tenantId: string;
  tenantName: string;
  success: boolean;
  repositoryPath?: string;
  message: string;
  errorMessage?: string;
  generatedAt: string;
  repositoryInfo?: {
    artifactId: string;
    version: string;
    schemaName: string;
    environments: string[];
    generatedFiles: string[];
    changesetCount: number;
  };
}

// API Functions
export class DBSerenityAPI {
  // Authentication
  static async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response: AxiosResponse<LoginResponse> = await api.post('/v1/auth/token', credentials);
    return response.data;
  }

  static async validateToken(token: string): Promise<any> {
    const response = await api.post('/v1/auth/validate', {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
  }

  // Tenant Management
  static async createTenant(tenant: TenantCreateRequest): Promise<any> {
    const response = await api.post('/v1/tenants', tenant);
    return response.data;
  }

  static async getTenant(tenantId: string): Promise<TenantResponse> {
    const response: AxiosResponse<TenantResponse> = await api.get(`/v1/tenants/${tenantId}`);
    return response.data;
  }

  static async getAllTenants(page = 0, size = 20): Promise<any> {
    const response = await api.get(`/v1/tenants?page=${page}&size=${size}`);
    return response.data;
  }

  static async updateTenant(tenantId: string, updates: Partial<TenantCreateRequest>): Promise<TenantResponse> {
    const response: AxiosResponse<TenantResponse> = await api.put(`/v1/tenants/${tenantId}`, updates);
    return response.data;
  }

  static async deleteTenant(tenantId: string): Promise<void> {
    await api.delete(`/v1/tenants/${tenantId}`);
  }

  static async activateTenant(tenantId: string): Promise<TenantResponse> {
    const response: AxiosResponse<TenantResponse> = await api.post(`/v1/tenants/${tenantId}/activate`);
    return response.data;
  }

  static async deactivateTenant(tenantId: string): Promise<TenantResponse> {
    const response: AxiosResponse<TenantResponse> = await api.post(`/v1/tenants/${tenantId}/deactivate`);
    return response.data;
  }

  static async getTenantStats(): Promise<TenantStatsResponse> {
    const response: AxiosResponse<TenantStatsResponse> = await api.get('/v1/tenants/stats');
    return response.data;
  }

  // Changeset Execution
  static async executeChangesets(request: ChangesetExecutionRequest): Promise<ChangesetExecutionResponse> {
    const response: AxiosResponse<ChangesetExecutionResponse> = await api.post('/v1/changesets/execute', request);
    return response.data;
  }

  static async validateChangesets(request: ChangesetExecutionRequest): Promise<ChangesetExecutionResponse> {
    const response: AxiosResponse<ChangesetExecutionResponse> = await api.post('/v1/changesets/validate', request);
    return response.data;
  }

  static async getExecutionStatus(executionId: string): Promise<ChangesetExecutionResponse> {
    const response: AxiosResponse<ChangesetExecutionResponse> = await api.get(`/v1/changesets/status/${executionId}`);
    return response.data;
  }

  static async getExecutionHistory(page = 0, size = 20, environment?: string, status?: string): Promise<any> {
    const params = new URLSearchParams({
      page: page.toString(),
      size: size.toString(),
    });
    if (environment) params.append('environment', environment);
    if (status) params.append('status', status);
    
    const response = await api.get(`/v1/changesets/history?${params}`);
    return response.data;
  }

  // Repository Templates
  static async generateRepositoryTemplate(request: RepositoryTemplateRequest): Promise<RepositoryTemplateResponse> {
    const response: AxiosResponse<RepositoryTemplateResponse> = await api.post('/v1/repository-templates/generate', request);
    return response.data;
  }

  static async generateTemplateForTenant(): Promise<RepositoryTemplateResponse> {
    const response: AxiosResponse<RepositoryTemplateResponse> = await api.post('/v1/repository-templates/generate-for-tenant');
    return response.data;
  }

  static async listGeneratedRepositories(): Promise<string[]> {
    const response: AxiosResponse<string[]> = await api.get('/v1/repository-templates/list');
    return response.data;
  }

  // Health and Info
  static async getHealth(): Promise<any> {
    const response = await api.get('/actuator/health');
    return response.data;
  }

  static async getInfo(): Promise<any> {
    const response = await api.get('/actuator/info');
    return response.data;
  }
}

export default api;

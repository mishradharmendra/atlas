import React from 'react';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'error' | 'warning' | 'info' | 'default';
  size?: 'sm' | 'md' | 'lg';
  icon?: LucideIcon;
  className?: string;
}

const badgeVariants = {
  success: 'bg-green-100 text-green-800 border-green-200',
  error: 'bg-red-100 text-red-800 border-red-200',
  warning: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  info: 'bg-blue-100 text-blue-800 border-blue-200',
  default: 'bg-gray-100 text-gray-800 border-gray-200'
};

const badgeSizes = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-2.5 py-0.5 text-sm',
  lg: 'px-3 py-1 text-sm'
};

export function Badge({ 
  children, 
  variant = 'default', 
  size = 'md', 
  icon: Icon, 
  className 
}: BadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full font-medium border',
      badgeVariants[variant],
      badgeSizes[size],
      className
    )}>
      {Icon && <Icon className="w-3 h-3 mr-1" />}
      {children}
    </span>
  );
}

// Status-specific badge components
export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const getVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'success':
      case 'completed':
      case 'active':
        return 'success';
      case 'failed':
      case 'error':
      case 'inactive':
        return 'error';
      case 'running':
      case 'started':
      case 'processing':
        return 'info';
      case 'pending':
      case 'waiting':
        return 'warning';
      default:
        return 'default';
    }
  };

  return (
    <Badge variant={getVariant(status)} className={className}>
      {status}
    </Badge>
  );
}

export function EnvironmentBadge({ environment, className }: { environment: string; className?: string }) {
  const getVariant = (env: string) => {
    switch (env.toLowerCase()) {
      case 'prod':
      case 'production':
        return 'error';
      case 'staging':
      case 'stage':
        return 'warning';
      case 'dev':
      case 'development':
        return 'success';
      default:
        return 'default';
    }
  };

  return (
    <Badge variant={getVariant(environment)} className={className}>
      {environment}
    </Badge>
  );
}



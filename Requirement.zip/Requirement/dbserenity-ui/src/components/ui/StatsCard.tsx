import React from 'react';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color?: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'indigo';
  className?: string;
}

const colorVariants = {
  blue: {
    icon: 'from-blue-500 to-blue-600',
    text: 'text-blue-600',
    bg: 'from-blue-50 to-indigo-50',
    border: 'hover:border-blue-200'
  },
  green: {
    icon: 'from-green-500 to-emerald-600',
    text: 'text-green-600',
    bg: 'from-green-50 to-emerald-50',
    border: 'hover:border-green-200'
  },
  purple: {
    icon: 'from-purple-500 to-purple-600',
    text: 'text-purple-600',
    bg: 'from-purple-50 to-pink-50',
    border: 'hover:border-purple-200'
  },
  orange: {
    icon: 'from-orange-500 to-red-600',
    text: 'text-orange-600',
    bg: 'from-orange-50 to-red-50',
    border: 'hover:border-orange-200'
  },
  red: {
    icon: 'from-red-500 to-red-600',
    text: 'text-red-600',
    bg: 'from-red-50 to-pink-50',
    border: 'hover:border-red-200'
  },
  indigo: {
    icon: 'from-indigo-500 to-purple-600',
    text: 'text-indigo-600',
    bg: 'from-indigo-50 to-purple-50',
    border: 'hover:border-indigo-200'
  }
};

export function StatsCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend, 
  color = 'blue',
  className 
}: StatsCardProps) {
  const colors = colorVariants[color];

  return (
    <div className={cn(
      "stats-card group hover-lift bg-gradient-to-r",
      colors.bg,
      colors.border,
      className
    )}>
      <div className="flex items-center justify-between mb-4">
        <div className={cn(
          "w-12 h-12 bg-gradient-to-r rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200",
          colors.icon
        )}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="text-right">
          <div className={cn("stats-number", colors.text)}>{value}</div>
          <div className="stats-label">{title}</div>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        {subtitle && (
          <span className={cn("text-sm font-medium", colors.text)}>
            {subtitle}
          </span>
        )}
        
        {trend && (
          <div className={cn(
            "flex items-center text-sm font-medium",
            trend.isPositive ? "text-green-600" : "text-red-600"
          )}>
            {trend.isPositive ? (
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            ) : (
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
            {Math.abs(trend.value)}%
          </div>
        )}
      </div>
    </div>
  );
}



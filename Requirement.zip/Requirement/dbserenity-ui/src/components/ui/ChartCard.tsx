import React from 'react';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  children: React.ReactNode;
  className?: string;
  headerActions?: React.ReactNode;
}

export function ChartCard({ 
  title, 
  subtitle, 
  icon: Icon, 
  children, 
  className,
  headerActions 
}: ChartCardProps) {
  return (
    <div className={cn("chart-container hover-lift", className)}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          {Icon && (
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
              <Icon className="w-5 h-5 text-white" />
            </div>
          )}
          <div>
            <h3 className="text-lg font-bold text-gray-900">{title}</h3>
            {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
          </div>
        </div>
        {headerActions && (
          <div className="flex items-center space-x-2">
            {headerActions}
          </div>
        )}
      </div>
      <div className="relative">
        {children}
      </div>
    </div>
  );
}

interface MetricCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color: 'green' | 'blue' | 'purple' | 'orange' | 'red';
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

const metricColors = {
  green: 'from-green-500 to-emerald-600 text-green-600',
  blue: 'from-blue-500 to-blue-600 text-blue-600',
  purple: 'from-purple-500 to-purple-600 text-purple-600',
  orange: 'from-orange-500 to-orange-600 text-orange-600',
  red: 'from-red-500 to-red-600 text-red-600'
};

export function MetricCard({ label, value, icon: Icon, color, trend }: MetricCardProps) {
  const colorClass = metricColors[color];
  const [gradientClass, textClass] = colorClass.split(' text-');

  return (
    <div className="text-center p-6 bg-white rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200 group">
      <div className={cn(
        "w-12 h-12 bg-gradient-to-r rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-200",
        gradientClass
      )}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className={cn("text-3xl font-bold mb-1", `text-${textClass}`)}>
        {value}
      </div>
      <div className="text-sm text-gray-600 mb-2">{label}</div>
      {trend && (
        <div className={cn(
          "flex items-center justify-center text-xs font-medium",
          trend.isPositive ? "text-green-600" : "text-red-600"
        )}>
          {trend.isPositive ? (
            <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          )}
          {Math.abs(trend.value)}%
        </div>
      )}
    </div>
  );
}



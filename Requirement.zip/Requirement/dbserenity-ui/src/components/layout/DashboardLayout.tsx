'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/Button';
import {
  Database,
  Users,
  Activity,
  Settings,
  LogOut,
  Menu,
  X,
  Home,
  GitBranch,
  BarChart3,
  Shield,
  Bell,
  User,
  Search,
  Moon,
  Sun,
  ChevronDown,
  Maximize2
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const pathname = usePathname();

  const adminNavigation = [
    { name: 'Dashboard', href: '/dashboard', icon: Home, color: 'text-blue-600' },
    { name: 'Tenants', href: '/dashboard/tenants', icon: Users, color: 'text-green-600' },
    { name: 'Executions', href: '/dashboard/executions', icon: Activity, color: 'text-purple-600' },
    { name: 'Analytics', href: '/dashboard/analytics', icon: BarChart3, color: 'text-orange-600' },
    { name: 'Audit Logs', href: '/dashboard/audit', icon: Shield, color: 'text-red-600' },
    { name: 'Templates', href: '/dashboard/templates', icon: GitBranch, color: 'text-indigo-600' },
    { name: 'Settings', href: '/dashboard/settings', icon: Settings, color: 'text-gray-600' },
  ];

  const tenantNavigation = [
    { name: 'Dashboard', href: '/dashboard', icon: Home, color: 'text-blue-600' },
    { name: 'Execute Scripts', href: '/dashboard/execute', icon: Database, color: 'text-green-600' },
    { name: 'Execution History', href: '/dashboard/history', icon: Activity, color: 'text-purple-600' },
    { name: 'Analytics', href: '/dashboard/analytics', icon: BarChart3, color: 'text-orange-600' },
    { name: 'Repository', href: '/dashboard/repository', icon: GitBranch, color: 'text-indigo-600' },
    { name: 'Settings', href: '/dashboard/settings', icon: Settings, color: 'text-gray-600' },
  ];

  const navigation = user?.role === 'admin' ? adminNavigation : tenantNavigation;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "sidebar lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Sidebar header */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg">
              <Database className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-lg font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                DBSerenity
              </span>
              <p className="text-xs text-gray-500 -mt-1">Schema Platform</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* User info */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-md">
              <User className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">
                {user?.tenantName || user?.clientId}
              </p>
              <p className="text-xs text-gray-500 capitalize">
                {user?.role} • {user?.tenantId}
              </p>
            </div>
            <div className={cn(
              "w-3 h-3 rounded-full",
              user?.role === 'admin' ? 'bg-red-500' : 'bg-green-500'
            )} />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "nav-item group",
                  isActive && "active"
                )}
                onClick={() => setSidebarOpen(false)}
              >
                <div className={cn(
                  "w-5 h-5 mr-3 transition-colors",
                  isActive ? item.color : "text-gray-400 group-hover:text-gray-600"
                )}>
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="font-medium">{item.name}</span>
                {isActive && (
                  <div className="ml-auto w-2 h-2 bg-blue-600 rounded-full"></div>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Sidebar footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Zap className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-semibold text-gray-900">Platform Status</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs text-gray-600">All systems operational</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top navigation */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-200/50 shadow-sm">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-5 h-5" />
              </Button>
              
              <div>
                <h1 className="text-lg font-bold text-gray-900">
                  {user?.role === 'admin' ? 'Admin Portal' : `${user?.tenantName || 'Tenant'} Portal`}
                </h1>
                <p className="text-xs text-gray-500 -mt-1">
                  {user?.role === 'admin' ? 'Platform Management' : 'Database Operations'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="hidden md:flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="pl-10 pr-4 py-2 bg-gray-100 border-0 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 w-64"
                  />
                </div>
              </div>

              {/* Notifications */}
              <div className="relative">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="relative hover:bg-gray-100"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                </Button>
              </div>

              {/* User menu */}
              <div className="relative">
                <Button
                  variant="ghost"
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center space-x-3 hover:bg-gray-100 px-3 py-2 rounded-lg"
                >
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-md">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <div className="hidden md:block text-left">
                    <p className="text-sm font-semibold text-gray-900">
                      {user?.tenantName || user?.clientId}
                    </p>
                    <p className="text-xs text-gray-500 capitalize">
                      {user?.role}
                    </p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </Button>

                {/* User dropdown */}
                {userMenuOpen && (
                  <div className="dropdown">
                    <div className="px-4 py-3 border-b border-gray-100">
                      <p className="text-sm font-medium text-gray-900">
                        {user?.tenantName || user?.clientId}
                      </p>
                      <p className="text-xs text-gray-500">
                        {user?.email || user?.tenantId}
                      </p>
                    </div>
                    <a href="#" className="dropdown-item">
                      <User className="w-4 h-4 mr-3" />
                      Profile
                    </a>
                    <a href="#" className="dropdown-item">
                      <Settings className="w-4 h-4 mr-3" />
                      Settings
                    </a>
                    <div className="border-t border-gray-100 my-1"></div>
                    <button
                      onClick={logout}
                      className="dropdown-item w-full text-left text-red-600 hover:bg-red-50"
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Click outside to close user menu */}
      {userMenuOpen && (
        <div 
          className="fixed inset-0 z-20" 
          onClick={() => setUserMenuOpen(false)}
        />
      )}
    </div>
  );
}
'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { DBSerenityAPI, TenantStatsResponse, ChangesetExecutionResponse } from '@/lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
  Database,
  Users,
  Server,
  GitBranch,
  Calendar,
  Download
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { formatNumber, formatDuration } from '@/lib/utils';

export default function AnalyticsPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<TenantStatsResponse | null>(null);
  const [executions, setExecutions] = useState<ChangesetExecutionResponse[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    loadAnalyticsData();
  }, [timeRange]);

  const loadAnalyticsData = async () => {
    try {
      setIsLoading(true);
      
      const promises = [];
      
      if (user?.role === 'admin') {
        promises.push(DBSerenityAPI.getTenantStats());
      }
      
      promises.push(DBSerenityAPI.getExecutionHistory(0, 100));
      
      const results = await Promise.all(promises);
      
      if (user?.role === 'admin') {
        setStats(results[0] as TenantStatsResponse);
        setExecutions((results[1] as any).executions || []);
      } else {
        setExecutions((results[0] as any).executions || []);
      }
    } catch (error) {
      console.error('Failed to load analytics data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate analytics data
  const executionsByStatus = getExecutionsByStatus(executions);
  const executionsByEnvironment = getExecutionsByEnvironment(executions);
  const executionTrend = getExecutionTrend(executions);
  const performanceMetrics = getPerformanceMetrics(executions);
  const successRate = getSuccessRate(executions);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="text-gray-600">
            {user?.role === 'admin' 
              ? 'Platform-wide analytics and insights'
              : 'Your tenant analytics and performance metrics'
            }
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {user?.role === 'admin' && stats && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(stats.totalTenants)}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeTenants} active
              </p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Executions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(executions.length)}</div>
            <p className="text-xs text-muted-foreground">
              {timeRange} period
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{successRate}%</div>
            <p className="text-xs text-muted-foreground">
              {executions.filter(e => e.status === 'SUCCESS').length} successful
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Duration</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {performanceMetrics.avgDuration ? formatDuration(performanceMetrics.avgDuration) : 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground">
              Average execution time
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Execution Status Distribution</CardTitle>
            <CardDescription>Breakdown of execution results</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={executionsByStatus}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {executionsByStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Environment Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Executions by Environment</CardTitle>
            <CardDescription>Distribution across environments</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={executionsByEnvironment}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Execution Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Execution Trend</CardTitle>
            <CardDescription>Execution volume over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={executionTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="executions" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                <Area type="monotone" dataKey="successful" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Insights</CardTitle>
          <CardDescription>Key performance indicators and trends</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">{successRate}%</p>
              <p className="text-sm text-gray-600">Success Rate</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">
                {performanceMetrics.avgDuration ? formatDuration(performanceMetrics.avgDuration) : 'N/A'}
              </p>
              <p className="text-sm text-gray-600">Avg Duration</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Database className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">
                {formatNumber(performanceMetrics.totalChangesets)}
              </p>
              <p className="text-sm text-gray-600">Total Changesets</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper functions for analytics calculations
function getExecutionsByStatus(executions: ChangesetExecutionResponse[]) {
  const statusCounts = executions.reduce((acc, execution) => {
    acc[execution.status] = (acc[execution.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const colors = {
    SUCCESS: '#10b981',
    FAILED: '#ef4444',
    RUNNING: '#3b82f6',
    STARTED: '#f59e0b',
  };

  return Object.entries(statusCounts).map(([status, value]) => ({
    name: status,
    value,
    fill: colors[status as keyof typeof colors] || '#6b7280',
  }));
}

function getExecutionsByEnvironment(executions: ChangesetExecutionResponse[]) {
  const envCounts = executions.reduce((acc, execution) => {
    acc[execution.environment] = (acc[execution.environment] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(envCounts).map(([name, value]) => ({ name, value }));
}

function getExecutionTrend(executions: ChangesetExecutionResponse[]) {
  // Group executions by date
  const dateGroups = executions.reduce((acc, execution) => {
    const date = new Date(execution.startedAt).toISOString().split('T')[0];
    if (!acc[date]) {
      acc[date] = { total: 0, successful: 0 };
    }
    acc[date].total++;
    if (execution.status === 'SUCCESS') {
      acc[date].successful++;
    }
    return acc;
  }, {} as Record<string, { total: number; successful: number }>);

  return Object.entries(dateGroups)
    .map(([date, data]) => ({
      date,
      executions: data.total,
      successful: data.successful,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

function getPerformanceMetrics(executions: ChangesetExecutionResponse[]) {
  const completedExecutions = executions.filter(e => e.durationMs);
  const totalDuration = completedExecutions.reduce((sum, e) => sum + (e.durationMs || 0), 0);
  const avgDuration = completedExecutions.length > 0 ? totalDuration / completedExecutions.length : 0;
  const totalChangesets = executions.reduce((sum, e) => sum + (e.summary?.changesetsExecuted || 0), 0);

  return {
    avgDuration,
    totalChangesets,
    completedExecutions: completedExecutions.length,
  };
}

function getSuccessRate(executions: ChangesetExecutionResponse[]): number {
  if (executions.length === 0) return 0;
  const successCount = executions.filter(e => e.status === 'SUCCESS').length;
  return Math.round((successCount / executions.length) * 100);
}

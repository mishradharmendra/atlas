'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { DBSerenityAPI, TenantStatsResponse, ChangesetExecutionResponse } from '@/lib/api';
import { Button } from '@/components/ui/Button';
import {
  Users,
  Database,
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Server,
  GitBranch,
  AlertCircle,
  Plus,
  Eye,
  Play,
  BarChart3,
  Zap,
  Shield
} from 'lucide-react';
import { formatNumber, getStatusColor, formatRelativeTime, cn } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from 'recharts';
import Link from 'next/link';

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<TenantStatsResponse | null>(null);
  const [recentExecutions, setRecentExecutions] = useState<ChangesetExecutionResponse[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      if (user?.role === 'admin') {
        // Load admin dashboard data
        const [statsData, executionsData] = await Promise.all([
          DBSerenityAPI.getTenantStats(),
          DBSerenityAPI.getExecutionHistory(0, 10)
        ]);
        
        setStats(statsData);
        setRecentExecutions(executionsData.executions || []);
      } else {
        // Load tenant dashboard data
        const executionsData = await DBSerenityAPI.getExecutionHistory(0, 10);
        setRecentExecutions(executionsData.executions || []);
      }
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="stats-card animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {user?.tenantName || user?.clientId}! 👋
            </h1>
            <p className="text-blue-100 text-lg">
              {user?.role === 'admin' 
                ? 'Manage tenants, monitor executions, and oversee the entire platform ecosystem'
                : 'Execute changesets, monitor your database schema, and track deployment progress'
              }
            </p>
          </div>
          <div className="hidden lg:block">
            <div className="w-24 h-24 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              {user?.role === 'admin' ? (
                <Shield className="w-12 h-12 text-white" />
              ) : (
                <Database className="w-12 h-12 text-white" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Admin Dashboard */}
      {user?.role === 'admin' && stats && (
        <>
          {/* Admin Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="stats-card group hover-lift">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="stats-number text-blue-600">{formatNumber(stats.totalTenants)}</div>
                  <div className="stats-label">Total Tenants</div>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-600 font-medium">{stats.activeTenants} active</span>
                <span className="text-gray-500">{stats.inactiveTenants} inactive</span>
              </div>
              <div className="mt-3 bg-gray-100 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(stats.activeTenants / stats.totalTenants) * 100}%` }}
                ></div>
              </div>
            </div>

            <div className="stats-card group hover-lift">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="stats-number text-green-600">{formatNumber(stats.activeTenants)}</div>
                  <div className="stats-label">Active Tenants</div>
                </div>
              </div>
              <div className="flex items-center text-sm text-green-600">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span className="font-medium">
                  {Math.round((stats.activeTenants / stats.totalTenants) * 100)}% active rate
                </span>
              </div>
            </div>

            <div className="stats-card group hover-lift">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                  <GitBranch className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="stats-number text-purple-600">{formatNumber(stats.tenantsWithGitHubRepo)}</div>
                  <div className="stats-label">GitHub Repos</div>
                </div>
              </div>
              <div className="flex items-center text-sm text-purple-600">
                <GitBranch className="w-4 h-4 mr-1" />
                <span className="font-medium">Connected repositories</span>
              </div>
            </div>

            <div className="stats-card group hover-lift">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="stats-number text-orange-600">{formatNumber(recentExecutions.length)}</div>
                  <div className="stats-label">Recent Executions</div>
                </div>
              </div>
              <div className="flex items-center text-sm text-orange-600">
                <Clock className="w-4 h-4 mr-1" />
                <span className="font-medium">Last 24 hours</span>
              </div>
            </div>
          </div>

          {/* Admin Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="chart-container">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Tenant Distribution</h3>
                  <p className="text-sm text-gray-600">Active vs Inactive tenants</p>
                </div>
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-4 h-4 text-white" />
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Active', value: stats.activeTenants, fill: '#10b981' },
                      { name: 'Inactive', value: stats.inactiveTenants, fill: '#ef4444' }
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {[
                      { name: 'Active', value: stats.activeTenants, fill: '#10b981' },
                      { name: 'Inactive', value: stats.inactiveTenants, fill: '#ef4444' }
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="chart-container">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Execution Overview</h3>
                  <p className="text-sm text-gray-600">Recent execution results</p>
                </div>
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <Activity className="w-4 h-4 text-white" />
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={getExecutionStatusData(recentExecutions)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Bar dataKey="count" fill="url(#colorGradient)" radius={[4, 4, 0, 0]} />
                  <defs>
                    <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.9}/>
                      <stop offset="95%" stopColor="#1d4ed8" stopOpacity={0.9}/>
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}

      {/* Tenant Dashboard */}
      {user?.role === 'tenant' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="stats-card group hover-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <div className="stats-number text-blue-600">{formatNumber(recentExecutions.length)}</div>
                <div className="stats-label">Total Executions</div>
              </div>
            </div>
            <div className="flex items-center text-sm text-blue-600">
              <Activity className="w-4 h-4 mr-1" />
              <span className="font-medium">All time executions</span>
            </div>
          </div>

          <div className="stats-card group hover-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <div className="stats-number text-green-600">{getSuccessRate(recentExecutions)}%</div>
                <div className="stats-label">Success Rate</div>
              </div>
            </div>
            <div className="flex items-center text-sm text-green-600">
              <CheckCircle className="w-4 h-4 mr-1" />
              <span className="font-medium">Last 30 days</span>
            </div>
          </div>

          <div className="stats-card group hover-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200">
                <Server className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                <div className="stats-number text-purple-600">3</div>
                <div className="stats-label">Environments</div>
              </div>
            </div>
            <div className="flex items-center text-sm text-purple-600">
              <Server className="w-4 h-4 mr-1" />
              <span className="font-medium">Dev, Staging, Production</span>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Quick Actions</h2>
              <p className="text-sm text-gray-600">Common tasks and operations</p>
            </div>
            <Zap className="w-6 h-6 text-yellow-500" />
          </div>
        </div>
        <div className="card-content">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {user?.role === 'admin' ? (
              <>
                <Link href="/dashboard/tenants">
                  <div className="group p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border-2 border-transparent hover:border-blue-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <Plus className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Add Tenant</h3>
                    <p className="text-sm text-gray-600">Create new tenant account</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/executions">
                  <div className="group p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border-2 border-transparent hover:border-purple-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <Eye className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">View Executions</h3>
                    <p className="text-sm text-gray-600">Monitor all executions</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/analytics">
                  <div className="group p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-transparent hover:border-green-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <BarChart3 className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Analytics</h3>
                    <p className="text-sm text-gray-600">Platform insights</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/audit">
                  <div className="group p-6 bg-gradient-to-r from-red-50 to-pink-50 rounded-xl border-2 border-transparent hover:border-red-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <Shield className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Audit Logs</h3>
                    <p className="text-sm text-gray-600">Security monitoring</p>
                  </div>
                </Link>
              </>
            ) : (
              <>
                <Link href="/dashboard/execute">
                  <div className="group p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border-2 border-transparent hover:border-blue-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <Play className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Execute Scripts</h3>
                    <p className="text-sm text-gray-600">Run database changesets</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/history">
                  <div className="group p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border-2 border-transparent hover:border-purple-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <Activity className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">View History</h3>
                    <p className="text-sm text-gray-600">Execution history</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/analytics">
                  <div className="group p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-transparent hover:border-green-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <BarChart3 className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Analytics</h3>
                    <p className="text-sm text-gray-600">Performance insights</p>
                  </div>
                </Link>
                
                <Link href="/dashboard/repository">
                  <div className="group p-6 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border-2 border-transparent hover:border-orange-200 hover:shadow-lg transition-all duration-200 cursor-pointer">
                    <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-200">
                      <GitBranch className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Repository</h3>
                    <p className="text-sm text-gray-600">Template management</p>
                  </div>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Recent Executions */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Recent Executions</h2>
              <p className="text-sm text-gray-600">
                Latest changeset executions across {user?.role === 'admin' ? 'all tenants' : 'your environments'}
              </p>
            </div>
            <Link href={user?.role === 'admin' ? '/dashboard/executions' : '/dashboard/history'}>
              <Button variant="outline" className="hover-scale">
                View All
                <Eye className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
        <div className="card-content">
          {recentExecutions.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No recent executions</h3>
              <p className="text-gray-500 mb-6">
                Execute your first changeset to see activity here
              </p>
              {user?.role === 'tenant' && (
                <Link href="/dashboard/execute">
                  <Button className="btn-primary">
                    <Play className="w-4 h-4 mr-2" />
                    Execute First Script
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {recentExecutions.slice(0, 5).map((execution) => (
                <div key={execution.executionId} className="group p-4 bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 hover:border-gray-300 transition-all duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={cn(
                        "w-4 h-4 rounded-full shadow-sm",
                        execution.status === 'SUCCESS' ? 'bg-green-500' :
                        execution.status === 'FAILED' ? 'bg-red-500' :
                        execution.status === 'RUNNING' ? 'bg-blue-500 animate-pulse' :
                        'bg-yellow-500'
                      )} />
                      <div>
                        <p className="font-semibold text-gray-900">{execution.executionId}</p>
                        <div className="flex items-center space-x-3 text-sm text-gray-600">
                          <span className="flex items-center">
                            <Database className="w-3 h-3 mr-1" />
                            {execution.tenantId}
                          </span>
                          <span className={cn(
                            "badge",
                            execution.environment === 'prod' ? 'badge-error' :
                            execution.environment === 'staging' ? 'badge-warning' :
                            'badge-success'
                          )}>
                            {execution.environment}
                          </span>
                          <span className="capitalize">{execution.mode}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={cn(
                        "badge",
                        execution.status === 'SUCCESS' ? 'badge-success' :
                        execution.status === 'FAILED' ? 'badge-error' :
                        execution.status === 'RUNNING' ? 'badge-info' :
                        'badge-warning'
                      )}>
                        {execution.status}
                      </span>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatRelativeTime(execution.startedAt)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Helper functions
function getExecutionStatusData(executions: ChangesetExecutionResponse[]) {
  const statusCounts = executions.reduce((acc, execution) => {
    acc[execution.status] = (acc[execution.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(statusCounts).map(([status, count]) => ({
    name: status,
    count,
  }));
}

function getSuccessRate(executions: ChangesetExecutionResponse[]): number {
  if (executions.length === 0) return 0;
  const successCount = executions.filter(e => e.status === 'SUCCESS').length;
  return Math.round((successCount / executions.length) * 100);
}
'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { DBSerenityAPI, TenantResponse, TenantCreateRequest } from '@/lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import {
  Users,
  Plus,
  Search,
  Edit,
  Trash2,
  Power,
  PowerOff,
  ExternalLink,
  Mail,
  Calendar,
  GitBranch
} from 'lucide-react';
import { formatDate, getStatusColor, cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import ProtectedRoute from '@/components/ProtectedRoute';

export default function TenantsPage() {
  const { user } = useAuth();
  const [tenants, setTenants] = useState<TenantResponse[]>([]);
  const [filteredTenants, setFilteredTenants] = useState<TenantResponse[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    loadTenants();
  }, []);

  useEffect(() => {
    // Filter tenants based on search term
    const filtered = tenants.filter(tenant =>
      tenant.tenantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tenant.tenantId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tenant.contactEmail.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredTenants(filtered);
  }, [tenants, searchTerm]);

  const loadTenants = async () => {
    try {
      setIsLoading(true);
      const response = await DBSerenityAPI.getAllTenants(0, 100);
      setTenants(response.content || []);
    } catch (error) {
      console.error('Failed to load tenants:', error);
      toast.error('Failed to load tenants');
    } finally {
      setIsLoading(false);
    }
  };

  const handleActivateTenant = async (tenantId: string) => {
    try {
      await DBSerenityAPI.activateTenant(tenantId);
      toast.success('Tenant activated successfully');
      loadTenants();
    } catch (error) {
      toast.error('Failed to activate tenant');
    }
  };

  const handleDeactivateTenant = async (tenantId: string) => {
    try {
      await DBSerenityAPI.deactivateTenant(tenantId);
      toast.success('Tenant deactivated successfully');
      loadTenants();
    } catch (error) {
      toast.error('Failed to deactivate tenant');
    }
  };

  const handleDeleteTenant = async (tenantId: string) => {
    if (!confirm('Are you sure you want to delete this tenant? This action cannot be undone.')) {
      return;
    }

    try {
      await DBSerenityAPI.deleteTenant(tenantId);
      toast.success('Tenant deleted successfully');
      loadTenants();
    } catch (error) {
      toast.error('Failed to delete tenant');
    }
  };

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Tenant Management</h1>
            <p className="text-gray-600">Manage all tenants in the platform</p>
          </div>
          <Button onClick={() => setShowCreateModal(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Tenant
          </Button>
        </div>

        {/* Search and Filters */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search tenants by name, ID, or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline">
                <Users className="w-4 h-4 mr-2" />
                {filteredTenants.length} Tenants
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tenants Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredTenants.map((tenant) => (
              <Card key={tenant.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{tenant.tenantName}</CardTitle>
                      <CardDescription className="font-mono text-xs">
                        {tenant.tenantId}
                      </CardDescription>
                    </div>
                    <span className={cn(
                      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                      getStatusColor(tenant.isActive ? 'active' : 'inactive')
                    )}>
                      {tenant.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="w-4 h-4 mr-2" />
                      {tenant.contactEmail}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="w-4 h-4 mr-2" />
                      Created {formatDate(tenant.createdAt)}
                    </div>
                    {tenant.githubOrg && tenant.githubRepo && (
                      <div className="flex items-center text-sm text-gray-600">
                        <GitBranch className="w-4 h-4 mr-2" />
                        <a
                          href={`https://github.com/${tenant.githubOrg}/${tenant.githubRepo}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline flex items-center"
                        >
                          {tenant.githubOrg}/{tenant.githubRepo}
                          <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      </div>
                    )}
                  </div>

                  {tenant.description && (
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {tenant.description}
                    </p>
                  )}

                  {/* Environments */}
                  {tenant.environments && tenant.environments.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-gray-700 mb-2">Environments:</p>
                      <div className="flex flex-wrap gap-1">
                        {tenant.environments.map((env) => (
                          <span
                            key={env.id}
                            className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-800"
                          >
                            {env.environmentName}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      {tenant.isActive ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeactivateTenant(tenant.tenantId)}
                          className="text-orange-600 hover:text-orange-700"
                        >
                          <PowerOff className="w-4 h-4 mr-1" />
                          Deactivate
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleActivateTenant(tenant.tenantId)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Power className="w-4 h-4 mr-1" />
                          Activate
                        </Button>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteTenant(tenant.tenantId)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && filteredTenants.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tenants found</h3>
              <p className="text-gray-500 mb-6">
                {searchTerm ? 'No tenants match your search criteria' : 'Get started by creating your first tenant'}
              </p>
              {!searchTerm && (
                <Button onClick={() => setShowCreateModal(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Tenant
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </ProtectedRoute>
  );
}

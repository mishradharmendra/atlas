'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { DBSerenityAPI, ChangesetExecutionRequest, ChangesetExecutionResponse } from '@/lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import {
  Database,
  Play,
  TestTube,
  Upload,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Mail,
  Activity
} from 'lucide-react';
import { cn, formatDuration, getStatusColor } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function ExecutePage() {
  const { user } = useAuth();
  const [formData, setFormData] = useState<ChangesetExecutionRequest>({
    clientId: user?.clientId || '',
    clientSecret: '',
    artifactUrl: '',
    environment: 'dev',
    mode: 'dry-run',
    databasePassword: '',
    executionOptions: {
      rollbackOnFailure: true,
      notificationEmail: user?.email || '',
      timeoutMinutes: 30,
      contexts: 'common,dev',
      labels: 'v1.0',
    }
  });
  const [execution, setExecution] = useState<ChangesetExecutionResponse | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleInputChange = (field: keyof ChangesetExecutionRequest, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleExecutionOptionsChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      executionOptions: {
        ...prev.executionOptions,
        [field]: value
      }
    }));
  };

  const handleExecute = async (isDryRun: boolean = false) => {
    if (!formData.artifactUrl || !formData.databasePassword) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsExecuting(true);
    try {
      const request: ChangesetExecutionRequest = {
        ...formData,
        mode: isDryRun ? 'dry-run' : 'execute'
      };

      const response = isDryRun 
        ? await DBSerenityAPI.validateChangesets(request)
        : await DBSerenityAPI.executeChangesets(request);

      setExecution(response);
      toast.success(isDryRun ? 'Validation completed' : 'Execution started');
      
      // Poll for status updates if it's a real execution
      if (!isDryRun && response.executionId) {
        pollExecutionStatus(response.executionId);
      }
    } catch (error: any) {
      toast.error(error.message || 'Execution failed');
    } finally {
      setIsExecuting(false);
    }
  };

  const pollExecutionStatus = async (executionId: string) => {
    const poll = async () => {
      try {
        const status = await DBSerenityAPI.getExecutionStatus(executionId);
        setExecution(status);
        
        if (status.status === 'RUNNING' || status.status === 'STARTED') {
          setTimeout(poll, 2000); // Poll every 2 seconds
        }
      } catch (error) {
        console.error('Failed to poll execution status:', error);
      }
    };
    
    setTimeout(poll, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Execute Database Scripts</h1>
        <p className="text-gray-600">Run Liquibase changesets against your database environments</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="w-5 h-5 mr-2" />
              Changeset Execution
            </CardTitle>
            <CardDescription>
              Configure and execute your database changesets
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Basic Configuration */}
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Artifact URL *</label>
                <Input
                  placeholder="https://artifacts.example.com/tenant/changesets.zip"
                  value={formData.artifactUrl}
                  onChange={(e) => handleInputChange('artifactUrl', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Environment *</label>
                  <select
                    value={formData.environment}
                    onChange={(e) => handleInputChange('environment', e.target.value)}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="dev">Development</option>
                    <option value="staging">Staging</option>
                    <option value="prod">Production</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Mode</label>
                  <select
                    value={formData.mode}
                    onChange={(e) => handleInputChange('mode', e.target.value)}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="dry-run">Dry Run (Validate Only)</option>
                    <option value="execute">Execute Changes</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Database Password *</label>
                <Input
                  type="password"
                  placeholder="Enter database password"
                  value={formData.databasePassword}
                  onChange={(e) => handleInputChange('databasePassword', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            {/* Advanced Options */}
            <div className="border-t pt-4">
              <Button
                variant="ghost"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="mb-4"
              >
                <Settings className="w-4 h-4 mr-2" />
                Advanced Options
              </Button>

              {showAdvanced && (
                <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Contexts</label>
                      <Input
                        placeholder="common,dev"
                        value={formData.executionOptions?.contexts || ''}
                        onChange={(e) => handleExecutionOptionsChange('contexts', e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Labels</label>
                      <Input
                        placeholder="v1.0,v1.1"
                        value={formData.executionOptions?.labels || ''}
                        onChange={(e) => handleExecutionOptionsChange('labels', e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Timeout (minutes)</label>
                      <Input
                        type="number"
                        min="1"
                        max="120"
                        value={formData.executionOptions?.timeoutMinutes || 30}
                        onChange={(e) => handleExecutionOptionsChange('timeoutMinutes', parseInt(e.target.value))}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Notification Email</label>
                      <Input
                        type="email"
                        placeholder="admin@example.com"
                        value={formData.executionOptions?.notificationEmail || ''}
                        onChange={(e) => handleExecutionOptionsChange('notificationEmail', e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="rollbackOnFailure"
                      checked={formData.executionOptions?.rollbackOnFailure || false}
                      onChange={(e) => handleExecutionOptionsChange('rollbackOnFailure', e.target.checked)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="rollbackOnFailure" className="text-sm text-gray-700">
                      Rollback on failure
                    </label>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3 pt-4">
              <Button
                onClick={() => handleExecute(true)}
                disabled={isExecuting}
                variant="outline"
                className="flex-1"
              >
                <TestTube className="w-4 h-4 mr-2" />
                Validate (Dry Run)
              </Button>
              <Button
                onClick={() => handleExecute(false)}
                disabled={isExecuting}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Play className="w-4 h-4 mr-2" />
                Execute Changes
              </Button>
            </div>

            {/* Warning for Production */}
            {formData.environment === 'prod' && (
              <div className="flex items-start space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-800">Production Environment</p>
                  <p className="text-xs text-red-700">
                    You are about to execute changes in production. Please ensure you have tested these changes thoroughly.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Execution Results */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Execution Results
            </CardTitle>
            <CardDescription>
              Real-time execution status and results
            </CardDescription>
          </CardHeader>
          <CardContent>
            {execution ? (
              <div className="space-y-4">
                {/* Status Header */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{execution.executionId}</p>
                    <p className="text-sm text-gray-600">
                      {execution.environment} • {execution.mode}
                    </p>
                  </div>
                  <span className={cn(
                    "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium",
                    getStatusColor(execution.status)
                  )}>
                    {execution.status === 'RUNNING' && <Clock className="w-4 h-4 mr-1 animate-spin" />}
                    {execution.status === 'SUCCESS' && <CheckCircle className="w-4 h-4 mr-1" />}
                    {execution.status === 'FAILED' && <AlertTriangle className="w-4 h-4 mr-1" />}
                    {execution.status}
                  </span>
                </div>

                {/* Execution Details */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Started</p>
                    <p className="font-medium">{new Date(execution.startedAt).toLocaleString()}</p>
                  </div>
                  {execution.completedAt && (
                    <div>
                      <p className="text-gray-600">Completed</p>
                      <p className="font-medium">{new Date(execution.completedAt).toLocaleString()}</p>
                    </div>
                  )}
                  {execution.durationMs && (
                    <div>
                      <p className="text-gray-600">Duration</p>
                      <p className="font-medium">{formatDuration(execution.durationMs)}</p>
                    </div>
                  )}
                </div>

                {/* Summary */}
                {execution.summary && (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-blue-50 rounded-lg">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">
                        {execution.summary.changesetsExecuted || 0}
                      </p>
                      <p className="text-xs text-gray-600">Executed</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-yellow-600">
                        {execution.summary.changesetsSkipped || 0}
                      </p>
                      <p className="text-xs text-gray-600">Skipped</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-red-600">
                        {execution.summary.changesetsFailed || 0}
                      </p>
                      <p className="text-xs text-gray-600">Failed</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-blue-600">
                        {execution.summary.sqlStatementsExecuted || 0}
                      </p>
                      <p className="text-xs text-gray-600">SQL Statements</p>
                    </div>
                  </div>
                )}

                {/* Message */}
                {execution.message && (
                  <div className="p-3 bg-gray-100 rounded-lg">
                    <p className="text-sm">{execution.message}</p>
                  </div>
                )}

                {/* Logs */}
                {execution.logs && execution.logs.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <FileText className="w-4 h-4 mr-2" />
                      Execution Logs
                    </h4>
                    <div className="bg-gray-900 text-gray-100 p-4 rounded-lg max-h-64 overflow-y-auto font-mono text-xs">
                      {execution.logs.map((log, index) => (
                        <div key={index} className="mb-1">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Execute</h3>
                <p className="text-gray-500">
                  Configure your changeset execution settings and click validate or execute
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sample Artifacts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Upload className="w-5 h-5 mr-2" />
            Sample Artifacts
          </CardTitle>
          <CardDescription>
            Use these sample artifact URLs for testing
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">ACME Corp Sample</p>
                <p className="text-sm text-gray-600 font-mono">
                  https://artifacts.dbserenity.com/acme-corp/v1.0.0/changesets.zip
                </p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleInputChange('artifactUrl', 'https://artifacts.dbserenity.com/acme-corp/v1.0.0/changesets.zip')}
              >
                Use This
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">Demo Corp Sample</p>
                <p className="text-sm text-gray-600 font-mono">
                  https://artifacts.dbserenity.com/demo-corp/v1.1.0/changesets.zip
                </p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleInputChange('artifactUrl', 'https://artifacts.dbserenity.com/demo-corp/v1.1.0/changesets.zip')}
              >
                Use This
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Execution Tips */}
      <Card>
        <CardHeader>
          <CardTitle>💡 Execution Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Before Executing:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Always run a dry-run first to validate changes</li>
                <li>• Ensure database backups are available</li>
                <li>• Verify artifact URL is accessible</li>
                <li>• Check database connectivity</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Best Practices:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Use rollback on failure for safety</li>
                <li>• Set appropriate timeout values</li>
                <li>• Configure notification emails</li>
                <li>• Monitor execution progress</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

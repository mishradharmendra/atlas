'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import {
  Shield,
  Search,
  Filter,
  Download,
  Eye,
  Calendar,
  User,
  Activity,
  AlertTriangle,
  CheckCircle,
  Info,
  Clock
} from 'lucide-react';
import { formatDate, cn } from '@/lib/utils';
import ProtectedRoute from '@/components/ProtectedRoute';

interface AuditLog {
  id: string;
  eventType: string;
  eventCategory: 'AUTHENTICATION' | 'TENANT' | 'EXECUTION' | 'SYSTEM' | 'SECURITY';
  entityType?: string;
  entityId?: string;
  tenantId?: string;
  userId?: string;
  clientId?: string;
  action: string;
  message?: string;
  timestamp: string;
  ipAddress?: string;
  userAgent?: string;
}

export default function AuditPage() {
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  useEffect(() => {
    loadAuditLogs();
  }, []);

  useEffect(() => {
    // Filter audit logs
    let filtered = auditLogs;

    if (searchTerm) {
      filtered = filtered.filter(log =>
        log.eventType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.clientId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.tenantId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.message?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter) {
      filtered = filtered.filter(log => log.eventCategory === categoryFilter);
    }

    if (actionFilter) {
      filtered = filtered.filter(log => log.action === actionFilter);
    }

    setFilteredLogs(filtered);
  }, [auditLogs, searchTerm, categoryFilter, actionFilter]);

  const loadAuditLogs = async () => {
    try {
      setIsLoading(true);
      // Simulate audit logs data (replace with actual API call)
      const mockLogs: AuditLog[] = [
        {
          id: '1',
          eventType: 'USER_LOGIN',
          eventCategory: 'AUTHENTICATION',
          clientId: 'acme-corp-client',
          tenantId: 'acme-corp',
          action: 'LOGIN',
          message: 'User successfully authenticated',
          timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
          ipAddress: '192.168.1.100',
        },
        {
          id: '2',
          eventType: 'TENANT_CREATED',
          eventCategory: 'TENANT',
          entityType: 'tenant',
          entityId: 'demo-corp',
          userId: 'admin',
          action: 'CREATE',
          message: 'New tenant created: Demo Corporation',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        },
        {
          id: '3',
          eventType: 'CHANGESET_EXECUTED',
          eventCategory: 'EXECUTION',
          entityType: 'execution',
          entityId: 'exec-123456',
          tenantId: 'acme-corp',
          clientId: 'acme-corp-client',
          action: 'EXECUTE',
          message: 'Changeset execution completed successfully',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
        },
        {
          id: '4',
          eventType: 'SECURITY_VIOLATION',
          eventCategory: 'SECURITY',
          clientId: 'unknown-client',
          action: 'ACCESS',
          message: 'Unauthorized access attempt detected',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString(),
          ipAddress: '10.0.0.1',
        },
        {
          id: '5',
          eventType: 'SYSTEM_STARTUP',
          eventCategory: 'SYSTEM',
          action: 'STARTUP',
          message: 'DBSerenity platform started successfully',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        },
      ];
      
      setAuditLogs(mockLogs);
    } catch (error) {
      console.error('Failed to load audit logs:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'AUTHENTICATION':
        return <User className="w-4 h-4" />;
      case 'TENANT':
        return <User className="w-4 h-4" />;
      case 'EXECUTION':
        return <Activity className="w-4 h-4" />;
      case 'SECURITY':
        return <Shield className="w-4 h-4" />;
      case 'SYSTEM':
        return <Info className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'AUTHENTICATION':
        return 'text-blue-600 bg-blue-100';
      case 'TENANT':
        return 'text-green-600 bg-green-100';
      case 'EXECUTION':
        return 'text-purple-600 bg-purple-100';
      case 'SECURITY':
        return 'text-red-600 bg-red-100';
      case 'SYSTEM':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE':
        return <CheckCircle className="w-3 h-3 text-green-600" />;
      case 'UPDATE':
        return <Info className="w-3 h-3 text-blue-600" />;
      case 'DELETE':
        return <AlertTriangle className="w-3 h-3 text-red-600" />;
      case 'LOGIN':
        return <User className="w-3 h-3 text-green-600" />;
      case 'EXECUTE':
        return <Activity className="w-3 h-3 text-purple-600" />;
      default:
        return <Info className="w-3 h-3 text-gray-600" />;
    }
  };

  return (
    <ProtectedRoute requireAdmin>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Audit Logs</h1>
            <p className="text-gray-600">Monitor all system activities and security events</p>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Logs
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search audit logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">All Categories</option>
                <option value="AUTHENTICATION">Authentication</option>
                <option value="TENANT">Tenant</option>
                <option value="EXECUTION">Execution</option>
                <option value="SECURITY">Security</option>
                <option value="SYSTEM">System</option>
              </select>
              <select
                value={actionFilter}
                onChange={(e) => setActionFilter(e.target.value)}
                className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">All Actions</option>
                <option value="CREATE">Create</option>
                <option value="UPDATE">Update</option>
                <option value="DELETE">Delete</option>
                <option value="LOGIN">Login</option>
                <option value="EXECUTE">Execute</option>
                <option value="ACCESS">Access</option>
              </select>
              <div className="flex items-center text-sm text-gray-600">
                <Filter className="w-4 h-4 mr-2" />
                {filteredLogs.length} results
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Audit Logs List */}
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredLogs.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No audit logs found</h3>
              <p className="text-gray-500">
                {searchTerm || categoryFilter || actionFilter
                  ? 'No logs match your current filters'
                  : 'No audit logs available'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredLogs.map((log) => (
              <Card key={log.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={cn(
                        "flex items-center justify-center w-8 h-8 rounded-full",
                        getCategoryColor(log.eventCategory)
                      )}>
                        {getCategoryIcon(log.eventCategory)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-medium text-gray-900">{log.eventType}</h3>
                          <span className={cn(
                            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                            getCategoryColor(log.eventCategory)
                          )}>
                            {log.eventCategory}
                          </span>
                          <div className="flex items-center text-xs text-gray-500">
                            {getActionIcon(log.action)}
                            <span className="ml-1">{log.action}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                          <span className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {formatDate(log.timestamp)}
                          </span>
                          {log.tenantId && (
                            <span>Tenant: {log.tenantId}</span>
                          )}
                          {log.clientId && (
                            <span>Client: {log.clientId}</span>
                          )}
                          {log.ipAddress && (
                            <span>IP: {log.ipAddress}</span>
                          )}
                        </div>

                        {log.message && (
                          <p className="text-sm text-gray-700">{log.message}</p>
                        )}
                      </div>
                    </div>

                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedLog(log)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Audit Log Details Modal */}
        {selectedLog && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">Audit Log Details</h2>
                  <Button variant="ghost" onClick={() => setSelectedLog(null)}>
                    ×
                  </Button>
                </div>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Event Type</p>
                    <p className="font-medium">{selectedLog.eventType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Category</p>
                    <span className={cn(
                      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                      getCategoryColor(selectedLog.eventCategory)
                    )}>
                      {selectedLog.eventCategory}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Action</p>
                    <div className="flex items-center">
                      {getActionIcon(selectedLog.action)}
                      <span className="ml-2">{selectedLog.action}</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Timestamp</p>
                    <p className="font-medium">{formatDate(selectedLog.timestamp)}</p>
                  </div>
                  {selectedLog.tenantId && (
                    <div>
                      <p className="text-sm text-gray-600">Tenant ID</p>
                      <p className="font-medium">{selectedLog.tenantId}</p>
                    </div>
                  )}
                  {selectedLog.clientId && (
                    <div>
                      <p className="text-sm text-gray-600">Client ID</p>
                      <p className="font-medium">{selectedLog.clientId}</p>
                    </div>
                  )}
                  {selectedLog.ipAddress && (
                    <div>
                      <p className="text-sm text-gray-600">IP Address</p>
                      <p className="font-medium">{selectedLog.ipAddress}</p>
                    </div>
                  )}
                  {selectedLog.entityType && (
                    <div>
                      <p className="text-sm text-gray-600">Entity Type</p>
                      <p className="font-medium">{selectedLog.entityType}</p>
                    </div>
                  )}
                </div>

                {selectedLog.message && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Message</p>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm">{selectedLog.message}</p>
                    </div>
                  </div>
                )}

                {selectedLog.userAgent && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">User Agent</p>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs font-mono break-all">{selectedLog.userAgent}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Events</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{auditLogs.length}</div>
              <p className="text-xs text-muted-foreground">
                Last 24 hours
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Security Events</CardTitle>
              <Shield className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {auditLogs.filter(log => log.eventCategory === 'SECURITY').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Requires attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Executions</CardTitle>
              <Activity className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {auditLogs.filter(log => log.eventCategory === 'EXECUTION').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Changeset executions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Auth Events</CardTitle>
              <User className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {auditLogs.filter(log => log.eventCategory === 'AUTHENTICATION').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Login attempts
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  );
}

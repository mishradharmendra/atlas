'use client';

import { useEffect, useState } from 'react';
import { DBSerenityAPI, ChangesetExecutionResponse } from '@/lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import {
  Activity,
  Search,
  Filter,
  Download,
  Eye,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Calendar,
  Database,
  FileText
} from 'lucide-react';
import { formatDate, formatDuration, getStatusColor, getEnvironmentColor, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function HistoryPage() {
  const [executions, setExecutions] = useState<ChangesetExecutionResponse[]>([]);
  const [filteredExecutions, setFilteredExecutions] = useState<ChangesetExecutionResponse[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [environmentFilter, setEnvironmentFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedExecution, setSelectedExecution] = useState<ChangesetExecutionResponse | null>(null);

  useEffect(() => {
    loadExecutions();
  }, []);

  useEffect(() => {
    // Filter executions based on search and filters
    let filtered = executions;

    if (searchTerm) {
      filtered = filtered.filter(execution =>
        execution.executionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        execution.tenantId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (execution.message && execution.message.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (statusFilter) {
      filtered = filtered.filter(execution => execution.status === statusFilter);
    }

    if (environmentFilter) {
      filtered = filtered.filter(execution => execution.environment === environmentFilter);
    }

    setFilteredExecutions(filtered);
  }, [executions, searchTerm, statusFilter, environmentFilter]);

  const loadExecutions = async () => {
    try {
      setIsLoading(true);
      const response = await DBSerenityAPI.getExecutionHistory(0, 50);
      setExecutions(response.executions || []);
    } catch (error) {
      console.error('Failed to load execution history:', error);
      toast.error('Failed to load execution history');
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = (execution: ChangesetExecutionResponse) => {
    setSelectedExecution(execution);
  };

  const handleRefresh = () => {
    loadExecutions();
    toast.success('Execution history refreshed');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'SUCCESS':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'FAILED':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'RUNNING':
      case 'STARTED':
        return <Clock className="w-4 h-4 text-blue-600 animate-pulse" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Execution History</h1>
          <p className="text-gray-600">Track and monitor all changeset executions</p>
        </div>
        <Button onClick={handleRefresh} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search executions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="">All Statuses</option>
              <option value="SUCCESS">Success</option>
              <option value="FAILED">Failed</option>
              <option value="RUNNING">Running</option>
              <option value="STARTED">Started</option>
            </select>
            <select
              value={environmentFilter}
              onChange={(e) => setEnvironmentFilter(e.target.value)}
              className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="">All Environments</option>
              <option value="dev">Development</option>
              <option value="staging">Staging</option>
              <option value="prod">Production</option>
            </select>
            <div className="flex items-center text-sm text-gray-600">
              <Filter className="w-4 h-4 mr-2" />
              {filteredExecutions.length} results
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Execution List */}
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : filteredExecutions.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No executions found</h3>
            <p className="text-gray-500">
              {searchTerm || statusFilter || environmentFilter
                ? 'No executions match your current filters'
                : 'No changeset executions have been performed yet'
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredExecutions.map((execution) => (
            <Card key={execution.executionId} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(execution.status)}
                    <div>
                      <h3 className="font-medium text-gray-900">{execution.executionId}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center">
                          <Database className="w-3 h-3 mr-1" />
                          {execution.tenantId}
                        </span>
                        <span className={cn(
                          "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                          getEnvironmentColor(execution.environment)
                        )}>
                          {execution.environment}
                        </span>
                        <span className="capitalize">{execution.mode}</span>
                        <span className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(execution.startedAt)}
                        </span>
                        {execution.durationMs && (
                          <span className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {formatDuration(execution.durationMs)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className={cn(
                      "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium",
                      getStatusColor(execution.status)
                    )}>
                      {execution.status}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewDetails(execution)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Details
                    </Button>
                  </div>
                </div>

                {/* Summary Stats */}
                {execution.summary && (
                  <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 p-3 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <p className="text-lg font-semibold text-green-600">
                        {execution.summary.changesetsExecuted || 0}
                      </p>
                      <p className="text-xs text-gray-600">Executed</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-yellow-600">
                        {execution.summary.changesetsSkipped || 0}
                      </p>
                      <p className="text-xs text-gray-600">Skipped</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-red-600">
                        {execution.summary.changesetsFailed || 0}
                      </p>
                      <p className="text-xs text-gray-600">Failed</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-blue-600">
                        {execution.summary.sqlStatementsExecuted || 0}
                      </p>
                      <p className="text-xs text-gray-600">SQL Statements</p>
                    </div>
                  </div>
                )}

                {execution.message && (
                  <div className="mt-3 p-2 bg-blue-50 rounded text-sm text-blue-800">
                    {execution.message}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Execution Details Modal */}
      {selectedExecution && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">Execution Details</h2>
                <Button variant="ghost" onClick={() => setSelectedExecution(null)}>
                  ×
                </Button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              {/* Execution Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Execution ID</p>
                  <p className="font-mono">{selectedExecution.executionId}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <span className={cn(
                    "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                    getStatusColor(selectedExecution.status)
                  )}>
                    {selectedExecution.status}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Environment</p>
                  <span className={cn(
                    "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                    getEnvironmentColor(selectedExecution.environment)
                  )}>
                    {selectedExecution.environment}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Mode</p>
                  <p className="capitalize">{selectedExecution.mode}</p>
                </div>
              </div>

              {/* Logs */}
              {selectedExecution.logs && selectedExecution.logs.length > 0 && (
                <div>
                  <h3 className="font-medium mb-3 flex items-center">
                    <FileText className="w-4 h-4 mr-2" />
                    Execution Logs
                  </h3>
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg max-h-96 overflow-y-auto font-mono text-sm">
                    {selectedExecution.logs.map((log, index) => (
                      <div key={index} className="mb-1 leading-relaxed">
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

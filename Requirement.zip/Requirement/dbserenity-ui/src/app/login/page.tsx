'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { 
  Database, 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  Shield, 
  Zap, 
  CheckCircle,
  ArrowLeft,
  Mail,
  Key
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [clientId, setClientId] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!clientId || !clientSecret) {
      toast.error('Please enter both Client ID and Client Secret');
      return;
    }

    setIsLoading(true);
    try {
      await login(clientId, clientSecret);
      toast.success('Welcome to DBSerenity!');
      router.push('/dashboard');
    } catch (error: any) {
      toast.error(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const fillDemoCredentials = () => {
    setClientId('platform-admin-client');
    setClientSecret('admin-secret-change-in-production');
    toast.success('Demo credentials filled');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-20 left-10 w-96 h-96 bg-blue-500/20 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
          <div className="absolute top-40 right-10 w-96 h-96 bg-purple-500/20 rounded-full mix-blend-multiply filter blur-3xl animate-pulse animation-delay-2000"></div>
          <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-indigo-500/20 rounded-full mix-blend-multiply filter blur-3xl animate-pulse animation-delay-4000"></div>
        </div>
      </div>

      {/* Back to home */}
      <div className="absolute top-6 left-6 z-10">
        <Button
          variant="ghost"
          onClick={() => router.push('/')}
          className="text-white/80 hover:text-white hover:bg-white/10 backdrop-blur-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo and Header */}
          <div className="text-center mb-8 animate-fade-in-up">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl mb-6 shadow-2xl">
              <Database className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-2">Welcome Back</h1>
            <p className="text-blue-200">Sign in to your DBSerenity account</p>
          </div>

          {/* Login Card */}
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 p-8 animate-scale-in">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="form-label text-white">Client ID</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Enter your client ID"
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    className="pl-12 bg-white/10 border-white/20 text-white placeholder-gray-300 focus:bg-white/20 focus:border-white/40 transition-all duration-200"
                    disabled={isLoading}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="form-label text-white">Client Secret</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your client secret"
                    value={clientSecret}
                    onChange={(e) => setClientSecret(e.target.value)}
                    className="pl-12 pr-12 bg-white/10 border-white/20 text-white placeholder-gray-300 focus:bg-white/20 focus:border-white/40 transition-all duration-200"
                    disabled={isLoading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200 font-semibold"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                    Signing In...
                  </div>
                ) : (
                  <>
                    <Shield className="w-5 h-5 mr-2" />
                    Sign In Securely
                  </>
                )}
              </Button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-8 p-6 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-white flex items-center">
                  <Key className="w-4 h-4 mr-2" />
                  Demo Credentials
                </h3>
                <Button
                  type="button"
                  onClick={fillDemoCredentials}
                  className="text-xs bg-blue-600/20 hover:bg-blue-600/30 text-blue-200 px-3 py-1 rounded-lg transition-colors"
                >
                  Use Demo
                </Button>
              </div>
              
              <div className="space-y-3 text-sm">
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <div className="flex items-center text-blue-200 mb-1">
                    <Shield className="w-3 h-3 mr-1" />
                    <span className="font-medium">Admin Access</span>
                  </div>
                  <p className="text-xs text-gray-300 font-mono">platform-admin-client</p>
                  <p className="text-xs text-gray-400 mt-1">Full platform management access</p>
                </div>
                
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <div className="flex items-center text-green-200 mb-1">
                    <User className="w-3 h-3 mr-1" />
                    <span className="font-medium">Tenant Access</span>
                  </div>
                  <p className="text-xs text-gray-400">Create a tenant first to get credentials</p>
                </div>
              </div>
            </div>

            {/* Security Features */}
            <div className="mt-6 flex items-center justify-center space-x-6 text-xs text-gray-300">
              <div className="flex items-center">
                <Lock className="w-3 h-3 mr-1" />
                <span>JWT Secured</span>
              </div>
              <div className="flex items-center">
                <Shield className="w-3 h-3 mr-1" />
                <span>Enterprise Grade</span>
              </div>
              <div className="flex items-center">
                <Zap className="w-3 h-3 mr-1" />
                <span>Real-time</span>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-12">
            <p className="text-gray-400 text-sm">
              © 2025 DBSerenity Platform. Secure database schema versioning solution.
            </p>
            <div className="flex items-center justify-center space-x-4 mt-4 text-xs text-gray-500">
              <a href="#" className="hover:text-gray-300 transition-colors">Privacy Policy</a>
              <span>•</span>
              <a href="#" className="hover:text-gray-300 transition-colors">Terms of Service</a>
              <span>•</span>
              <a href="#" className="hover:text-gray-300 transition-colors">Support</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
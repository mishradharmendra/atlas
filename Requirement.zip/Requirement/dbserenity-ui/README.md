# DBSerenity UI Portal

A modern, intuitive dashboard for the DBSerenity platform built with Next.js, TypeScript, and Tailwind CSS.

## 🚀 Features

### Admin Dashboard
- **Tenant Management**: Create, edit, delete, and manage all tenants
- **Platform Analytics**: Comprehensive insights and metrics
- **Audit Logs**: Monitor all system activities and security events
- **Execution Monitoring**: Track all changeset executions across tenants
- **Repository Templates**: Generate and manage tenant repositories

### Tenant Dashboard
- **Changeset Execution**: Run database scripts with dry-run and execute modes
- **Execution History**: View and monitor previous runs
- **Analytics**: Tenant-specific performance metrics and insights
- **Repository Management**: Access generated repository templates
- **Real-time Monitoring**: Live execution status and progress tracking

### Key Features
- ✅ **Role-based Access Control** - Admin and tenant specific dashboards
- ✅ **JWT Authentication** - Secure login with client credentials
- ✅ **Real-time Updates** - Live execution monitoring and status updates
- ✅ **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- ✅ **Modern UI/UX** - Intuitive interface with rich visualizations
- ✅ **Comprehensive Analytics** - Charts, graphs, and performance metrics
- ✅ **Production Ready** - Built with enterprise-grade best practices

## 🛠️ Technology Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Custom components with Headless UI
- **Charts**: Recharts for data visualization
- **HTTP Client**: Axios with interceptors
- **Form Handling**: React Hook Form with Zod validation
- **State Management**: React Query for server state
- **Icons**: Lucide React and Heroicons
- **Notifications**: React Hot Toast

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm 9+
- DBSerenity Platform running on http://localhost:8080

### Installation

1. **Install dependencies**
   ```bash
   cd dbserenity-ui
   npm install
   ```

2. **Configure environment**
   ```bash
   # Create .env.local file
   echo "NEXT_PUBLIC_API_URL=http://localhost:8080/api" > .env.local
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Access the application**
   - **URL**: http://localhost:3000
   - **Login**: Use your DBSerenity client credentials

### Production Build

```bash
# Build for production
npm run build

# Start production server
npm start
```

## 📱 User Interface

### Login Page
- Clean, professional login interface
- Client ID and Client Secret authentication
- Demo credentials provided for testing
- Responsive design with gradient background

### Admin Dashboard
- **Overview**: Platform statistics and recent activity
- **Tenant Management**: Complete CRUD operations for tenants
- **Analytics**: Platform-wide metrics and insights
- **Audit Logs**: Comprehensive activity monitoring
- **Execution Monitoring**: Track all changeset executions

### Tenant Dashboard
- **Overview**: Tenant-specific statistics and activity
- **Execute Scripts**: Run changesets with advanced options
- **Execution History**: View and analyze previous runs
- **Analytics**: Performance metrics and success rates
- **Repository**: Access generated templates and configurations

## 🎨 UI Components

### Dashboard Features
- **Responsive Grid Layout** - Adapts to all screen sizes
- **Interactive Charts** - Bar charts, pie charts, line graphs
- **Real-time Status** - Live updates with WebSocket-like polling
- **Advanced Filtering** - Search and filter across all data
- **Export Functionality** - Download reports and logs
- **Modal Dialogs** - Detailed views and forms

### Visual Elements
- **Status Indicators** - Color-coded status badges
- **Progress Bars** - Execution progress visualization
- **Loading States** - Skeleton loaders and spinners
- **Empty States** - Helpful messages when no data
- **Error Handling** - User-friendly error messages
- **Success Feedback** - Toast notifications and confirmations

## 🔐 Authentication & Security

### Login Flow
1. User enters Client ID and Client Secret
2. System authenticates with DBSerenity platform
3. JWT token stored securely in localStorage
4. User redirected to appropriate dashboard based on role

### Role-based Access
- **Admin Users**: Full platform access including tenant management
- **Tenant Users**: Access to their own tenant data and operations
- **Protected Routes**: Automatic redirection based on authentication status
- **Scope-based Permissions**: API calls restricted by user scopes

## 📊 Analytics & Monitoring

### Admin Analytics
- **Tenant Statistics**: Total, active, inactive tenants
- **Execution Metrics**: Success rates, failure analysis
- **Performance Trends**: Historical data and patterns
- **System Health**: Platform status and availability

### Tenant Analytics
- **Execution History**: Success rates and performance
- **Environment Distribution**: Dev, staging, production usage
- **Performance Metrics**: Average execution times
- **Changeset Statistics**: Total changesets executed

## 🔧 Configuration

### Environment Variables
```bash
# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:8080/api

# Optional: Custom branding
NEXT_PUBLIC_APP_NAME=DBSerenity Platform
NEXT_PUBLIC_COMPANY_NAME=Your Company
```

### API Integration
The UI automatically connects to the DBSerenity platform API:
- **Base URL**: Configurable via environment variables
- **Authentication**: JWT token-based with automatic refresh
- **Error Handling**: Comprehensive error management
- **Request Interceptors**: Automatic token attachment
- **Response Interceptors**: Auth error handling

## 🚀 Deployment

### Development
```bash
npm run dev
```

### Production
```bash
# Build the application
npm run build

# Start production server
npm start
```

### Docker Deployment
```bash
# Build Docker image
docker build -t dbserenity-ui .

# Run container
docker run -p 3000:3000 -e NEXT_PUBLIC_API_URL=http://your-api-url dbserenity-ui
```

## 📁 Project Structure

```
dbserenity-ui/
├── src/
│   ├── app/                    # Next.js App Router pages
│   │   ├── dashboard/          # Dashboard pages
│   │   │   ├── tenants/        # Admin tenant management
│   │   │   ├── execute/        # Tenant script execution
│   │   │   ├── history/        # Execution history
│   │   │   ├── analytics/      # Analytics dashboard
│   │   │   └── audit/          # Audit logs (admin only)
│   │   ├── login/              # Login page
│   │   ├── layout.tsx          # Root layout
│   │   └── page.tsx            # Home page
│   ├── components/             # Reusable UI components
│   │   ├── ui/                 # Base UI components
│   │   └── layout/             # Layout components
│   └── lib/                    # Utilities and configurations
│       ├── api.ts              # API client and types
│       ├── auth.ts             # Authentication logic
│       └── utils.ts            # Utility functions
├── public/                     # Static assets
├── tailwind.config.ts          # Tailwind configuration
├── next.config.js              # Next.js configuration
└── package.json                # Dependencies and scripts
```

## 🎯 Usage Examples

### Admin Login
```
Client ID: platform-admin-client
Client Secret: admin-secret-change-in-production
```

### Tenant Login
```
Client ID: your-tenant-client-id
Client Secret: your-tenant-client-secret
```

### Creating a Tenant (Admin)
1. Navigate to Dashboard → Tenants
2. Click "Add Tenant"
3. Fill in tenant details
4. Configure environments
5. Generate client credentials

### Executing Changesets (Tenant)
1. Navigate to Dashboard → Execute Scripts
2. Enter artifact URL
3. Select environment and mode
4. Configure advanced options
5. Run validation or execute

## 🔍 Troubleshooting

### Common Issues

1. **API Connection Failed**
   - Check if DBSerenity platform is running
   - Verify API URL in environment variables
   - Check network connectivity

2. **Authentication Failed**
   - Verify client credentials are correct
   - Check if tenant is active
   - Ensure credentials haven't expired

3. **UI Not Loading**
   - Check browser console for errors
   - Verify all dependencies are installed
   - Try clearing browser cache

### Development Tips
- Use browser dev tools to inspect API calls
- Check the Network tab for failed requests
- Monitor console for JavaScript errors
- Use React Developer Tools for debugging

## 📄 License

This project is proprietary software. Unauthorized access or distribution is prohibited.

---

**DBSerenity UI Portal** - Modern dashboard for enterprise database schema versioning
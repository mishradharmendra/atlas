-- liquibase formatted sql

-- changeset dbserenity:001-create-tenants-table labels:v1.0 context:platform
-- comment: Create tenants table for managing tenant information

-- Extensions not needed for H2
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create tenants table
CREATE TABLE tenants (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    uuid UUID DEFAULT RANDOM_UUID() UNIQUE NOT NULL,
    tenant_id VARCHAR(100) UNIQUE NOT NULL,
    tenant_name VARCHAR(255) NOT NULL,
    description TEXT,
    contact_email VARCHAR(255) NOT NULL,
    github_org VARCHAR(100),
    github_repo VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    
    CONSTRAINT tenants_tenant_id_format CHECK (tenant_id REGEXP '^[a-z0-9-]+$'),
    CONSTRAINT tenants_email_format CHECK (contact_email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Create tenant environments table
CREATE TABLE tenant_environments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    environment_name VARCHAR(50) NOT NULL,
    jdbc_url VARCHAR(500) NOT NULL,
    username VARCHAR(100) NOT NULL,
    schema_name VARCHAR(100),
    contexts TEXT[], -- Array of Liquibase contexts
    labels TEXT[], -- Array of Liquibase labels
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT tenant_environments_unique UNIQUE (tenant_id, environment_name),
    CONSTRAINT tenant_environments_env_name_valid CHECK (environment_name IN ('dev', 'staging', 'prod'))
);

-- Create indexes
CREATE INDEX idx_tenants_tenant_id ON tenants(tenant_id);
CREATE INDEX idx_tenants_active ON tenants(is_active);
CREATE INDEX idx_tenants_created_at ON tenants(created_at);

CREATE INDEX idx_tenant_environments_tenant_id ON tenant_environments(tenant_id);
CREATE INDEX idx_tenant_environments_env_name ON tenant_environments(environment_name);
CREATE INDEX idx_tenant_environments_active ON tenant_environments(is_active);

-- Triggers not supported in H2, will be handled by application layer
-- CREATE OR REPLACE FUNCTION update_updated_at_column()...
-- CREATE TRIGGER update_tenants_updated_at...
-- CREATE TRIGGER update_tenant_environments_updated_at...

-- rollback DROP TRIGGER IF EXISTS update_tenant_environments_updated_at ON tenant_environments;
-- rollback DROP TRIGGER IF EXISTS update_tenants_updated_at ON tenants;
-- rollback DROP FUNCTION IF EXISTS update_updated_at_column();
-- rollback DROP TABLE IF EXISTS tenant_environments CASCADE;
-- rollback DROP TABLE IF EXISTS tenants CASCADE;
-- rollback DROP EXTENSION IF EXISTS "pgcrypto";
-- rollback DROP EXTENSION IF EXISTS "uuid-ossp";

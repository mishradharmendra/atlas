-- liquibase formatted sql

-- changeset dbserenity:008-insert-initial-data labels:v1.0 context:platform
-- comment: Insert initial platform data and sample configurations

-- Insert platform admin tenant (for platform management)
INSERT INTO tenants (tenant_id, tenant_name, description, contact_email, is_active, created_by)
VALUES (
    'platform-admin',
    'Platform Administration',
    'Internal tenant for platform administration and monitoring',
    'admin@dbserenity.com',
    true,
    'system'
) ON CONFLICT (tenant_id) DO NOTHING;

-- Insert platform admin environment
DO $$
DECLARE
    admin_tenant_id BIGINT;
BEGIN
    SELECT id INTO admin_tenant_id FROM tenants WHERE tenant_id = 'platform-admin';
    
    IF admin_tenant_id IS NOT NULL THEN
        INSERT INTO tenant_environments (tenant_id, environment_name, jdbc_url, username, schema_name)
        VALUES (
            admin_tenant_id,
            'prod',
            'jdbc:postgresql://localhost:5432/dbserenity',
            'dbserenity_admin',
            'public'
        ) ON CONFLICT (tenant_id, environment_name) DO NOTHING;
    END IF;
END $$;

-- Insert platform admin client credentials
DO $$
DECLARE
    admin_tenant_id BIGINT;
    client_secret_salt VARCHAR(100);
    client_secret_hash VARCHAR(255);
BEGIN
    SELECT id INTO admin_tenant_id FROM tenants WHERE tenant_id = 'platform-admin';
    
    IF admin_tenant_id IS NOT NULL THEN
        -- Generate salt and hash for admin credentials
        client_secret_salt := encode(gen_random_bytes(16), 'base64');
        client_secret_hash := encode(digest('admin-secret-change-in-production' || client_secret_salt, 'sha256'), 'hex');
        
        INSERT INTO client_credentials (
            tenant_id, 
            client_id, 
            client_secret_hash, 
            client_secret_salt, 
            scopes, 
            created_by
        )
        VALUES (
            admin_tenant_id,
            'platform-admin-client',
            client_secret_hash,
            client_secret_salt,
            ARRAY['changeset:execute', 'changeset:status', 'admin:read', 'admin:write'],
            'system'
        ) ON CONFLICT (client_id) DO NOTHING;
    END IF;
END $$;

-- Log initial platform setup
SELECT log_system_event(
    'PLATFORM_INITIALIZED',
    'INFO',
    'platform-setup',
    'DBSerenity platform initialized with default configuration',
    '{"version": "1.0.0", "environment": "development"}'
);

-- Log audit event for platform setup
SELECT log_audit_event(
    'PLATFORM_SETUP',
    'SYSTEM',
    'platform',
    'platform-admin',
    NULL,
    'system',
    'platform-admin-client',
    'CREATE',
    NULL,
    '{"action": "platform_initialized", "version": "1.0.0"}',
    'Platform initialized with default configuration'
);

-- rollback DELETE FROM client_credentials WHERE client_id = 'platform-admin-client';
-- rollback DELETE FROM tenant_environments WHERE tenant_id = (SELECT id FROM tenants WHERE tenant_id = 'platform-admin');
-- rollback DELETE FROM tenants WHERE tenant_id = 'platform-admin';

-- liquibase formatted sql

-- Master changelog file for DBSerenity Platform database schema
-- This file includes all platform-specific changesets

-- changeset dbserenity:platform-1.0.0 labels:v1.0 context:platform
-- include file:changesets/v1.0/001-create-tenants-table.sql
-- include file:changesets/v1.0/002-create-client-credentials-table.sql
-- include file:changesets/v1.0/003-create-execution-logs-table-h2.sql
-- Temporarily disabled for H2 compatibility - will be enabled for PostgreSQL
-- include file:changesets/v1.0/004-create-audit-logs-table.sql
-- include file:changesets/v1.0/005-create-system-config-table.sql
-- include file:changesets/v1.0/006-create-notification-templates-table.sql
-- include file:changesets/v1.0/007-create-indexes.sql
-- include file:changesets/v1.0/008-insert-initial-data.sql

-- Development-specific changesets
-- changeset dbserenity:dev-data labels:v1.0 context:dev
-- include file:changesets/dev/001-dev-test-data.sql

-- Production-specific changesets  
-- changeset dbserenity:prod-config labels:v1.0 context:prod
-- include file:changesets/prod/001-prod-configurations.sql

-- liquibase formatted sql

-- changeset dbserenity:007-create-indexes labels:v1.0 context:platform
-- comment: Create additional indexes for performance optimization

-- Additional indexes for tenants table
CREATE INDEX idx_tenants_contact_email ON tenants(contact_email);
CREATE INDEX idx_tenants_github_org ON tenants(github_org);
CREATE INDEX idx_tenants_github_repo ON tenants(github_repo);
CREATE INDEX idx_tenants_created_by ON tenants(created_by);

-- Additional indexes for tenant_environments table
CREATE INDEX idx_tenant_environments_jdbc_url ON tenant_environments(jdbc_url);
CREATE INDEX idx_tenant_environments_username ON tenant_environments(username);
CREATE INDEX idx_tenant_environments_schema_name ON tenant_environments(schema_name);

-- Additional indexes for client_credentials table
CREATE INDEX idx_client_credentials_created_by ON client_credentials(created_by);
CREATE INDEX idx_client_credentials_last_used ON client_credentials(last_used_at);

-- Additional indexes for api_tokens table
CREATE INDEX idx_api_tokens_created_at ON api_tokens(created_at);
CREATE INDEX idx_api_tokens_ip_address ON api_tokens(ip_address);

-- Composite indexes for common queries
CREATE INDEX idx_execution_logs_tenant_env ON execution_logs(tenant_id, environment);
CREATE INDEX idx_execution_logs_tenant_status ON execution_logs(tenant_id, status);
CREATE INDEX idx_execution_logs_client_status ON execution_logs(client_id, status);
CREATE INDEX idx_execution_logs_status_started ON execution_logs(status, started_at);

-- Composite indexes for audit logs
CREATE INDEX idx_audit_logs_tenant_timestamp ON audit_logs(tenant_id, timestamp);
CREATE INDEX idx_audit_logs_user_timestamp ON audit_logs(user_id, timestamp);
CREATE INDEX idx_audit_logs_client_timestamp ON audit_logs(client_id, timestamp);
CREATE INDEX idx_audit_logs_category_timestamp ON audit_logs(event_category, timestamp);

-- Partial indexes for active records
CREATE INDEX idx_tenants_active_created ON tenants(created_at) WHERE is_active = true;
CREATE INDEX idx_client_credentials_active_created ON client_credentials(created_at) WHERE is_active = true;
CREATE INDEX idx_tenant_environments_active_created ON tenant_environments(created_at) WHERE is_active = true;

-- Partial indexes for running executions
CREATE INDEX idx_execution_logs_running ON execution_logs(started_at) WHERE status IN ('STARTED', 'RUNNING');
CREATE INDEX idx_execution_logs_failed ON execution_logs(started_at) WHERE status = 'FAILED';

-- Expression indexes for case-insensitive searches
CREATE INDEX idx_tenants_name_lower ON tenants(LOWER(tenant_name));
CREATE INDEX idx_tenants_email_lower ON tenants(LOWER(contact_email));

-- rollback DROP INDEX IF EXISTS idx_tenants_email_lower;
-- rollback DROP INDEX IF EXISTS idx_tenants_name_lower;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_failed;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_running;
-- rollback DROP INDEX IF EXISTS idx_tenant_environments_active_created;
-- rollback DROP INDEX IF EXISTS idx_client_credentials_active_created;
-- rollback DROP INDEX IF EXISTS idx_tenants_active_created;
-- rollback DROP INDEX IF EXISTS idx_audit_logs_category_timestamp;
-- rollback DROP INDEX IF EXISTS idx_audit_logs_client_timestamp;
-- rollback DROP INDEX IF EXISTS idx_audit_logs_user_timestamp;
-- rollback DROP INDEX IF EXISTS idx_audit_logs_tenant_timestamp;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_status_started;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_client_status;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_tenant_status;
-- rollback DROP INDEX IF EXISTS idx_execution_logs_tenant_env;
-- rollback DROP INDEX IF EXISTS idx_api_tokens_ip_address;
-- rollback DROP INDEX IF EXISTS idx_api_tokens_created_at;
-- rollback DROP INDEX IF EXISTS idx_client_credentials_last_used;
-- rollback DROP INDEX IF EXISTS idx_client_credentials_created_by;
-- rollback DROP INDEX IF EXISTS idx_tenant_environments_schema_name;
-- rollback DROP INDEX IF EXISTS idx_tenant_environments_username;
-- rollback DROP INDEX IF EXISTS idx_tenant_environments_jdbc_url;
-- rollback DROP INDEX IF EXISTS idx_tenants_created_by;
-- rollback DROP INDEX IF EXISTS idx_tenants_github_repo;
-- rollback DROP INDEX IF EXISTS idx_tenants_github_org;
-- rollback DROP INDEX IF EXISTS idx_tenants_contact_email;

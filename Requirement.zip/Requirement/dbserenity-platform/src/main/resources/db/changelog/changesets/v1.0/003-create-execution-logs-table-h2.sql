-- liquibase formatted sql

-- changeset dbserenity:003-create-execution-logs-table labels:v1.0 context:platform
-- comment: Create execution logs table for tracking changeset executions (H2 compatible)

-- Create execution logs table
CREATE TABLE execution_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    execution_id VARCHAR(100) UNIQUE NOT NULL,
    tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id VARCHAR(100) NOT NULL,
    environment VARCHAR(50) NOT NULL,
    mode VARCHAR(20) NOT NULL,
    artifact_url VARCHAR(500) NOT NULL,
    status VARCHAR(50) NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms BIGINT,
    message TEXT,
    error_message TEXT,
    changesets_executed INTEGER,
    changesets_skipped INTEGER,
    changesets_failed INTEGER,
    sql_statements_executed INTEGER,
    database_version VARCHAR(100),
    liquibase_version VARCHAR(50),
    contexts VARCHAR(500),
    labels VARCHAR(500),
    rollback_executed BOOLEAN DEFAULT false,
    notification_sent BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT execution_logs_environment_valid CHECK (environment IN ('dev', 'staging', 'prod')),
    CONSTRAINT execution_logs_mode_valid CHECK (mode IN ('dry-run', 'execute')),
    CONSTRAINT execution_logs_status_valid CHECK (status IN ('STARTED', 'RUNNING', 'SUCCESS', 'FAILED', 'CANCELLED'))
);

-- Create execution log metadata table
CREATE TABLE execution_log_metadata (
    execution_log_id BIGINT NOT NULL REFERENCES execution_logs(id) ON DELETE CASCADE,
    metadata_key VARCHAR(100) NOT NULL,
    metadata_value TEXT,
    PRIMARY KEY (execution_log_id, metadata_key)
);

-- Create indexes
CREATE INDEX idx_execution_logs_execution_id ON execution_logs(execution_id);
CREATE INDEX idx_execution_logs_tenant_id ON execution_logs(tenant_id);
CREATE INDEX idx_execution_logs_client_id ON execution_logs(client_id);
CREATE INDEX idx_execution_logs_status ON execution_logs(status);
CREATE INDEX idx_execution_logs_environment ON execution_logs(environment);
CREATE INDEX idx_execution_logs_started_at ON execution_logs(started_at);

-- rollback DROP TABLE IF EXISTS execution_log_metadata CASCADE;
-- rollback DROP TABLE IF EXISTS execution_logs CASCADE;

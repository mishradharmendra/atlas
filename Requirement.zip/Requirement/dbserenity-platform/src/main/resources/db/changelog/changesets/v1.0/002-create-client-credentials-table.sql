-- liquibase formatted sql

-- changeset dbserenity:002-create-client-credentials-table labels:v1.0 context:platform
-- comment: Create client credentials table for tenant authentication

-- Create client credentials table
CREATE TABLE client_credentials (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id VARCHAR(100) UNIQUE NOT NULL,
    client_secret_hash VARCHAR(255) NOT NULL,
    client_secret_salt VARCHAR(100) NOT NULL,
    scopes VARCHAR(500) DEFAULT 'changeset:execute,changeset:status',
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMP,
    last_used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    
    CONSTRAINT client_credentials_client_id_format CHECK (client_id REGEXP '^[a-z0-9-]+$')
);

-- Create API tokens table for temporary access tokens
CREATE TABLE api_tokens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    client_credentials_id BIGINT NOT NULL REFERENCES client_credentials(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    token_type VARCHAR(20) DEFAULT 'Bearer',
    scopes VARCHAR(500),
    expires_at TIMESTAMP NOT NULL,
    is_revoked BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used_at TIMESTAMP,
    user_agent TEXT,
    ip_address VARCHAR(45),
    
    CONSTRAINT api_tokens_token_type_valid CHECK (token_type IN ('Bearer', 'Basic'))
);

-- Create indexes
CREATE INDEX idx_client_credentials_tenant_id ON client_credentials(tenant_id);
CREATE INDEX idx_client_credentials_client_id ON client_credentials(client_id);
CREATE INDEX idx_client_credentials_active ON client_credentials(is_active);
CREATE INDEX idx_client_credentials_expires_at ON client_credentials(expires_at);

CREATE INDEX idx_api_tokens_client_credentials_id ON api_tokens(client_credentials_id);
CREATE INDEX idx_api_tokens_token_hash ON api_tokens(token_hash);
CREATE INDEX idx_api_tokens_expires_at ON api_tokens(expires_at);
CREATE INDEX idx_api_tokens_revoked ON api_tokens(is_revoked);

-- Triggers not supported in H2, will be handled by application layer
-- CREATE TRIGGER update_client_credentials_updated_at...

-- Functions not supported in H2, will be handled by application layer
-- CREATE OR REPLACE FUNCTION generate_client_id(tenant_name TEXT)...
-- CREATE OR REPLACE FUNCTION hash_client_secret(secret TEXT, salt TEXT)...
-- CREATE OR REPLACE FUNCTION verify_client_secret(secret TEXT, salt TEXT, hash TEXT)...

-- rollback DROP FUNCTION IF EXISTS verify_client_secret(TEXT, TEXT, TEXT);
-- rollback DROP FUNCTION IF EXISTS hash_client_secret(TEXT, TEXT);
-- rollback DROP FUNCTION IF EXISTS generate_client_id(TEXT);
-- rollback DROP TRIGGER IF EXISTS update_client_credentials_updated_at ON client_credentials;
-- rollback DROP TABLE IF EXISTS api_tokens CASCADE;
-- rollback DROP TABLE IF EXISTS client_credentials CASCADE;

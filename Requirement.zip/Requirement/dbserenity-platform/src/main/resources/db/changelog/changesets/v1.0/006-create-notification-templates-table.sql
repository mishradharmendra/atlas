-- liquibase formatted sql

-- changeset dbserenity:006-create-notification-templates-table labels:v1.0 context:platform
-- comment: Create notification templates table for email templates

-- Create notification templates table
CREATE TABLE notification_templates (
    id BIGSERIAL PRIMARY KEY,
    template_name VARCHAR(100) UNIQUE NOT NULL,
    template_type VARCHAR(20) NOT NULL,
    subject_template TEXT,
    body_template TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    
    CONSTRAINT notification_templates_type_valid CHECK (template_type IN ('EMAIL', 'SMS', 'SLACK', 'WEBHOOK'))
);

-- Create indexes
CREATE INDEX idx_notification_templates_name ON notification_templates(template_name);
CREATE INDEX idx_notification_templates_type ON notification_templates(template_type);
CREATE INDEX idx_notification_templates_active ON notification_templates(is_active);

-- Create trigger for updated_at
CREATE TRIGGER update_notification_templates_updated_at 
    BEFORE UPDATE ON notification_templates 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insert default email templates
INSERT INTO notification_templates (template_name, template_type, subject_template, body_template, created_by) VALUES
    ('execution_success', 'EMAIL', 
     'DBSerenity Execution SUCCESS - {{executionId}} [{{tenantId}}/{{environment}}]',
     'DBSerenity Changeset Execution Report
=====================================

Execution ID: {{executionId}}
Tenant: {{tenantId}}
Environment: {{environment}}
Mode: {{mode}}
Status: {{status}}
Started: {{startedAt}}
Completed: {{completedAt}}
Duration: {{duration}}

✅ Execution completed successfully!

Execution Summary:
-----------------
Changesets Executed: {{changesetsExecuted}}
Changesets Skipped: {{changesetsSkipped}}
Changesets Failed: {{changesetsFailed}}
SQL Statements: {{sqlStatementsExecuted}}
Database Version: {{databaseVersion}}
Liquibase Version: {{liquibaseVersion}}

Artifact: {{artifactUrl}}

This is an automated notification from DBSerenity Platform.
Please do not reply to this email.',
     'system'),

    ('execution_failure', 'EMAIL',
     'DBSerenity Execution FAILED - {{executionId}} [{{tenantId}}/{{environment}}]',
     'DBSerenity Changeset Execution Report
=====================================

Execution ID: {{executionId}}
Tenant: {{tenantId}}
Environment: {{environment}}
Mode: {{mode}}
Status: {{status}}
Started: {{startedAt}}
Completed: {{completedAt}}
Duration: {{duration}}

❌ Execution failed!

Error Message:
--------------
{{errorMessage}}

Artifact: {{artifactUrl}}

This is an automated notification from DBSerenity Platform.
Please do not reply to this email.',
     'system'),

    ('tenant_created', 'EMAIL',
     'DBSerenity Tenant Created - {{tenantName}}',
     'Welcome to DBSerenity!

Your tenant has been successfully created:

Tenant ID: {{tenantId}}
Tenant Name: {{tenantName}}
Contact Email: {{contactEmail}}
Created At: {{createdAt}}

You can now start using the DBSerenity platform for database schema versioning.

Next Steps:
1. Use your client credentials to authenticate
2. Set up your tenant environments
3. Create your first changeset repository
4. Execute your first database migration

Best regards,
DBSerenity Team',
     'system'),

    ('tenant_deactivated', 'EMAIL',
     'DBSerenity Tenant Deactivated - {{tenantName}}',
     'Your DBSerenity tenant has been deactivated.

Tenant ID: {{tenantId}}
Tenant Name: {{tenantName}}
Deactivated At: {{deactivatedAt}}
Deactivated By: {{deactivatedBy}}

If you believe this was done in error, please contact your administrator.

Best regards,
DBSerenity Team',
     'system');

-- rollback DROP TRIGGER IF EXISTS update_notification_templates_updated_at ON notification_templates;
-- rollback DROP TABLE IF EXISTS notification_templates CASCADE;

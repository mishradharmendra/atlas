-- liquibase formatted sql

-- changeset dbserenity:004-create-audit-logs-table labels:v1.0 context:platform
-- comment: Create audit logs table for comprehensive audit trail

-- Create audit logs table
CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    event_category VARCHAR(30) NOT NULL,
    entity_type VARCHAR(50),
    entity_id VARCHAR(100),
    tenant_id BIGINT REFERENCES tenants(id) ON DELETE SET NULL,
    user_id VARCHAR(100),
    client_id VARCHAR(100),
    action VARCHAR(50) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[],
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(100),
    correlation_id UUID,
    message TEXT,
    metadata JSONB DEFAULT '{}',
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT audit_logs_event_category_valid CHECK (event_category IN ('AUTHENTICATION', 'TENANT', 'EXECUTION', 'SYSTEM', 'SECURITY')),
    CONSTRAINT audit_logs_action_valid CHECK (action IN ('CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'EXECUTE', 'ROLLBACK', 'ACCESS', 'ERROR'))
);

-- Create system event logs table
CREATE TABLE system_event_logs (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(10) NOT NULL,
    component VARCHAR(100),
    message TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    correlation_id UUID,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT system_event_logs_severity_valid CHECK (severity IN ('DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL'))
);

-- Create indexes for audit logs
CREATE INDEX idx_audit_logs_event_type ON audit_logs(event_type);
CREATE INDEX idx_audit_logs_event_category ON audit_logs(event_category);
CREATE INDEX idx_audit_logs_entity_type ON audit_logs(entity_type);
CREATE INDEX idx_audit_logs_entity_id ON audit_logs(entity_id);
CREATE INDEX idx_audit_logs_tenant_id ON audit_logs(tenant_id);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_client_id ON audit_logs(client_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_correlation_id ON audit_logs(correlation_id);

-- Create indexes for system event logs
CREATE INDEX idx_system_event_logs_event_type ON system_event_logs(event_type);
CREATE INDEX idx_system_event_logs_severity ON system_event_logs(severity);
CREATE INDEX idx_system_event_logs_component ON system_event_logs(component);
CREATE INDEX idx_system_event_logs_timestamp ON system_event_logs(timestamp);
CREATE INDEX idx_system_event_logs_correlation_id ON system_event_logs(correlation_id);

-- Create function to log audit events
CREATE OR REPLACE FUNCTION log_audit_event(
    p_event_type VARCHAR(50),
    p_event_category VARCHAR(30),
    p_entity_type VARCHAR(50) DEFAULT NULL,
    p_entity_id VARCHAR(100) DEFAULT NULL,
    p_tenant_id BIGINT DEFAULT NULL,
    p_user_id VARCHAR(100) DEFAULT NULL,
    p_client_id VARCHAR(100) DEFAULT NULL,
    p_action VARCHAR(50) DEFAULT 'ACCESS',
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL,
    p_message TEXT DEFAULT NULL,
    p_metadata JSONB DEFAULT '{}'
) RETURNS VOID AS $$
BEGIN
    INSERT INTO audit_logs (
        event_type,
        event_category,
        entity_type,
        entity_id,
        tenant_id,
        user_id,
        client_id,
        action,
        old_values,
        new_values,
        message,
        metadata,
        ip_address,
        user_agent,
        session_id,
        correlation_id
    ) VALUES (
        p_event_type,
        p_event_category,
        p_entity_type,
        p_entity_id,
        p_tenant_id,
        p_user_id,
        p_client_id,
        p_action,
        p_old_values,
        p_new_values,
        p_message,
        p_metadata,
        NULLIF(current_setting('app.client_ip', true), '')::INET,
        NULLIF(current_setting('app.user_agent', true), ''),
        NULLIF(current_setting('app.session_id', true), ''),
        NULLIF(current_setting('app.correlation_id', true), '')::UUID
    );
END;
$$ LANGUAGE plpgsql;

-- Create function to log system events
CREATE OR REPLACE FUNCTION log_system_event(
    p_event_type VARCHAR(50),
    p_severity VARCHAR(10),
    p_component VARCHAR(100),
    p_message TEXT,
    p_details JSONB DEFAULT '{}',
    p_correlation_id UUID DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
    INSERT INTO system_event_logs (
        event_type,
        severity,
        component,
        message,
        details,
        correlation_id
    ) VALUES (
        p_event_type,
        p_severity,
        p_component,
        p_message,
        p_details,
        COALESCE(p_correlation_id, NULLIF(current_setting('app.correlation_id', true), '')::UUID)
    );
END;
$$ LANGUAGE plpgsql;

-- rollback DROP FUNCTION IF EXISTS log_system_event(VARCHAR, VARCHAR, VARCHAR, TEXT, JSONB, UUID);
-- rollback DROP FUNCTION IF EXISTS log_audit_event(VARCHAR, VARCHAR, VARCHAR, VARCHAR, BIGINT, VARCHAR, VARCHAR, VARCHAR, JSONB, JSONB, TEXT, JSONB);
-- rollback DROP TABLE IF EXISTS system_event_logs CASCADE;
-- rollback DROP TABLE IF EXISTS audit_logs CASCADE;

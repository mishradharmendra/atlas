-- liquibase formatted sql

-- changeset dbserenity:005-create-system-config-table labels:v1.0 context:platform
-- comment: Create system configuration table for platform settings

-- Create system configuration table
CREATE TABLE system_config (
    id BIGSERIAL PRIMARY KEY,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    description TEXT,
    config_type VARCHAR(20) DEFAULT 'STRING',
    is_encrypted BOOLEAN DEFAULT false,
    is_readonly BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(100),
    
    CONSTRAINT system_config_type_valid CHECK (config_type IN ('STRING', 'INTEGER', 'BOOLEAN', 'JSON', 'ENCRYPTED'))
);

-- Create indexes
CREATE INDEX idx_system_config_key ON system_config(config_key);
CREATE INDEX idx_system_config_type ON system_config(config_type);
CREATE INDEX idx_system_config_readonly ON system_config(is_readonly);

-- Create trigger for updated_at
CREATE TRIGGER update_system_config_updated_at 
    BEFORE UPDATE ON system_config 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insert default system configurations
INSERT INTO system_config (config_key, config_value, description, config_type, is_readonly) VALUES
    ('platform.name', 'DBSerenity Platform', 'Platform name', 'STRING', true),
    ('platform.version', '1.0.0', 'Platform version', 'STRING', true),
    ('platform.environment', 'development', 'Platform environment', 'STRING', false),
    ('execution.max_concurrent', '5', 'Maximum concurrent executions', 'INTEGER', false),
    ('execution.timeout_minutes', '30', 'Default execution timeout in minutes', 'INTEGER', false),
    ('execution.cleanup_days', '30', 'Days to keep execution logs', 'INTEGER', false),
    ('artifact.max_size_mb', '100', 'Maximum artifact size in MB', 'INTEGER', false),
    ('artifact.cleanup_hours', '24', 'Hours to keep downloaded artifacts', 'INTEGER', false),
    ('notification.email_enabled', 'true', 'Enable email notifications', 'BOOLEAN', false),
    ('notification.retry_attempts', '3', 'Number of notification retry attempts', 'INTEGER', false),
    ('security.token_expiry_hours', '24', 'JWT token expiry in hours', 'INTEGER', false),
    ('security.max_login_attempts', '5', 'Maximum login attempts before lockout', 'INTEGER', false),
    ('audit.retention_days', '90', 'Days to keep audit logs', 'INTEGER', false),
    ('maintenance.enabled', 'false', 'Maintenance mode flag', 'BOOLEAN', false);

-- rollback DROP TRIGGER IF EXISTS update_system_config_updated_at ON system_config;
-- rollback DROP TABLE IF EXISTS system_config CASCADE;

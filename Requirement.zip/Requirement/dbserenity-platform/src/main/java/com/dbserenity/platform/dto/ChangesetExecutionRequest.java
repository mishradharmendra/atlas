package com.dbserenity.platform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.Map;

/**
 * DTO for changeset execution request
 */
public class ChangesetExecutionRequest {

    @NotBlank(message = "Client ID is required")
    private String clientId;

    @NotBlank(message = "Client secret is required")
    private String clientSecret;

    @NotBlank(message = "Artifact URL is required")
    private String artifactUrl;

    @NotBlank(message = "Environment is required")
    @Pattern(regexp = "^(dev|staging|prod)$", message = "Environment must be dev, staging, or prod")
    private String environment;

    @NotBlank(message = "Mode is required")
    @Pattern(regexp = "^(dry-run|execute)$", message = "Mode must be dry-run or execute")
    private String mode;

    @NotBlank(message = "Database password is required")
    private String databasePassword;

    private ExecutionOptions executionOptions;

    // Constructors
    public ChangesetExecutionRequest() {}

    public ChangesetExecutionRequest(String clientId, String clientSecret, String artifactUrl, 
                                   String environment, String mode, String databasePassword) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.artifactUrl = artifactUrl;
        this.environment = environment;
        this.mode = mode;
        this.databasePassword = databasePassword;
    }

    // Getters and Setters
    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getArtifactUrl() {
        return artifactUrl;
    }

    public void setArtifactUrl(String artifactUrl) {
        this.artifactUrl = artifactUrl;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getDatabasePassword() {
        return databasePassword;
    }

    public void setDatabasePassword(String databasePassword) {
        this.databasePassword = databasePassword;
    }

    public ExecutionOptions getExecutionOptions() {
        return executionOptions;
    }

    public void setExecutionOptions(ExecutionOptions executionOptions) {
        this.executionOptions = executionOptions;
    }

    @Override
    public String toString() {
        return "ChangesetExecutionRequest{" +
                "clientId='" + clientId + '\'' +
                ", artifactUrl='" + artifactUrl + '\'' +
                ", environment='" + environment + '\'' +
                ", mode='" + mode + '\'' +
                ", executionOptions=" + executionOptions +
                '}';
    }

    /**
     * Execution options for changeset execution
     */
    public static class ExecutionOptions {
        private Boolean rollbackOnFailure = true;
        private String notificationEmail;
        private Integer timeoutMinutes = 30;
        private String contexts;
        private String labels;
        private Map<String, String> parameters;

        // Constructors
        public ExecutionOptions() {}

        // Getters and Setters
        public Boolean getRollbackOnFailure() {
            return rollbackOnFailure;
        }

        public void setRollbackOnFailure(Boolean rollbackOnFailure) {
            this.rollbackOnFailure = rollbackOnFailure;
        }

        public String getNotificationEmail() {
            return notificationEmail;
        }

        public void setNotificationEmail(String notificationEmail) {
            this.notificationEmail = notificationEmail;
        }

        public Integer getTimeoutMinutes() {
            return timeoutMinutes;
        }

        public void setTimeoutMinutes(Integer timeoutMinutes) {
            this.timeoutMinutes = timeoutMinutes;
        }

        public String getContexts() {
            return contexts;
        }

        public void setContexts(String contexts) {
            this.contexts = contexts;
        }

        public String getLabels() {
            return labels;
        }

        public void setLabels(String labels) {
            this.labels = labels;
        }

        public Map<String, String> getParameters() {
            return parameters;
        }

        public void setParameters(Map<String, String> parameters) {
            this.parameters = parameters;
        }

        @Override
        public String toString() {
            return "ExecutionOptions{" +
                    "rollbackOnFailure=" + rollbackOnFailure +
                    ", notificationEmail='" + notificationEmail + '\'' +
                    ", timeoutMinutes=" + timeoutMinutes +
                    ", contexts='" + contexts + '\'' +
                    ", labels='" + labels + '\'' +
                    '}';
        }
    }
}

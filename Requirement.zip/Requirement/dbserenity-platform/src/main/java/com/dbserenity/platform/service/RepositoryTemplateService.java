package com.dbserenity.platform.service;

import com.dbserenity.platform.dto.TenantCreateRequest;
import com.dbserenity.platform.dto.TenantEnvironmentRequest;
import com.dbserenity.platform.entity.Tenant;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Service for generating tenant repository templates
 */
@Service
public class RepositoryTemplateService {

    private static final Logger logger = LoggerFactory.getLogger(RepositoryTemplateService.class);

    private final ObjectMapper objectMapper;
    private final String templatesDirectory;
    private final String outputDirectory;

    public RepositoryTemplateService(ObjectMapper objectMapper,
                                   @Value("${dbserenity.templates.directory:./templates}") String templatesDirectory,
                                   @Value("${dbserenity.templates.output:./generated-repos}") String outputDirectory) {
        this.objectMapper = objectMapper;
        this.templatesDirectory = templatesDirectory;
        this.outputDirectory = outputDirectory;
        
        // Ensure directories exist
        try {
            Files.createDirectories(Paths.get(templatesDirectory));
            Files.createDirectories(Paths.get(outputDirectory));
        } catch (IOException e) {
            logger.error("Failed to create template directories", e);
        }
    }

    /**
     * Generate tenant repository from template
     */
    public RepositoryGenerationResult generateTenantRepository(Tenant tenant, TenantCreateRequest request) {
        logger.info("Generating repository template for tenant: {}", tenant.getTenantId());

        try {
            // Create tenant-specific output directory
            Path tenantRepoPath = Paths.get(outputDirectory, tenant.getTenantId() + "-repo");
            if (Files.exists(tenantRepoPath)) {
                deleteDirectory(tenantRepoPath.toFile());
            }
            Files.createDirectories(tenantRepoPath);

            // Generate template context
            TemplateContext context = createTemplateContext(tenant, request);

            // Generate all template files
            generateMavenPom(tenantRepoPath, context);
            generateTenantConfig(tenantRepoPath, context);
            generateLiquibaseProperties(tenantRepoPath, context);
            generateChangelogMaster(tenantRepoPath, context);
            generateInitialChangesets(tenantRepoPath, context);
            generateGitHubWorkflows(tenantRepoPath, context);
            generateAssemblyDescriptor(tenantRepoPath, context);
            generateReadme(tenantRepoPath, context);
            generateGitIgnore(tenantRepoPath, context);

            logger.info("Repository template generated successfully for tenant: {}", tenant.getTenantId());

            return new RepositoryGenerationResult(
                true,
                tenantRepoPath.toString(),
                "Repository template generated successfully",
                null
            );

        } catch (Exception e) {
            logger.error("Failed to generate repository template for tenant: {}", tenant.getTenantId(), e);
            return new RepositoryGenerationResult(
                false,
                null,
                "Failed to generate repository template: " + e.getMessage(),
                e
            );
        }
    }

    /**
     * Create template context with tenant-specific data
     */
    private TemplateContext createTemplateContext(Tenant tenant, TenantCreateRequest request) {
        TemplateContext context = new TemplateContext();
        
        // Basic tenant information
        context.put("tenantId", tenant.getTenantId());
        context.put("tenantName", tenant.getTenantName());
        context.put("tenantDescription", tenant.getDescription() != null ? tenant.getDescription() : "Database schema for " + tenant.getTenantName());
        context.put("contactEmail", tenant.getContactEmail());
        context.put("createdAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        context.put("createdBy", tenant.getCreatedBy() != null ? tenant.getCreatedBy() : "system");
        
        // GitHub information
        context.put("githubOrg", tenant.getGithubOrg() != null ? tenant.getGithubOrg() : "your-org");
        context.put("githubRepo", tenant.getGithubRepo() != null ? tenant.getGithubRepo() : tenant.getTenantId() + "-schema");
        
        // Maven artifact information
        context.put("groupId", "com.dbserenity.tenant");
        context.put("artifactId", tenant.getTenantId() + "-schema");
        context.put("version", "1.0.0");
        
        // Schema information
        String schemaName = tenant.getTenantId().replace("-", "_") + "_schema";
        context.put("schemaName", schemaName);
        context.put("tablePrefix", tenant.getTenantId().replace("-", "_"));
        
        // Environment configurations
        if (request.getEnvironments() != null && !request.getEnvironments().isEmpty()) {
            context.put("environments", request.getEnvironments());
        } else {
            // Create default environments
            List<TenantEnvironmentRequest> defaultEnvs = createDefaultEnvironments(tenant, schemaName);
            context.put("environments", defaultEnvs);
        }
        
        return context;
    }

    /**
     * Create default environments if none provided
     */
    private List<TenantEnvironmentRequest> createDefaultEnvironments(Tenant tenant, String schemaName) {
        List<TenantEnvironmentRequest> environments = new ArrayList<>();
        
        // Development environment
        TenantEnvironmentRequest dev = new TenantEnvironmentRequest();
        dev.setEnvironmentName("dev");
        dev.setJdbcUrl("jdbc:postgresql://dev-db:5432/" + tenant.getTenantId() + "_dev");
        dev.setUsername(tenant.getTenantId() + "_dev_user");
        dev.setSchemaName(schemaName);
        dev.setContexts(Arrays.asList("common", "dev"));
        dev.setLabels(Arrays.asList("v1.0"));
        environments.add(dev);
        
        // Production environment
        TenantEnvironmentRequest prod = new TenantEnvironmentRequest();
        prod.setEnvironmentName("prod");
        prod.setJdbcUrl("jdbc:postgresql://prod-db:5432/" + tenant.getTenantId() + "_prod");
        prod.setUsername(tenant.getTenantId() + "_prod_user");
        prod.setSchemaName(schemaName);
        prod.setContexts(Arrays.asList("common", "prod"));
        prod.setLabels(Arrays.asList("v1.0"));
        environments.add(prod);
        
        return environments;
    }

    /**
     * Generate Maven POM file
     */
    private void generateMavenPom(Path repoPath, TemplateContext context) throws IOException {
        String pomTemplate = loadTemplate("pom.xml.template");
        String pomContent = processTemplate(pomTemplate, context);
        writeFile(repoPath.resolve("pom.xml"), pomContent);
    }

    /**
     * Generate tenant configuration file
     */
    private void generateTenantConfig(Path repoPath, TemplateContext context) throws IOException {
        // Create tenant config JSON
        ObjectNode config = objectMapper.createObjectNode();
        config.put("tenantId", context.getString("tenantId"));
        config.put("tenantName", context.getString("tenantName"));
        config.put("version", context.getString("version"));
        
        // Add environments
        ObjectNode environments = objectMapper.createObjectNode();
        @SuppressWarnings("unchecked")
        List<TenantEnvironmentRequest> envList = (List<TenantEnvironmentRequest>) context.get("environments");
        
        for (TenantEnvironmentRequest env : envList) {
            ObjectNode envConfig = objectMapper.createObjectNode();
            envConfig.put("jdbcUrl", env.getJdbcUrl());
            envConfig.put("username", env.getUsername());
            envConfig.put("schema", env.getSchemaName());
            
            if (env.getContexts() != null) {
                envConfig.set("contexts", objectMapper.valueToTree(env.getContexts()));
            }
            if (env.getLabels() != null) {
                envConfig.set("labels", objectMapper.valueToTree(env.getLabels()));
            }
            
            environments.set(env.getEnvironmentName(), envConfig);
        }
        config.set("environments", environments);
        
        // Add Liquibase config
        ObjectNode liquibaseConfig = objectMapper.createObjectNode();
        liquibaseConfig.put("changeLogFile", "db/changelog/db.changelog-master.sql");
        liquibaseConfig.put("defaultSchemaName", context.getString("schemaName"));
        liquibaseConfig.put("logLevel", "INFO");
        config.set("liquibaseConfig", liquibaseConfig);
        
        // Add notification config
        ObjectNode notifications = objectMapper.createObjectNode();
        ObjectNode email = objectMapper.createObjectNode();
        email.set("onSuccess", objectMapper.valueToTree(Arrays.asList(context.getString("contactEmail"))));
        email.set("onFailure", objectMapper.valueToTree(Arrays.asList(context.getString("contactEmail"))));
        notifications.set("email", email);
        config.set("notifications", notifications);
        
        // Write config file
        Path configDir = repoPath.resolve("config");
        Files.createDirectories(configDir);
        String configJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(config);
        writeFile(configDir.resolve("tenant-config.json"), configJson);
    }

    /**
     * Generate Liquibase properties file
     */
    private void generateLiquibaseProperties(Path repoPath, TemplateContext context) throws IOException {
        String template = loadTemplate("liquibase.properties.template");
        String content = processTemplate(template, context);
        
        Path resourcesDir = repoPath.resolve("src/main/resources");
        Files.createDirectories(resourcesDir);
        writeFile(resourcesDir.resolve("liquibase.properties"), content);
    }

    /**
     * Generate changelog master file
     */
    private void generateChangelogMaster(Path repoPath, TemplateContext context) throws IOException {
        String template = loadTemplate("db.changelog-master.sql.template");
        String content = processTemplate(template, context);
        
        Path changelogDir = repoPath.resolve("src/main/resources/db/changelog");
        Files.createDirectories(changelogDir);
        writeFile(changelogDir.resolve("db.changelog-master.sql"), content);
    }

    /**
     * Generate initial changesets
     */
    private void generateInitialChangesets(Path repoPath, TemplateContext context) throws IOException {
        Path changesetsDir = repoPath.resolve("src/main/resources/db/changelog/changesets/v1.0");
        Files.createDirectories(changesetsDir);
        
        // Generate initial schema changeset
        String schemaTemplate = loadTemplate("001-initial-schema.sql.template");
        String schemaContent = processTemplate(schemaTemplate, context);
        writeFile(changesetsDir.resolve("001-initial-schema.sql"), schemaContent);
        
        // Generate sample table changeset
        String tableTemplate = loadTemplate("002-sample-tables.sql.template");
        String tableContent = processTemplate(tableTemplate, context);
        writeFile(changesetsDir.resolve("002-sample-tables.sql"), tableContent);
        
        // Generate dev data changeset
        Path devDir = repoPath.resolve("src/main/resources/db/changelog/changesets/dev");
        Files.createDirectories(devDir);
        
        String devDataTemplate = loadTemplate("001-dev-test-data.sql.template");
        String devDataContent = processTemplate(devDataTemplate, context);
        writeFile(devDir.resolve("001-dev-test-data.sql"), devDataContent);
    }

    /**
     * Generate GitHub workflows
     */
    private void generateGitHubWorkflows(Path repoPath, TemplateContext context) throws IOException {
        Path workflowsDir = repoPath.resolve(".github/workflows");
        Files.createDirectories(workflowsDir);
        
        // Generate dev deployment workflow
        String devWorkflowTemplate = loadTemplate("dev-deploy.yml.template");
        String devWorkflowContent = processTemplate(devWorkflowTemplate, context);
        writeFile(workflowsDir.resolve("dev-deploy.yml"), devWorkflowContent);
        
        // Generate release workflow
        String releaseWorkflowTemplate = loadTemplate("release.yml.template");
        String releaseWorkflowContent = processTemplate(releaseWorkflowTemplate, context);
        writeFile(workflowsDir.resolve("release.yml"), releaseWorkflowContent);
    }

    /**
     * Generate Maven assembly descriptor
     */
    private void generateAssemblyDescriptor(Path repoPath, TemplateContext context) throws IOException {
        Path assemblyDir = repoPath.resolve("src/assembly");
        Files.createDirectories(assemblyDir);
        
        String assemblyTemplate = loadTemplate("changeset-bundle.xml.template");
        String assemblyContent = processTemplate(assemblyTemplate, context);
        writeFile(assemblyDir.resolve("changeset-bundle.xml"), assemblyContent);
    }

    /**
     * Generate README file
     */
    private void generateReadme(Path repoPath, TemplateContext context) throws IOException {
        String readmeTemplate = loadTemplate("README.md.template");
        String readmeContent = processTemplate(readmeTemplate, context);
        writeFile(repoPath.resolve("README.md"), readmeContent);
    }

    /**
     * Generate .gitignore file
     */
    private void generateGitIgnore(Path repoPath, TemplateContext context) throws IOException {
        String gitignoreTemplate = loadTemplate(".gitignore.template");
        String gitignoreContent = processTemplate(gitignoreTemplate, context);
        writeFile(repoPath.resolve(".gitignore"), gitignoreContent);
    }

    /**
     * Load template from resources or file system
     */
    private String loadTemplate(String templateName) throws IOException {
        try {
            // Try to load from classpath first
            Resource resource = new ClassPathResource("templates/" + templateName);
            if (resource.exists()) {
                return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            logger.debug("Template not found in classpath: {}", templateName);
        }
        
        // Try to load from file system
        Path templatePath = Paths.get(templatesDirectory, templateName);
        if (Files.exists(templatePath)) {
            return Files.readString(templatePath, StandardCharsets.UTF_8);
        }
        
        // Return default template if not found
        return getDefaultTemplate(templateName);
    }

    /**
     * Get default template content
     */
    private String getDefaultTemplate(String templateName) {
        // Return basic templates for essential files
        switch (templateName) {
            case "pom.xml.template":
                return getDefaultPomTemplate();
            case "liquibase.properties.template":
                return getDefaultLiquibasePropertiesTemplate();
            case "db.changelog-master.sql.template":
                return getDefaultChangelogMasterTemplate();
            case "README.md.template":
                return getDefaultReadmeTemplate();
            case ".gitignore.template":
                return getDefaultGitIgnoreTemplate();
            default:
                logger.warn("No default template available for: {}", templateName);
                return "# Template not found: " + templateName;
        }
    }

    /**
     * Process template with context variables
     */
    private String processTemplate(String template, TemplateContext context) {
        String result = template;
        
        // Simple template processing - replace {{variable}} with values
        for (Map.Entry<String, Object> entry : context.entrySet()) {
            String placeholder = "{{" + entry.getKey() + "}}";
            String value = entry.getValue() != null ? entry.getValue().toString() : "";
            result = result.replace(placeholder, value);
        }
        
        return result;
    }

    /**
     * Write content to file
     */
    private void writeFile(Path filePath, String content) throws IOException {
        Files.createDirectories(filePath.getParent());
        try (FileWriter writer = new FileWriter(filePath.toFile(), StandardCharsets.UTF_8)) {
            writer.write(content);
        }
    }

    /**
     * Delete directory recursively
     */
    private void deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file);
                }
            }
        }
        directory.delete();
    }

    /**
     * Get list of generated repositories
     */
    public List<String> getGeneratedRepositories() {
        try {
            Path outputPath = Paths.get(outputDirectory);
            if (!Files.exists(outputPath)) {
                return Collections.emptyList();
            }
            
            return Files.list(outputPath)
                    .filter(Files::isDirectory)
                    .map(path -> path.getFileName().toString())
                    .sorted()
                    .toList();
        } catch (IOException e) {
            logger.error("Failed to list generated repositories", e);
            return Collections.emptyList();
        }
    }

    /**
     * Clean up old generated repositories
     */
    public void cleanupOldRepositories(int maxAge) {
        try {
            Path outputPath = Paths.get(outputDirectory);
            if (!Files.exists(outputPath)) {
                return;
            }
            
            long cutoffTime = System.currentTimeMillis() - (maxAge * 24 * 60 * 60 * 1000L);
            
            Files.list(outputPath)
                    .filter(Files::isDirectory)
                    .filter(path -> {
                        try {
                            return Files.getLastModifiedTime(path).toMillis() < cutoffTime;
                        } catch (IOException e) {
                            return false;
                        }
                    })
                    .forEach(path -> {
                        try {
                            deleteDirectory(path.toFile());
                            logger.info("Cleaned up old repository: {}", path.getFileName());
                        } catch (Exception e) {
                            logger.warn("Failed to cleanup repository: {}", path.getFileName(), e);
                        }
                    });
        } catch (IOException e) {
            logger.error("Failed to cleanup old repositories", e);
        }
    }

    // Default template methods
    private String getDefaultPomTemplate() {
        return """
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>{{groupId}}</groupId>
    <artifactId>{{artifactId}}</artifactId>
    <version>{{version}}</version>
    <packaging>jar</packaging>

    <name>{{tenantName}} Database Schema</name>
    <description>{{tenantDescription}}</description>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <liquibase.version>4.25.0</liquibase.version>
        <postgresql.version>42.7.1</postgresql.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.liquibase</groupId>
            <artifactId>liquibase-core</artifactId>
            <version>${liquibase.version}</version>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>${postgresql.version}</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.liquibase</groupId>
                <artifactId>liquibase-maven-plugin</artifactId>
                <version>${liquibase.version}</version>
                <configuration>
                    <propertyFile>src/main/resources/liquibase.properties</propertyFile>
                    <changeLogFile>src/main/resources/db/changelog/db.changelog-master.sql</changeLogFile>
                </configuration>
            </plugin>
            
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-assembly-plugin</artifactId>
                <version>3.6.0</version>
                <configuration>
                    <descriptors>
                        <descriptor>src/assembly/changeset-bundle.xml</descriptor>
                    </descriptors>
                    <finalName>{{artifactId}}-${project.version}</finalName>
                    <appendAssemblyId>false</appendAssemblyId>
                </configuration>
                <executions>
                    <execution>
                        <id>make-assembly</id>
                        <phase>package</phase>
                        <goals>
                            <goal>single</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
""";
    }

    private String getDefaultLiquibasePropertiesTemplate() {
        return """
# Liquibase Configuration for {{tenantName}}
# Database password should be provided via environment variable

url=jdbc:postgresql://localhost:5432/{{tenantId}}_dev
username={{tenantId}}_dev_user
# password will be injected by DBSerenity platform

changeLogFile=db/changelog/db.changelog-master.sql
defaultSchemaName={{schemaName}}
liquibaseSchemaName={{schemaName}}

logLevel=INFO
validateChecksums=true
contexts=common,dev
labels=v1.0
""";
    }

    private String getDefaultChangelogMasterTemplate() {
        return """
-- liquibase formatted sql

-- Master changelog file for {{tenantName}} database schema
-- Generated on {{createdAt}}

-- changeset {{tenantId}}:master-1.0.0 labels:v1.0 context:common
-- include file:changesets/v1.0/001-initial-schema.sql
-- include file:changesets/v1.0/002-sample-tables.sql

-- Development-specific changesets
-- changeset {{tenantId}}:dev-data labels:v1.0 context:dev
-- include file:changesets/dev/001-dev-test-data.sql
""";
    }

    private String getDefaultReadmeTemplate() {
        return """
# {{tenantName}} Database Schema

This repository contains the database schema and changesets for {{tenantName}} in the DBSerenity platform.

## Tenant Information

- **Tenant ID**: {{tenantId}}
- **Tenant Name**: {{tenantName}}
- **Contact**: {{contactEmail}}
- **Created**: {{createdAt}}
- **Schema**: {{schemaName}}

## Repository Structure

```
├── config/
│   └── tenant-config.json          # Tenant configuration
├── src/
│   ├── main/resources/
│   │   ├── db/changelog/
│   │   │   ├── db.changelog-master.sql    # Master changelog
│   │   │   └── changesets/                # Version-specific changesets
│   │   └── liquibase.properties           # Liquibase configuration
│   └── assembly/
│       └── changeset-bundle.xml           # Maven assembly descriptor
├── .github/workflows/
│   ├── dev-deploy.yml                     # Development deployment
│   └── release.yml                        # Production release
└── README.md                              # This file
```

## Usage

### Local Development

1. Update `src/main/resources/liquibase.properties` with your local database settings
2. Run Liquibase commands:
   ```bash
   mvn liquibase:validate
   mvn liquibase:update
   ```

### Deployment

This repository is integrated with DBSerenity platform:
- Push to `dev` branch triggers development deployment
- Push to `main` branch creates production release
- Use DBSerenity APIs to execute changesets

## Generated by DBSerenity Platform

This repository was automatically generated by the DBSerenity platform on {{createdAt}}.
""";
    }

    private String getDefaultGitIgnoreTemplate() {
        return """
# Maven
target/
pom.xml.tag
pom.xml.releaseBackup
pom.xml.versionsBackup
pom.xml.next
release.properties
dependency-reduced-pom.xml
buildNumber.properties
.mvn/timing.properties
.mvn/wrapper/maven-wrapper.jar

# IDE
.idea/
*.iml
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
logs/

# Database
*.db
*.sqlite

# Liquibase
liquibase.log
""";
    }

    /**
     * Template context for variable substitution
     */
    public static class TemplateContext extends HashMap<String, Object> {
        public String getString(String key) {
            Object value = get(key);
            return value != null ? value.toString() : "";
        }
        
        public Integer getInteger(String key) {
            Object value = get(key);
            if (value instanceof Integer) {
                return (Integer) value;
            } else if (value instanceof String) {
                try {
                    return Integer.parseInt((String) value);
                } catch (NumberFormatException e) {
                    return null;
                }
            }
            return null;
        }
        
        public Boolean getBoolean(String key) {
            Object value = get(key);
            if (value instanceof Boolean) {
                return (Boolean) value;
            } else if (value instanceof String) {
                return Boolean.parseBoolean((String) value);
            }
            return null;
        }
    }

    /**
     * Result of repository generation
     */
    public static class RepositoryGenerationResult {
        private final boolean success;
        private final String repositoryPath;
        private final String message;
        private final Exception error;

        public RepositoryGenerationResult(boolean success, String repositoryPath, String message, Exception error) {
            this.success = success;
            this.repositoryPath = repositoryPath;
            this.message = message;
            this.error = error;
        }

        // Getters
        public boolean isSuccess() { return success; }
        public String getRepositoryPath() { return repositoryPath; }
        public String getMessage() { return message; }
        public Exception getError() { return error; }

        @Override
        public String toString() {
            return "RepositoryGenerationResult{" +
                    "success=" + success +
                    ", repositoryPath='" + repositoryPath + '\'' +
                    ", message='" + message + '\'' +
                    '}';
        }
    }
}

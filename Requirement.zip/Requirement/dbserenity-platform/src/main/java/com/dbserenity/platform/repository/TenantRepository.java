package com.dbserenity.platform.repository;

import com.dbserenity.platform.entity.Tenant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository interface for Tenant entity operations
 */
@Repository
public interface TenantRepository extends JpaRepository<Tenant, Long> {

    /**
     * Find tenant by tenant ID
     */
    Optional<Tenant> findByTenantId(String tenantId);

    /**
     * Find tenant by UUID
     */
    Optional<Tenant> findByUuid(UUID uuid);

    /**
     * Find tenant by contact email
     */
    Optional<Tenant> findByContactEmail(String contactEmail);

    /**
     * Find all active tenants
     */
    List<Tenant> findByIsActiveTrue();

    /**
     * Find tenants by active status with pagination
     */
    Page<Tenant> findByIsActive(Boolean isActive, Pageable pageable);

    /**
     * Find tenants by name containing (case insensitive)
     */
    @Query("SELECT t FROM Tenant t WHERE LOWER(t.tenantName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Tenant> findByTenantNameContainingIgnoreCase(@Param("name") String name);

    /**
     * Find tenants by GitHub organization
     */
    List<Tenant> findByGithubOrg(String githubOrg);

    /**
     * Check if tenant ID exists
     */
    boolean existsByTenantId(String tenantId);

    /**
     * Check if contact email exists
     */
    boolean existsByContactEmail(String contactEmail);

    /**
     * Find tenants with their environments (fetch join)
     */
    @Query("SELECT DISTINCT t FROM Tenant t LEFT JOIN FETCH t.environments WHERE t.isActive = true")
    List<Tenant> findActiveTenantsWithEnvironments();

    /**
     * Find tenant with environments by tenant ID
     */
    @Query("SELECT t FROM Tenant t LEFT JOIN FETCH t.environments WHERE t.tenantId = :tenantId")
    Optional<Tenant> findByTenantIdWithEnvironments(@Param("tenantId") String tenantId);

    /**
     * Find tenant with client credentials by tenant ID
     */
    @Query("SELECT t FROM Tenant t LEFT JOIN FETCH t.clientCredentials WHERE t.tenantId = :tenantId")
    Optional<Tenant> findByTenantIdWithCredentials(@Param("tenantId") String tenantId);

    /**
     * Search tenants by multiple criteria
     */
    @Query("SELECT t FROM Tenant t WHERE " +
           "(:tenantId IS NULL OR t.tenantId = :tenantId) AND " +
           "(:tenantName IS NULL OR LOWER(t.tenantName) LIKE LOWER(CONCAT('%', :tenantName, '%'))) AND " +
           "(:contactEmail IS NULL OR t.contactEmail = :contactEmail) AND " +
           "(:isActive IS NULL OR t.isActive = :isActive)")
    Page<Tenant> searchTenants(@Param("tenantId") String tenantId,
                              @Param("tenantName") String tenantName,
                              @Param("contactEmail") String contactEmail,
                              @Param("isActive") Boolean isActive,
                              Pageable pageable);

    /**
     * Count active tenants
     */
    @Query("SELECT COUNT(t) FROM Tenant t WHERE t.isActive = true")
    long countActiveTenants();

    /**
     * Find tenants created by a specific user
     */
    List<Tenant> findByCreatedBy(String createdBy);

    /**
     * Find tenants that have GitHub repository configured
     */
    @Query("SELECT t FROM Tenant t WHERE t.githubOrg IS NOT NULL AND t.githubRepo IS NOT NULL")
    List<Tenant> findTenantsWithGitHubRepo();
}

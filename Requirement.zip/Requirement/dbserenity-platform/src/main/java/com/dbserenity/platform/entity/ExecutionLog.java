package com.dbserenity.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Entity representing changeset execution logs
 */
@Entity
@Table(name = "execution_logs")
public class ExecutionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "execution_id", nullable = false, unique = true, length = 100)
    @NotBlank(message = "Execution ID is required")
    private String executionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tenant_id", nullable = false)
    @NotNull(message = "Tenant is required")
    private Tenant tenant;

    @Column(name = "client_id", nullable = false, length = 100)
    @NotBlank(message = "Client ID is required")
    private String clientId;

    @Column(name = "environment", nullable = false, length = 50)
    @NotBlank(message = "Environment is required")
    private String environment;

    @Column(name = "mode", nullable = false, length = 20)
    @NotBlank(message = "Mode is required")
    private String mode;

    @Column(name = "artifact_url", nullable = false, length = 500)
    @NotBlank(message = "Artifact URL is required")
    private String artifactUrl;

    @Column(name = "status", nullable = false, length = 50)
    @NotBlank(message = "Status is required")
    private String status;

    @Column(name = "started_at", nullable = false)
    @CreationTimestamp
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "duration_ms")
    private Long durationMs;

    @Column(name = "message", columnDefinition = "TEXT")
    private String message;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    @Column(name = "changesets_executed")
    private Integer changesetsExecuted;

    @Column(name = "changesets_skipped")
    private Integer changesetsSkipped;

    @Column(name = "changesets_failed")
    private Integer changesetsFailed;

    @Column(name = "sql_statements_executed")
    private Integer sqlStatementsExecuted;

    @Column(name = "database_version", length = 100)
    private String databaseVersion;

    @Column(name = "liquibase_version", length = 50)
    private String liquibaseVersion;

    @ElementCollection
    @CollectionTable(name = "execution_log_metadata", 
                    joinColumns = @JoinColumn(name = "execution_log_id"))
    @MapKeyColumn(name = "metadata_key")
    @Column(name = "metadata_value")
    private Map<String, String> metadata;

    @Column(name = "contexts", length = 500)
    private String contexts;

    @Column(name = "labels", length = 500)
    private String labels;

    @Column(name = "rollback_executed")
    private Boolean rollbackExecuted = false;

    @Column(name = "notification_sent")
    private Boolean notificationSent = false;

    // Constructors
    public ExecutionLog() {}

    public ExecutionLog(String executionId, Tenant tenant, String clientId, 
                       String environment, String mode, String artifactUrl) {
        this.executionId = executionId;
        this.tenant = tenant;
        this.clientId = clientId;
        this.environment = environment;
        this.mode = mode;
        this.artifactUrl = artifactUrl;
        this.status = "STARTED";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getArtifactUrl() {
        return artifactUrl;
    }

    public void setArtifactUrl(String artifactUrl) {
        this.artifactUrl = artifactUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public Long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Long durationMs) {
        this.durationMs = durationMs;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Integer getChangesetsExecuted() {
        return changesetsExecuted;
    }

    public void setChangesetsExecuted(Integer changesetsExecuted) {
        this.changesetsExecuted = changesetsExecuted;
    }

    public Integer getChangesetsSkipped() {
        return changesetsSkipped;
    }

    public void setChangesetsSkipped(Integer changesetsSkipped) {
        this.changesetsSkipped = changesetsSkipped;
    }

    public Integer getChangesetsFailed() {
        return changesetsFailed;
    }

    public void setChangesetsFailed(Integer changesetsFailed) {
        this.changesetsFailed = changesetsFailed;
    }

    public Integer getSqlStatementsExecuted() {
        return sqlStatementsExecuted;
    }

    public void setSqlStatementsExecuted(Integer sqlStatementsExecuted) {
        this.sqlStatementsExecuted = sqlStatementsExecuted;
    }

    public String getDatabaseVersion() {
        return databaseVersion;
    }

    public void setDatabaseVersion(String databaseVersion) {
        this.databaseVersion = databaseVersion;
    }

    public String getLiquibaseVersion() {
        return liquibaseVersion;
    }

    public void setLiquibaseVersion(String liquibaseVersion) {
        this.liquibaseVersion = liquibaseVersion;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
    }

    public String getContexts() {
        return contexts;
    }

    public void setContexts(String contexts) {
        this.contexts = contexts;
    }

    public String getLabels() {
        return labels;
    }

    public void setLabels(String labels) {
        this.labels = labels;
    }

    public Boolean getRollbackExecuted() {
        return rollbackExecuted;
    }

    public void setRollbackExecuted(Boolean rollbackExecuted) {
        this.rollbackExecuted = rollbackExecuted;
    }

    public Boolean getNotificationSent() {
        return notificationSent;
    }

    public void setNotificationSent(Boolean notificationSent) {
        this.notificationSent = notificationSent;
    }

    // Helper methods
    public void markCompleted(String status, String message) {
        this.status = status;
        this.message = message;
        this.completedAt = LocalDateTime.now();
        if (this.startedAt != null) {
            this.durationMs = java.time.Duration.between(this.startedAt, this.completedAt).toMillis();
        }
    }

    public void markFailed(String errorMessage) {
        this.status = "FAILED";
        this.errorMessage = errorMessage;
        this.completedAt = LocalDateTime.now();
        if (this.startedAt != null) {
            this.durationMs = java.time.Duration.between(this.startedAt, this.completedAt).toMillis();
        }
    }

    public boolean isCompleted() {
        return "SUCCESS".equals(status) || "FAILED".equals(status);
    }

    public boolean isRunning() {
        return "STARTED".equals(status) || "RUNNING".equals(status);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExecutionLog)) return false;
        ExecutionLog that = (ExecutionLog) o;
        return executionId.equals(that.executionId);
    }

    @Override
    public int hashCode() {
        return executionId.hashCode();
    }

    @Override
    public String toString() {
        return "ExecutionLog{" +
                "id=" + id +
                ", executionId='" + executionId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", environment='" + environment + '\'' +
                ", mode='" + mode + '\'' +
                ", status='" + status + '\'' +
                ", startedAt=" + startedAt +
                ", completedAt=" + completedAt +
                ", durationMs=" + durationMs +
                '}';
    }
}

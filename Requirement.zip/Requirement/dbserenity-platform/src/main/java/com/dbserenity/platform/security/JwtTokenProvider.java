package com.dbserenity.platform.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

/**
 * JWT token provider for authentication
 */
@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    private final Algorithm algorithm;
    private final JWTVerifier verifier;
    private final String issuer;
    private final long expirationTime;

    public JwtTokenProvider(@Value("${dbserenity.jwt.secret}") String secret,
                           @Value("${dbserenity.jwt.issuer}") String issuer,
                           @Value("${dbserenity.jwt.expiration}") long expirationTime) {
        this.algorithm = Algorithm.HMAC256(secret);
        this.verifier = JWT.require(algorithm).withIssuer(issuer).build();
        this.issuer = issuer;
        this.expirationTime = expirationTime;
    }

    /**
     * Generate JWT token for client credentials
     */
    public String generateToken(String clientId, String tenantId, List<String> scopes) {
        Instant now = Instant.now();
        Instant expiry = now.plusSeconds(expirationTime);

        return JWT.create()
                .withIssuer(issuer)
                .withSubject(clientId)
                .withClaim("tenant_id", tenantId)
                .withClaim("scopes", scopes)
                .withClaim("token_type", "access_token")
                .withIssuedAt(Date.from(now))
                .withExpiresAt(Date.from(expiry))
                .sign(algorithm);
    }

    /**
     * Validate and parse JWT token
     */
    public JwtTokenInfo validateToken(String token) {
        try {
            DecodedJWT decodedJWT = verifier.verify(token);
            
            String clientId = decodedJWT.getSubject();
            String tenantId = decodedJWT.getClaim("tenant_id").asString();
            List<String> scopes = decodedJWT.getClaim("scopes").asList(String.class);
            
            LocalDateTime expiresAt = LocalDateTime.ofInstant(
                decodedJWT.getExpiresAt().toInstant(), 
                ZoneId.systemDefault()
            );
            
            return new JwtTokenInfo(clientId, tenantId, scopes, expiresAt);
            
        } catch (JWTVerificationException e) {
            logger.warn("Invalid JWT token: {}", e.getMessage());
            throw new InvalidTokenException("Invalid or expired token", e);
        }
    }

    /**
     * Extract client ID from token without full validation
     */
    public String extractClientId(String token) {
        try {
            DecodedJWT decodedJWT = JWT.decode(token);
            return decodedJWT.getSubject();
        } catch (Exception e) {
            logger.warn("Failed to extract client ID from token: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Check if token is expired
     */
    public boolean isTokenExpired(String token) {
        try {
            DecodedJWT decodedJWT = JWT.decode(token);
            return decodedJWT.getExpiresAt().before(new Date());
        } catch (Exception e) {
            return true;
        }
    }

    /**
     * Get token expiration time in seconds
     */
    public long getExpirationTime() {
        return expirationTime;
    }

    /**
     * JWT token information holder
     */
    public static class JwtTokenInfo {
        private final String clientId;
        private final String tenantId;
        private final List<String> scopes;
        private final LocalDateTime expiresAt;

        public JwtTokenInfo(String clientId, String tenantId, List<String> scopes, LocalDateTime expiresAt) {
            this.clientId = clientId;
            this.tenantId = tenantId;
            this.scopes = scopes;
            this.expiresAt = expiresAt;
        }

        public String getClientId() { return clientId; }
        public String getTenantId() { return tenantId; }
        public List<String> getScopes() { return scopes; }
        public LocalDateTime getExpiresAt() { return expiresAt; }

        public boolean hasScope(String scope) {
            return scopes != null && scopes.contains(scope);
        }

        public boolean isExpired() {
            return LocalDateTime.now().isAfter(expiresAt);
        }

        @Override
        public String toString() {
            return "JwtTokenInfo{" +
                    "clientId='" + clientId + '\'' +
                    ", tenantId='" + tenantId + '\'' +
                    ", scopes=" + scopes +
                    ", expiresAt=" + expiresAt +
                    '}';
        }
    }

    /**
     * Exception for invalid tokens
     */
    public static class InvalidTokenException extends RuntimeException {
        public InvalidTokenException(String message) {
            super(message);
        }

        public InvalidTokenException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

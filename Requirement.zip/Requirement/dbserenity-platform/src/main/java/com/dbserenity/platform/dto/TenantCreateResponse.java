package com.dbserenity.platform.dto;

/**
 * DTO for tenant creation response
 */
public class TenantCreateResponse {

    private TenantResponse tenant;
    private ClientCredentialsCreateResponse clientCredentials;
    private GitHubRepoCreateResponse gitHubRepo;

    // Constructors
    public TenantCreateResponse() {}

    public TenantCreateResponse(TenantResponse tenant) {
        this.tenant = tenant;
    }

    // Getters and Setters
    public TenantResponse getTenant() {
        return tenant;
    }

    public void setTenant(TenantResponse tenant) {
        this.tenant = tenant;
    }

    public ClientCredentialsCreateResponse getClientCredentials() {
        return clientCredentials;
    }

    public void setClientCredentials(ClientCredentialsCreateResponse clientCredentials) {
        this.clientCredentials = clientCredentials;
    }

    public GitHubRepoCreateResponse getGitHubRepo() {
        return gitHubRepo;
    }

    public void setGitHubRepo(GitHubRepoCreateResponse gitHubRepo) {
        this.gitHubRepo = gitHubRepo;
    }

    @Override
    public String toString() {
        return "TenantCreateResponse{" +
                "tenant=" + tenant +
                ", clientCredentials=" + (clientCredentials != null ? "present" : "null") +
                ", gitHubRepo=" + (gitHubRepo != null ? "present" : "null") +
                '}';
    }
}

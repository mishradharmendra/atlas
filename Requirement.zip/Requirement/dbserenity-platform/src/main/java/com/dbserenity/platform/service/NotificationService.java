package com.dbserenity.platform.service;

import com.dbserenity.platform.dto.ChangesetExecutionResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

/**
 * Service for sending notifications
 */
@Service
public class NotificationService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    private final JavaMailSender mailSender;
    private final String fromEmail;
    private final boolean emailEnabled;

    @Autowired
    public NotificationService(JavaMailSender mailSender,
                             @Value("${dbserenity.notification.email.from}") String fromEmail,
                             @Value("${dbserenity.notification.email.enabled:true}") boolean emailEnabled) {
        this.mailSender = mailSender;
        this.fromEmail = fromEmail;
        this.emailEnabled = emailEnabled;
    }

    /**
     * Send execution notification
     */
    public void sendExecutionNotification(String toEmail, ChangesetExecutionResponse response, boolean success) {
        if (!emailEnabled) {
            logger.debug("Email notifications are disabled");
            return;
        }

        try {
            logger.info("Sending execution notification to: {} for execution: {}", toEmail, response.getExecutionId());

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject(buildSubject(response, success));
            message.setText(buildEmailBody(response, success));

            mailSender.send(message);
            logger.info("Execution notification sent successfully to: {}", toEmail);

        } catch (Exception e) {
            logger.error("Failed to send execution notification to: {}", toEmail, e);
            throw new RuntimeException("Failed to send notification", e);
        }
    }

    /**
     * Build email subject
     */
    private String buildSubject(ChangesetExecutionResponse response, boolean success) {
        String status = success ? "SUCCESS" : "FAILED";
        return String.format("DBSerenity Execution %s - %s [%s/%s]", 
                           status, 
                           response.getExecutionId(),
                           response.getTenantId(),
                           response.getEnvironment());
    }

    /**
     * Build email body
     */
    private String buildEmailBody(ChangesetExecutionResponse response, boolean success) {
        StringBuilder body = new StringBuilder();
        
        body.append("DBSerenity Changeset Execution Report\n");
        body.append("=====================================\n\n");
        
        body.append("Execution ID: ").append(response.getExecutionId()).append("\n");
        body.append("Tenant: ").append(response.getTenantId()).append("\n");
        body.append("Environment: ").append(response.getEnvironment()).append("\n");
        body.append("Mode: ").append(response.getMode()).append("\n");
        body.append("Status: ").append(response.getStatus()).append("\n");
        
        if (response.getStartedAt() != null) {
            body.append("Started: ").append(response.getStartedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)).append("\n");
        }
        
        if (response.getCompletedAt() != null) {
            body.append("Completed: ").append(response.getCompletedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)).append("\n");
        }
        
        if (response.getDurationMs() != null) {
            body.append("Duration: ").append(formatDuration(response.getDurationMs())).append("\n");
        }
        
        body.append("\n");
        
        if (success) {
            body.append("✅ Execution completed successfully!\n\n");
            
            if (response.getSummary() != null) {
                body.append("Execution Summary:\n");
                body.append("-----------------\n");
                body.append("Changesets Executed: ").append(response.getSummary().getChangesetsExecuted()).append("\n");
                body.append("Changesets Skipped: ").append(response.getSummary().getChangesetsSkipped()).append("\n");
                body.append("Changesets Failed: ").append(response.getSummary().getChangesetsFailed()).append("\n");
                
                if (response.getSummary().getSqlStatementsExecuted() != null) {
                    body.append("SQL Statements: ").append(response.getSummary().getSqlStatementsExecuted()).append("\n");
                }
                
                if (response.getSummary().getDatabaseVersion() != null) {
                    body.append("Database Version: ").append(response.getSummary().getDatabaseVersion()).append("\n");
                }
                
                if (response.getSummary().getLiquibaseVersion() != null) {
                    body.append("Liquibase Version: ").append(response.getSummary().getLiquibaseVersion()).append("\n");
                }
                body.append("\n");
            }
            
        } else {
            body.append("❌ Execution failed!\n\n");
            
            if (response.getMessage() != null) {
                body.append("Error Message:\n");
                body.append("--------------\n");
                body.append(response.getMessage()).append("\n\n");
            }
        }
        
        if (response.getArtifactUrl() != null) {
            body.append("Artifact: ").append(response.getArtifactUrl()).append("\n");
        }
        
        body.append("\n");
        body.append("This is an automated notification from DBSerenity Platform.\n");
        body.append("Please do not reply to this email.\n");
        
        return body.toString();
    }

    /**
     * Format duration in human-readable format
     */
    private String formatDuration(long durationMs) {
        if (durationMs < 1000) {
            return durationMs + "ms";
        } else if (durationMs < 60000) {
            return String.format("%.1fs", durationMs / 1000.0);
        } else if (durationMs < 3600000) {
            long minutes = durationMs / 60000;
            long seconds = (durationMs % 60000) / 1000;
            return String.format("%dm %ds", minutes, seconds);
        } else {
            long hours = durationMs / 3600000;
            long minutes = (durationMs % 3600000) / 60000;
            return String.format("%dh %dm", hours, minutes);
        }
    }

    /**
     * Send tenant creation notification
     */
    public void sendTenantCreationNotification(String toEmail, String tenantId, String tenantName) {
        if (!emailEnabled) {
            return;
        }

        try {
            logger.info("Sending tenant creation notification to: {} for tenant: {}", toEmail, tenantId);

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("DBSerenity Tenant Created - " + tenantName);
            
            StringBuilder body = new StringBuilder();
            body.append("Welcome to DBSerenity!\n\n");
            body.append("Your tenant has been successfully created:\n\n");
            body.append("Tenant ID: ").append(tenantId).append("\n");
            body.append("Tenant Name: ").append(tenantName).append("\n\n");
            body.append("You can now start using the DBSerenity platform for database schema versioning.\n\n");
            body.append("Best regards,\n");
            body.append("DBSerenity Team");
            
            message.setText(body.toString());
            mailSender.send(message);
            
            logger.info("Tenant creation notification sent successfully to: {}", toEmail);

        } catch (Exception e) {
            logger.error("Failed to send tenant creation notification to: {}", toEmail, e);
        }
    }

    /**
     * Send test notification
     */
    public void sendTestNotification(String toEmail) {
        if (!emailEnabled) {
            throw new RuntimeException("Email notifications are disabled");
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("DBSerenity Test Notification");
            message.setText("This is a test notification from DBSerenity Platform.\n\nIf you received this email, the notification system is working correctly.");

            mailSender.send(message);
            logger.info("Test notification sent successfully to: {}", toEmail);

        } catch (Exception e) {
            logger.error("Failed to send test notification to: {}", toEmail, e);
            throw new RuntimeException("Failed to send test notification", e);
        }
    }
}

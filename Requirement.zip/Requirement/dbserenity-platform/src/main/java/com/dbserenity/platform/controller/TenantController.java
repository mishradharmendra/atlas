package com.dbserenity.platform.controller;

import com.dbserenity.platform.dto.*;
import com.dbserenity.platform.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

/**
 * REST controller for tenant management operations
 */
@RestController
@RequestMapping("/v1/tenants")
@Tag(name = "Tenant Management", description = "APIs for managing tenants in the DBSerenity platform")
public class TenantController {

    private static final Logger logger = LoggerFactory.getLogger(TenantController.class);

    private final TenantService tenantService;

    @Autowired
    public TenantController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @Operation(summary = "Create a new tenant", description = "Creates a new tenant with optional environment configurations and client credentials")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Tenant created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid request data"),
        @ApiResponse(responseCode = "409", description = "Tenant already exists")
    })
    @PostMapping
    public ResponseEntity<TenantCreateResponse> createTenant(
            @Valid @RequestBody TenantCreateRequest request,
            Authentication authentication) {
        
        logger.info("Creating tenant: {} by user: {}", request.getTenantId(), 
                   authentication != null ? authentication.getName() : "system");
        
        String createdBy = authentication != null ? authentication.getName() : "system";
        TenantCreateResponse response = tenantService.createTenant(request, createdBy);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @Operation(summary = "Get tenant by ID", description = "Retrieves a tenant by its unique tenant ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Tenant found"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @GetMapping("/{tenantId}")
    public ResponseEntity<TenantResponse> getTenant(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId) {
        
        logger.debug("Getting tenant: {}", tenantId);
        TenantResponse response = tenantService.getTenant(tenantId);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Get tenant by UUID", description = "Retrieves a tenant by its UUID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Tenant found"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @GetMapping("/uuid/{uuid}")
    public ResponseEntity<TenantResponse> getTenantByUuid(
            @Parameter(description = "Tenant UUID") 
            @PathVariable UUID uuid) {
        
        logger.debug("Getting tenant by UUID: {}", uuid);
        TenantResponse response = tenantService.getTenantByUuid(uuid);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Get all tenants", description = "Retrieves all tenants with pagination")
    @ApiResponse(responseCode = "200", description = "Tenants retrieved successfully")
    @GetMapping
    public ResponseEntity<Page<TenantResponse>> getAllTenants(
            @PageableDefault(size = 20) Pageable pageable) {
        
        logger.debug("Getting all tenants with pagination: {}", pageable);
        Page<TenantResponse> response = tenantService.getAllTenants(pageable);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Get active tenants", description = "Retrieves all active tenants")
    @ApiResponse(responseCode = "200", description = "Active tenants retrieved successfully")
    @GetMapping("/active")
    public ResponseEntity<List<TenantResponse>> getActiveTenants() {
        
        logger.debug("Getting active tenants");
        List<TenantResponse> response = tenantService.getActiveTenants();
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Search tenants", description = "Search tenants by various criteria")
    @ApiResponse(responseCode = "200", description = "Search completed successfully")
    @GetMapping("/search")
    public ResponseEntity<Page<TenantResponse>> searchTenants(
            @Parameter(description = "Tenant ID to search for") 
            @RequestParam(required = false) String tenantId,
            @Parameter(description = "Tenant name to search for") 
            @RequestParam(required = false) String tenantName,
            @Parameter(description = "Contact email to search for") 
            @RequestParam(required = false) String contactEmail,
            @Parameter(description = "Active status filter") 
            @RequestParam(required = false) Boolean isActive,
            @PageableDefault(size = 20) Pageable pageable) {
        
        logger.debug("Searching tenants with criteria - tenantId: {}, tenantName: {}, contactEmail: {}, isActive: {}", 
                    tenantId, tenantName, contactEmail, isActive);
        
        Page<TenantResponse> response = tenantService.searchTenants(
            tenantId, tenantName, contactEmail, isActive, pageable);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Update tenant", description = "Updates tenant information")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Tenant updated successfully"),
        @ApiResponse(responseCode = "404", description = "Tenant not found"),
        @ApiResponse(responseCode = "409", description = "Email already exists")
    })
    @PutMapping("/{tenantId}")
    public ResponseEntity<TenantResponse> updateTenant(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId,
            @Valid @RequestBody TenantUpdateRequest request,
            Authentication authentication) {
        
        logger.info("Updating tenant: {} by user: {}", tenantId, 
                   authentication != null ? authentication.getName() : "system");
        
        String updatedBy = authentication != null ? authentication.getName() : "system";
        TenantResponse response = tenantService.updateTenant(tenantId, request, updatedBy);
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Activate tenant", description = "Activates a tenant")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Tenant activated successfully"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @PostMapping("/{tenantId}/activate")
    public ResponseEntity<TenantResponse> activateTenant(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId,
            Authentication authentication) {
        
        logger.info("Activating tenant: {} by user: {}", tenantId, 
                   authentication != null ? authentication.getName() : "system");
        
        String updatedBy = authentication != null ? authentication.getName() : "system";
        TenantResponse response = tenantService.updateTenantStatus(tenantId, true, updatedBy);
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Deactivate tenant", description = "Deactivates a tenant")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Tenant deactivated successfully"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @PostMapping("/{tenantId}/deactivate")
    public ResponseEntity<TenantResponse> deactivateTenant(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId,
            Authentication authentication) {
        
        logger.info("Deactivating tenant: {} by user: {}", tenantId, 
                   authentication != null ? authentication.getName() : "system");
        
        String updatedBy = authentication != null ? authentication.getName() : "system";
        TenantResponse response = tenantService.updateTenantStatus(tenantId, false, updatedBy);
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Delete tenant", description = "Soft deletes a tenant by deactivating it")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Tenant deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @DeleteMapping("/{tenantId}")
    public ResponseEntity<Void> deleteTenant(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId,
            Authentication authentication) {
        
        logger.info("Deleting tenant: {} by user: {}", tenantId, 
                   authentication != null ? authentication.getName() : "system");
        
        String deletedBy = authentication != null ? authentication.getName() : "system";
        tenantService.deleteTenant(tenantId, deletedBy);
        
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Get tenant statistics", description = "Retrieves platform-wide tenant statistics")
    @ApiResponse(responseCode = "200", description = "Statistics retrieved successfully")
    @GetMapping("/stats")
    public ResponseEntity<TenantStatsResponse> getTenantStats() {
        
        logger.debug("Getting tenant statistics");
        TenantStatsResponse response = tenantService.getTenantStats();
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Check tenant existence", description = "Checks if a tenant exists by tenant ID")
    @ApiResponse(responseCode = "200", description = "Check completed")
    @GetMapping("/{tenantId}/exists")
    public ResponseEntity<Boolean> tenantExists(
            @Parameter(description = "Unique tenant identifier") 
            @PathVariable String tenantId) {
        
        logger.debug("Checking if tenant exists: {}", tenantId);
        boolean exists = tenantService.tenantExists(tenantId);
        return ResponseEntity.ok(exists);
    }
}

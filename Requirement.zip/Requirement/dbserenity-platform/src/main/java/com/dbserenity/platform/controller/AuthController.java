package com.dbserenity.platform.controller;

import com.dbserenity.platform.dto.TokenRequest;
import com.dbserenity.platform.dto.TokenResponse;
import com.dbserenity.platform.service.AuthenticationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Authentication controller for client credentials flow
 */
@RestController
@RequestMapping("/v1/auth")
@Tag(name = "Authentication", description = "Client credentials authentication APIs")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final AuthenticationService authenticationService;

    @Autowired
    public AuthController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @Operation(summary = "Get access token", description = "Authenticate using client credentials and get JWT access token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token generated successfully"),
        @ApiResponse(responseCode = "401", description = "Invalid client credentials"),
        @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    @PreAuthorize("permitAll()")
    @PostMapping("/token")
    public ResponseEntity<TokenResponse> getToken(@Valid @RequestBody TokenRequest request) {
        
        logger.info("Token request for client: {}", request.getClientId());
        
        TokenResponse response = authenticationService.authenticate(request);
        
        logger.info("Token generated successfully for client: {}", request.getClientId());
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Validate token", description = "Validate an existing JWT token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token is valid"),
        @ApiResponse(responseCode = "401", description = "Token is invalid or expired")
    })
    @PostMapping("/validate")
    public ResponseEntity<TokenValidationResponse> validateToken(
            @RequestHeader("Authorization") String authorizationHeader) {
        
        String token = extractTokenFromHeader(authorizationHeader);
        if (token == null) {
            return ResponseEntity.badRequest().build();
        }
        
        logger.debug("Validating token");
        
        TokenValidationResponse response = authenticationService.validateToken(token);
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Revoke token", description = "Revoke an existing JWT token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token revoked successfully"),
        @ApiResponse(responseCode = "401", description = "Invalid token")
    })
    @PostMapping("/revoke")
    public ResponseEntity<Void> revokeToken(
            @RequestHeader("Authorization") String authorizationHeader) {
        
        String token = extractTokenFromHeader(authorizationHeader);
        if (token == null) {
            return ResponseEntity.badRequest().build();
        }
        
        logger.info("Revoking token");
        
        authenticationService.revokeToken(token);
        
        return ResponseEntity.ok().build();
    }

    private String extractTokenFromHeader(String authorizationHeader) {
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            return authorizationHeader.substring(7);
        }
        return null;
    }

    /**
     * Token validation response
     */
    public static class TokenValidationResponse {
        private boolean valid;
        private String clientId;
        private String tenantId;
        private java.util.List<String> scopes;
        private java.time.LocalDateTime expiresAt;

        public TokenValidationResponse() {}

        public TokenValidationResponse(boolean valid, String clientId, String tenantId, 
                                     java.util.List<String> scopes, java.time.LocalDateTime expiresAt) {
            this.valid = valid;
            this.clientId = clientId;
            this.tenantId = tenantId;
            this.scopes = scopes;
            this.expiresAt = expiresAt;
        }

        // Getters and Setters
        public boolean isValid() { return valid; }
        public void setValid(boolean valid) { this.valid = valid; }
        
        public String getClientId() { return clientId; }
        public void setClientId(String clientId) { this.clientId = clientId; }
        
        public String getTenantId() { return tenantId; }
        public void setTenantId(String tenantId) { this.tenantId = tenantId; }
        
        public java.util.List<String> getScopes() { return scopes; }
        public void setScopes(java.util.List<String> scopes) { this.scopes = scopes; }
        
        public java.time.LocalDateTime getExpiresAt() { return expiresAt; }
        public void setExpiresAt(java.time.LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
    }
}

package com.dbserenity.platform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * DTO for tenant environment request
 */
public class TenantEnvironmentRequest {

    @NotBlank(message = "Environment name is required")
    @Pattern(regexp = "^(dev|staging|prod)$", message = "Environment name must be dev, staging, or prod")
    private String environmentName;

    @NotBlank(message = "JDBC URL is required")
    @Size(max = 500, message = "JDBC URL must not exceed 500 characters")
    private String jdbcUrl;

    @NotBlank(message = "Username is required")
    @Size(max = 100, message = "Username must not exceed 100 characters")
    private String username;

    @Size(max = 100, message = "Schema name must not exceed 100 characters")
    private String schemaName;

    private List<String> contexts;
    private List<String> labels;

    // Constructors
    public TenantEnvironmentRequest() {}

    public TenantEnvironmentRequest(String environmentName, String jdbcUrl, String username) {
        this.environmentName = environmentName;
        this.jdbcUrl = jdbcUrl;
        this.username = username;
    }

    // Getters and Setters
    public String getEnvironmentName() {
        return environmentName;
    }

    public void setEnvironmentName(String environmentName) {
        this.environmentName = environmentName;
    }

    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public List<String> getContexts() {
        return contexts;
    }

    public void setContexts(List<String> contexts) {
        this.contexts = contexts;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    @Override
    public String toString() {
        return "TenantEnvironmentRequest{" +
                "environmentName='" + environmentName + '\'' +
                ", jdbcUrl='" + jdbcUrl + '\'' +
                ", username='" + username + '\'' +
                ", schemaName='" + schemaName + '\'' +
                ", contexts=" + contexts +
                ", labels=" + labels +
                '}';
    }
}

package com.dbserenity.platform.service;

import com.dbserenity.platform.controller.AuthController;
import com.dbserenity.platform.dto.TokenRequest;
import com.dbserenity.platform.dto.TokenResponse;
import com.dbserenity.platform.entity.ClientCredentials;
import com.dbserenity.platform.entity.Tenant;
import com.dbserenity.platform.repository.ClientCredentialsRepository;
import com.dbserenity.platform.security.JwtTokenProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service for handling authentication operations
 */
@Service
@Transactional
public class AuthenticationService {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationService.class);

    private final ClientCredentialsRepository clientCredentialsRepository;
    private final JwtTokenProvider jwtTokenProvider;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    @Autowired
    public AuthenticationService(ClientCredentialsRepository clientCredentialsRepository,
                               JwtTokenProvider jwtTokenProvider,
                               PasswordEncoder passwordEncoder,
                               AuditService auditService) {
        this.clientCredentialsRepository = clientCredentialsRepository;
        this.jwtTokenProvider = jwtTokenProvider;
        this.passwordEncoder = passwordEncoder;
        this.auditService = auditService;
    }

    /**
     * Authenticate client credentials and generate JWT token
     */
    public TokenResponse authenticate(TokenRequest request) {
        logger.debug("Authenticating client: {}", request.getClientId());

        // Validate grant type
        if (!"client_credentials".equals(request.getGrantType())) {
            throw new BadCredentialsException("Unsupported grant type: " + request.getGrantType());
        }

        // Find client credentials
        ClientCredentials credentials = clientCredentialsRepository
                .findByClientIdWithTenant(request.getClientId())
                .orElseThrow(() -> new BadCredentialsException("Invalid client credentials"));

        // Validate client is active
        if (!credentials.isValid()) {
            logger.warn("Inactive or expired client credentials: {}", request.getClientId());
            throw new BadCredentialsException("Client credentials are inactive or expired");
        }

        // Validate tenant is active
        Tenant tenant = credentials.getTenant();
        if (!tenant.getIsActive()) {
            logger.warn("Tenant is inactive: {}", tenant.getTenantId());
            throw new BadCredentialsException("Tenant is inactive");
        }

        // Verify client secret using supported hashing schemes (sha256 hex OR bcrypt of secret+salt)
        String composite = request.getClientSecret() + credentials.getClientSecretSalt();
        String stored = credentials.getClientSecretHash();
        boolean secretValid;
        if (stored != null && stored.startsWith("$2")) {
            // bcrypt format
            secretValid = passwordEncoder.matches(composite, stored);
        } else {
            // assume sha256 hex
            String expectedHash = sha256Hex(composite);
            secretValid = expectedHash.equalsIgnoreCase(stored);
        }
        if (!secretValid) {
            logger.warn("Invalid client secret for client: {}", request.getClientId());
            auditService.logAuthenticationFailure(request.getClientId(), "Invalid client secret");
            throw new BadCredentialsException("Invalid client credentials");
        }

        // Determine scopes
        List<String> scopes = credentials.getScopes();
        if (request.getScope() != null && !request.getScope().isEmpty()) {
            // Filter requested scopes against allowed scopes
            List<String> requestedScopes = List.of(request.getScope().split(" "));
            scopes = requestedScopes.stream()
                    .filter(credentials::hasScope)
                    .toList();
            
            if (scopes.isEmpty()) {
                throw new BadCredentialsException("No valid scopes requested");
            }
        }

        // Generate JWT token
        String token = jwtTokenProvider.generateToken(
                credentials.getClientId(),
                tenant.getTenantId(),
                scopes
        );

        // Update last used timestamp
        credentials.updateLastUsed();
        clientCredentialsRepository.save(credentials);

        // Log successful authentication
        auditService.logAuthenticationSuccess(credentials.getClientId(), tenant.getTenantId());

        // Create response
        TokenResponse response = new TokenResponse();
        response.setAccessToken(token);
        response.setExpiresIn(jwtTokenProvider.getExpirationTime());
        response.setScope(String.join(" ", scopes));
        response.setTenantId(tenant.getTenantId());

        logger.info("Authentication successful for client: {} tenant: {}", 
                   request.getClientId(), tenant.getTenantId());

        return response;
    }

    /**
     * Validate JWT token
     */
    @Transactional(readOnly = true)
    public AuthController.TokenValidationResponse validateToken(String token) {
        try {
            JwtTokenProvider.JwtTokenInfo tokenInfo = jwtTokenProvider.validateToken(token);
            
            // Verify client credentials still exist and are active
            ClientCredentials credentials = clientCredentialsRepository
                    .findByClientIdWithTenant(tokenInfo.getClientId())
                    .orElse(null);
            
            if (credentials == null || !credentials.isValid()) {
                return new AuthController.TokenValidationResponse(false, null, null, null, null);
            }

            return new AuthController.TokenValidationResponse(
                    true,
                    tokenInfo.getClientId(),
                    tokenInfo.getTenantId(),
                    tokenInfo.getScopes(),
                    tokenInfo.getExpiresAt()
            );
            
        } catch (JwtTokenProvider.InvalidTokenException e) {
            logger.debug("Token validation failed: {}", e.getMessage());
            return new AuthController.TokenValidationResponse(false, null, null, null, null);
        }
    }

    /**
     * Revoke JWT token (add to blacklist if needed)
     */
    public void revokeToken(String token) {
        try {
            JwtTokenProvider.JwtTokenInfo tokenInfo = jwtTokenProvider.validateToken(token);
            
            // Log token revocation
            auditService.logTokenRevoked(tokenInfo.getClientId(), tokenInfo.getTenantId());
            
            // TODO: Implement token blacklist if needed for immediate revocation
            // For now, tokens will expire naturally
            
            logger.info("Token revoked for client: {}", tokenInfo.getClientId());
            
        } catch (JwtTokenProvider.InvalidTokenException e) {
            logger.warn("Attempted to revoke invalid token: {}", e.getMessage());
        }
    }

    /**
     * Hash client secret with salt
     */
    private String hashSecret(String secret, String salt) {
        // NOTE: Not used for verification; kept if needed elsewhere for initial hash generation
        return passwordEncoder.encode(secret + salt);
    }

    private String sha256Hex(String value) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to compute SHA-256 hash", e);
        }
    }
}

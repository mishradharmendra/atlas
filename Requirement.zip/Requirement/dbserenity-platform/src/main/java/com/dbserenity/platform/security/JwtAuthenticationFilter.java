package com.dbserenity.platform.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JWT authentication filter for processing bearer tokens
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    private final JwtTokenProvider tokenProvider;

    @Autowired
    public JwtAuthenticationFilter(JwtTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, 
                                  HttpServletResponse response, 
                                  FilterChain filterChain) throws ServletException, IOException {
        
        try {
            String token = extractTokenFromRequest(request);
            
            if (StringUtils.hasText(token)) {
                try {
                    JwtTokenProvider.JwtTokenInfo tokenInfo = tokenProvider.validateToken(token);
                    
                    if (!tokenInfo.isExpired()) {
                        // Create authentication object
                        List<SimpleGrantedAuthority> authorities = tokenInfo.getScopes().stream()
                                .map(scope -> new SimpleGrantedAuthority("SCOPE_" + scope))
                                .collect(Collectors.toList());
                        
                        UsernamePasswordAuthenticationToken authentication = 
                                new UsernamePasswordAuthenticationToken(
                                    tokenInfo.getClientId(), 
                                    null, 
                                    authorities
                                );
                        
                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        
                        // Set authentication in security context
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                        
                        // Add tenant context to MDC for logging
                        MDC.put("tenantId", tokenInfo.getTenantId());
                        MDC.put("clientId", tokenInfo.getClientId());
                        
                        // Add token info to request attributes for controllers
                        request.setAttribute("tokenInfo", tokenInfo);
                        
                        logger.debug("Successfully authenticated client: {} for tenant: {}", 
                                   tokenInfo.getClientId(), tokenInfo.getTenantId());
                    } else {
                        logger.warn("Token expired for client: {}", tokenInfo.getClientId());
                    }
                    
                } catch (JwtTokenProvider.InvalidTokenException e) {
                    logger.warn("Invalid token provided: {}", e.getMessage());
                }
            }
            
        } catch (Exception e) {
            logger.error("Cannot set user authentication", e);
        }
        
        try {
            filterChain.doFilter(request, response);
        } finally {
            // Clean up MDC
            MDC.remove("tenantId");
            MDC.remove("clientId");
        }
    }

    /**
     * Extract JWT token from Authorization header
     */
    private String extractTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader(AUTHORIZATION_HEADER);
        
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith(BEARER_PREFIX)) {
            return bearerToken.substring(BEARER_PREFIX.length());
        }
        
        return null;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        boolean skip = path.equals("/api/v1/auth/token") || path.equals("/api/v1/auth/validate");
        logger.debug("shouldNotFilter called for path: {} - skip: {}", path, skip);
        return skip;
    }
}

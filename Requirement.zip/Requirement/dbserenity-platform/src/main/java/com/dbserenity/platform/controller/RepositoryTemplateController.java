package com.dbserenity.platform.controller;

import com.dbserenity.platform.dto.RepositoryTemplateRequest;
import com.dbserenity.platform.dto.RepositoryTemplateResponse;
import com.dbserenity.platform.dto.TenantCreateRequest;
import com.dbserenity.platform.entity.Tenant;
import com.dbserenity.platform.security.JwtTokenProvider;
import com.dbserenity.platform.service.RepositoryTemplateService;
import com.dbserenity.platform.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for repository template operations
 */
@RestController
@RequestMapping("/v1/repository-templates")
@Tag(name = "Repository Templates", description = "APIs for generating tenant repository templates")
@SecurityRequirement(name = "bearerAuth")
public class RepositoryTemplateController {

    private static final Logger logger = LoggerFactory.getLogger(RepositoryTemplateController.class);

    private final RepositoryTemplateService repositoryTemplateService;
    private final TenantService tenantService;

    @Autowired
    public RepositoryTemplateController(RepositoryTemplateService repositoryTemplateService,
                                      TenantService tenantService) {
        this.repositoryTemplateService = repositoryTemplateService;
        this.tenantService = tenantService;
    }

    @Operation(summary = "Generate repository template", 
               description = "Generate a complete repository template for a tenant")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Template generated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid request"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @PostMapping("/generate")
    @PreAuthorize("hasAuthority('SCOPE_tenant:manage') or hasRole('ADMIN')")
    public ResponseEntity<RepositoryTemplateResponse> generateTemplate(
            @Valid @RequestBody RepositoryTemplateRequest request,
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        logger.info("Generating repository template for tenant: {} by client: {}", 
                   request.getTenantId(), tokenInfo.getClientId());

        try {
            // Get tenant information
            Tenant tenant = getTenantForRequest(request.getTenantId(), tokenInfo);
            
            // Create a basic tenant create request for template generation
            TenantCreateRequest tenantCreateRequest = new TenantCreateRequest();
            tenantCreateRequest.setTenantId(tenant.getTenantId());
            tenantCreateRequest.setTenantName(tenant.getTenantName());
            tenantCreateRequest.setContactEmail(tenant.getContactEmail());
            tenantCreateRequest.setGithubOrg(tenant.getGithubOrg());
            tenantCreateRequest.setGithubRepo(tenant.getGithubRepo());

            // Generate repository template
            RepositoryTemplateService.RepositoryGenerationResult result = 
                repositoryTemplateService.generateTenantRepository(tenant, tenantCreateRequest);

            // Create response
            RepositoryTemplateResponse response = new RepositoryTemplateResponse();
            response.setTenantId(tenant.getTenantId());
            response.setTenantName(tenant.getTenantName());
            response.setSuccess(result.isSuccess());
            response.setMessage(result.getMessage());
            response.setRepositoryPath(result.getRepositoryPath());

            if (!result.isSuccess() && result.getError() != null) {
                response.setErrorMessage(result.getError().getMessage());
            }

            // Add repository info if successful
            if (result.isSuccess()) {
                RepositoryTemplateResponse.RepositoryInfo repoInfo = new RepositoryTemplateResponse.RepositoryInfo();
                repoInfo.setArtifactId(tenant.getTenantId() + "-schema");
                repoInfo.setVersion("1.0.0");
                repoInfo.setSchemaName(tenant.getTenantId().replace("-", "_") + "_schema");
                repoInfo.setEnvironments(List.of("dev", "prod"));
                repoInfo.setChangesetCount(3); // Initial changesets
                repoInfo.setGeneratedFiles(List.of(
                    "pom.xml", "README.md", ".gitignore",
                    "config/tenant-config.json",
                    "src/main/resources/liquibase.properties",
                    "src/main/resources/db/changelog/db.changelog-master.sql",
                    "src/main/resources/db/changelog/changesets/v1.0/001-initial-schema.sql",
                    "src/main/resources/db/changelog/changesets/v1.0/002-sample-tables.sql",
                    "src/main/resources/db/changelog/changesets/dev/001-dev-test-data.sql",
                    ".github/workflows/dev-deploy.yml",
                    ".github/workflows/release.yml",
                    "src/assembly/changeset-bundle.xml"
                ));
                response.setRepositoryInfo(repoInfo);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Failed to generate repository template for tenant: {}", request.getTenantId(), e);
            
            RepositoryTemplateResponse errorResponse = new RepositoryTemplateResponse();
            errorResponse.setTenantId(request.getTenantId());
            errorResponse.setSuccess(false);
            errorResponse.setMessage("Failed to generate repository template");
            errorResponse.setErrorMessage(e.getMessage());
            
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }

    @Operation(summary = "Generate template for tenant", 
               description = "Generate repository template for the authenticated tenant")
    @ApiResponse(responseCode = "200", description = "Template generated successfully")
    @PostMapping("/generate-for-tenant")
    @PreAuthorize("hasAuthority('SCOPE_tenant:manage')")
    public ResponseEntity<RepositoryTemplateResponse> generateTemplateForTenant(
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        // Create request for the authenticated tenant
        RepositoryTemplateRequest request = new RepositoryTemplateRequest();
        request.setTenantId(tokenInfo.getTenantId());

        return generateTemplate(request, httpRequest);
    }

    @Operation(summary = "List generated repositories", 
               description = "Get list of all generated repository templates")
    @ApiResponse(responseCode = "200", description = "List retrieved successfully")
    @GetMapping("/list")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<String>> listGeneratedRepositories() {
        
        logger.debug("Listing generated repository templates");
        
        List<String> repositories = repositoryTemplateService.getGeneratedRepositories();
        return ResponseEntity.ok(repositories);
    }

    @Operation(summary = "Clean up old templates", 
               description = "Clean up old generated repository templates")
    @ApiResponse(responseCode = "200", description = "Cleanup completed")
    @PostMapping("/cleanup")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> cleanupOldTemplates(
            @Parameter(description = "Maximum age in days") 
            @RequestParam(defaultValue = "7") int maxAgeDays) {
        
        logger.info("Cleaning up repository templates older than {} days", maxAgeDays);
        
        repositoryTemplateService.cleanupOldRepositories(maxAgeDays);
        
        return ResponseEntity.ok("Cleanup completed for templates older than " + maxAgeDays + " days");
    }

    /**
     * Get tenant for request with proper authorization
     */
    private Tenant getTenantForRequest(String tenantId, JwtTokenProvider.JwtTokenInfo tokenInfo) {
        // For admin users, allow access to any tenant
        if (tokenInfo.hasScope("admin:read") || tokenInfo.hasScope("admin:write")) {
            return convertToTenantEntity(tenantService.getTenant(tenantId));
        }
        
        // For regular users, only allow access to their own tenant
        if (!tokenInfo.getTenantId().equals(tenantId)) {
            throw new IllegalArgumentException("Access denied to tenant: " + tenantId);
        }
        
        return convertToTenantEntity(tenantService.getTenant(tenantId));
    }

    /**
     * Convert TenantResponse to Tenant entity
     */
    private Tenant convertToTenantEntity(com.dbserenity.platform.dto.TenantResponse tenantResponse) {
        Tenant tenant = new Tenant();
        tenant.setId(tenantResponse.getId());
        tenant.setUuid(tenantResponse.getUuid());
        tenant.setTenantId(tenantResponse.getTenantId());
        tenant.setTenantName(tenantResponse.getTenantName());
        tenant.setDescription(tenantResponse.getDescription());
        tenant.setContactEmail(tenantResponse.getContactEmail());
        tenant.setGithubOrg(tenantResponse.getGithubOrg());
        tenant.setGithubRepo(tenantResponse.getGithubRepo());
        tenant.setIsActive(tenantResponse.getIsActive());
        tenant.setCreatedAt(tenantResponse.getCreatedAt());
        tenant.setUpdatedAt(tenantResponse.getUpdatedAt());
        tenant.setCreatedBy(tenantResponse.getCreatedBy());
        return tenant;
    }
}

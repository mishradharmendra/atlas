package com.dbserenity.platform.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for repository template generation request
 */
public class RepositoryTemplateRequest {

    @NotBlank(message = "Tenant ID is required")
    private String tenantId;

    private Boolean includeGitHubWorkflows = true;
    private Boolean includeSampleData = true;
    private Boolean includeDocumentation = true;
    private String templateVersion = "1.0";

    // Constructors
    public RepositoryTemplateRequest() {}

    public RepositoryTemplateRequest(String tenantId) {
        this.tenantId = tenantId;
    }

    // Getters and Setters
    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Boolean getIncludeGitHubWorkflows() {
        return includeGitHubWorkflows;
    }

    public void setIncludeGitHubWorkflows(Boolean includeGitHubWorkflows) {
        this.includeGitHubWorkflows = includeGitHubWorkflows;
    }

    public Boolean getIncludeSampleData() {
        return includeSampleData;
    }

    public void setIncludeSampleData(Boolean includeSampleData) {
        this.includeSampleData = includeSampleData;
    }

    public Boolean getIncludeDocumentation() {
        return includeDocumentation;
    }

    public void setIncludeDocumentation(Boolean includeDocumentation) {
        this.includeDocumentation = includeDocumentation;
    }

    public String getTemplateVersion() {
        return templateVersion;
    }

    public void setTemplateVersion(String templateVersion) {
        this.templateVersion = templateVersion;
    }

    @Override
    public String toString() {
        return "RepositoryTemplateRequest{" +
                "tenantId='" + tenantId + '\'' +
                ", includeGitHubWorkflows=" + includeGitHubWorkflows +
                ", includeSampleData=" + includeSampleData +
                ", includeDocumentation=" + includeDocumentation +
                ", templateVersion='" + templateVersion + '\'' +
                '}';
    }
}

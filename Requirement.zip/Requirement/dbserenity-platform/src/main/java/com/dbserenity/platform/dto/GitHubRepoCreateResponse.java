package com.dbserenity.platform.dto;

/**
 * DTO for GitHub repository creation response
 */
public class GitHubRepoCreateResponse {

    private String repositoryUrl;
    private String cloneUrl;
    private boolean created;
    private String message;

    // Constructors
    public GitHubRepoCreateResponse() {}

    public GitHubRepoCreateResponse(String repositoryUrl, String cloneUrl, boolean created) {
        this.repositoryUrl = repositoryUrl;
        this.cloneUrl = cloneUrl;
        this.created = created;
    }

    // Getters and Setters
    public String getRepositoryUrl() {
        return repositoryUrl;
    }

    public void setRepositoryUrl(String repositoryUrl) {
        this.repositoryUrl = repositoryUrl;
    }

    public String getCloneUrl() {
        return cloneUrl;
    }

    public void setCloneUrl(String cloneUrl) {
        this.cloneUrl = cloneUrl;
    }

    public boolean isCreated() {
        return created;
    }

    public void setCreated(boolean created) {
        this.created = created;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "GitHubRepoCreateResponse{" +
                "repositoryUrl='" + repositoryUrl + '\'' +
                ", cloneUrl='" + cloneUrl + '\'' +
                ", created=" + created +
                ", message='" + message + '\'' +
                '}';
    }
}

package com.dbserenity.platform.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for repository template generation response
 */
public class RepositoryTemplateResponse {

    private String tenantId;
    private String tenantName;
    private boolean success;
    private String repositoryPath;
    private String message;
    private String errorMessage;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime generatedAt;
    
    private RepositoryInfo repositoryInfo;

    // Constructors
    public RepositoryTemplateResponse() {
        this.generatedAt = LocalDateTime.now();
    }

    public RepositoryTemplateResponse(String tenantId, boolean success, String message) {
        this();
        this.tenantId = tenantId;
        this.success = success;
        this.message = message;
    }

    // Getters and Setters
    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getRepositoryPath() {
        return repositoryPath;
    }

    public void setRepositoryPath(String repositoryPath) {
        this.repositoryPath = repositoryPath;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(LocalDateTime generatedAt) {
        this.generatedAt = generatedAt;
    }

    public RepositoryInfo getRepositoryInfo() {
        return repositoryInfo;
    }

    public void setRepositoryInfo(RepositoryInfo repositoryInfo) {
        this.repositoryInfo = repositoryInfo;
    }

    @Override
    public String toString() {
        return "RepositoryTemplateResponse{" +
                "tenantId='" + tenantId + '\'' +
                ", tenantName='" + tenantName + '\'' +
                ", success=" + success +
                ", repositoryPath='" + repositoryPath + '\'' +
                ", message='" + message + '\'' +
                ", generatedAt=" + generatedAt +
                '}';
    }

    /**
     * Repository information
     */
    public static class RepositoryInfo {
        private String artifactId;
        private String version;
        private String schemaName;
        private List<String> environments;
        private List<String> generatedFiles;
        private int changesetCount;

        // Constructors
        public RepositoryInfo() {}

        // Getters and Setters
        public String getArtifactId() {
            return artifactId;
        }

        public void setArtifactId(String artifactId) {
            this.artifactId = artifactId;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getSchemaName() {
            return schemaName;
        }

        public void setSchemaName(String schemaName) {
            this.schemaName = schemaName;
        }

        public List<String> getEnvironments() {
            return environments;
        }

        public void setEnvironments(List<String> environments) {
            this.environments = environments;
        }

        public List<String> getGeneratedFiles() {
            return generatedFiles;
        }

        public void setGeneratedFiles(List<String> generatedFiles) {
            this.generatedFiles = generatedFiles;
        }

        public int getChangesetCount() {
            return changesetCount;
        }

        public void setChangesetCount(int changesetCount) {
            this.changesetCount = changesetCount;
        }

        @Override
        public String toString() {
            return "RepositoryInfo{" +
                    "artifactId='" + artifactId + '\'' +
                    ", version='" + version + '\'' +
                    ", schemaName='" + schemaName + '\'' +
                    ", environments=" + environments +
                    ", changesetCount=" + changesetCount +
                    '}';
        }
    }
}

package com.dbserenity.platform.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * DTO for changeset execution response
 */
public class ChangesetExecutionResponse {

    private String executionId;
    private String status;
    private String tenantId;
    private String environment;
    private String mode;
    private String artifactUrl;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime startedAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime completedAt;
    
    private Long durationMs;
    private String message;
    private ExecutionSummary summary;
    private List<String> logs;
    private Map<String, Object> metadata;

    // Constructors
    public ChangesetExecutionResponse() {}

    public ChangesetExecutionResponse(String executionId, String status, String tenantId, 
                                    String environment, String mode) {
        this.executionId = executionId;
        this.status = status;
        this.tenantId = tenantId;
        this.environment = environment;
        this.mode = mode;
        this.startedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getArtifactUrl() {
        return artifactUrl;
    }

    public void setArtifactUrl(String artifactUrl) {
        this.artifactUrl = artifactUrl;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public Long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Long durationMs) {
        this.durationMs = durationMs;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ExecutionSummary getSummary() {
        return summary;
    }

    public void setSummary(ExecutionSummary summary) {
        this.summary = summary;
    }

    public List<String> getLogs() {
        return logs;
    }

    public void setLogs(List<String> logs) {
        this.logs = logs;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    @Override
    public String toString() {
        return "ChangesetExecutionResponse{" +
                "executionId='" + executionId + '\'' +
                ", status='" + status + '\'' +
                ", tenantId='" + tenantId + '\'' +
                ", environment='" + environment + '\'' +
                ", mode='" + mode + '\'' +
                ", startedAt=" + startedAt +
                ", completedAt=" + completedAt +
                ", durationMs=" + durationMs +
                '}';
    }

    /**
     * Execution summary with statistics
     */
    public static class ExecutionSummary {
        private Integer changesetsExecuted;
        private Integer changesetsSkipped;
        private Integer changesetsFailed;
        private Integer sqlStatementsExecuted;
        private String databaseVersion;
        private String liquibaseVersion;

        // Constructors
        public ExecutionSummary() {}

        // Getters and Setters
        public Integer getChangesetsExecuted() {
            return changesetsExecuted;
        }

        public void setChangesetsExecuted(Integer changesetsExecuted) {
            this.changesetsExecuted = changesetsExecuted;
        }

        public Integer getChangesetsSkipped() {
            return changesetsSkipped;
        }

        public void setChangesetsSkipped(Integer changesetsSkipped) {
            this.changesetsSkipped = changesetsSkipped;
        }

        public Integer getChangesetsFailed() {
            return changesetsFailed;
        }

        public void setChangesetsFailed(Integer changesetsFailed) {
            this.changesetsFailed = changesetsFailed;
        }

        public Integer getSqlStatementsExecuted() {
            return sqlStatementsExecuted;
        }

        public void setSqlStatementsExecuted(Integer sqlStatementsExecuted) {
            this.sqlStatementsExecuted = sqlStatementsExecuted;
        }

        public String getDatabaseVersion() {
            return databaseVersion;
        }

        public void setDatabaseVersion(String databaseVersion) {
            this.databaseVersion = databaseVersion;
        }

        public String getLiquibaseVersion() {
            return liquibaseVersion;
        }

        public void setLiquibaseVersion(String liquibaseVersion) {
            this.liquibaseVersion = liquibaseVersion;
        }

        @Override
        public String toString() {
            return "ExecutionSummary{" +
                    "changesetsExecuted=" + changesetsExecuted +
                    ", changesetsSkipped=" + changesetsSkipped +
                    ", changesetsFailed=" + changesetsFailed +
                    ", sqlStatementsExecuted=" + sqlStatementsExecuted +
                    ", databaseVersion='" + databaseVersion + '\'' +
                    ", liquibaseVersion='" + liquibaseVersion + '\'' +
                    '}';
        }
    }
}

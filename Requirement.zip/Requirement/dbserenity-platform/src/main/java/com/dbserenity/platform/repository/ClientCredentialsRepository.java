package com.dbserenity.platform.repository;

import com.dbserenity.platform.entity.ClientCredentials;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ClientCredentials entity operations
 */
@Repository
public interface ClientCredentialsRepository extends JpaRepository<ClientCredentials, Long> {

    /**
     * Find client credentials by client ID
     */
    Optional<ClientCredentials> findByClientId(String clientId);

    /**
     * Find client credentials by client ID with tenant information
     */
    @Query("SELECT cc FROM ClientCredentials cc LEFT JOIN FETCH cc.tenant WHERE cc.clientId = :clientId")
    Optional<ClientCredentials> findByClientIdWithTenant(@Param("clientId") String clientId);

    /**
     * Find all client credentials for a tenant
     */
    @Query("SELECT cc FROM ClientCredentials cc WHERE cc.tenant.id = :tenantId")
    List<ClientCredentials> findByTenantId(@Param("tenantId") Long tenantId);

    /**
     * Find active client credentials
     */
    List<ClientCredentials> findByIsActiveTrueAndExpiresAtAfter(LocalDateTime now);

    /**
     * Find expired client credentials
     */
    List<ClientCredentials> findByExpiresAtBefore(LocalDateTime now);

    /**
     * Find client credentials by tenant ID string
     */
    @Query("SELECT cc FROM ClientCredentials cc WHERE cc.tenant.tenantId = :tenantId")
    List<ClientCredentials> findByTenantTenantId(@Param("tenantId") String tenantId);

    /**
     * Check if client ID exists
     */
    boolean existsByClientId(String clientId);

    /**
     * Find client credentials that haven't been used recently
     */
    @Query("SELECT cc FROM ClientCredentials cc WHERE cc.lastUsedAt < :cutoffDate OR cc.lastUsedAt IS NULL")
    List<ClientCredentials> findUnusedCredentials(@Param("cutoffDate") LocalDateTime cutoffDate);

    /**
     * Count active client credentials for a tenant
     */
    @Query("SELECT COUNT(cc) FROM ClientCredentials cc WHERE cc.tenant.id = :tenantId AND cc.isActive = true")
    long countActiveByTenantId(@Param("tenantId") Long tenantId);

    /**
     * Find client credentials created by a specific user
     */
    List<ClientCredentials> findByCreatedBy(String createdBy);

    /**
     * Find client credentials with specific scope
     */
    @Query("SELECT cc FROM ClientCredentials cc WHERE :scope MEMBER OF cc.scopes")
    List<ClientCredentials> findByScope(@Param("scope") String scope);
}

package com.dbserenity.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main application class for DBSerenity Platform
 * 
 * A comprehensive schema versioning platform using Liquibase for multi-tenant 
 * database change management with automated CI/CD integration.
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
@EnableTransactionManagement
public class DBSerenityPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(DBSerenityPlatformApplication.class, args);
    }
}

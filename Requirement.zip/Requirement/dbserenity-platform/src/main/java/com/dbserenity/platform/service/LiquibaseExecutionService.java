package com.dbserenity.platform.service;

import com.dbserenity.platform.dto.ChangesetExecutionRequest;
import com.dbserenity.platform.dto.ChangesetExecutionResponse;
import com.dbserenity.platform.entity.ExecutionLog;
import com.dbserenity.platform.entity.Tenant;
import com.dbserenity.platform.entity.TenantEnvironment;
import com.dbserenity.platform.repository.ExecutionLogRepository;
import com.dbserenity.platform.repository.TenantRepository;
import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.LiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.FileSystemResourceAccessor;
import liquibase.resource.ResourceAccessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Service for executing Liquibase changesets
 */
@Service
@Transactional
public class LiquibaseExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(LiquibaseExecutionService.class);

    private final ExecutionLogRepository executionLogRepository;
    private final TenantRepository tenantRepository;
    private final ArtifactService artifactService;
    private final NotificationService notificationService;
    private final AuditService auditService;

    @Autowired
    public LiquibaseExecutionService(ExecutionLogRepository executionLogRepository,
                                   TenantRepository tenantRepository,
                                   ArtifactService artifactService,
                                   NotificationService notificationService,
                                   AuditService auditService) {
        this.executionLogRepository = executionLogRepository;
        this.tenantRepository = tenantRepository;
        this.artifactService = artifactService;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    /**
     * Execute changesets asynchronously
     */
    @Async
    public CompletableFuture<ChangesetExecutionResponse> executeChangesets(
            ChangesetExecutionRequest request, String tenantId, String clientId) {
        
        String executionId = generateExecutionId();
        logger.info("Starting changeset execution: {} for tenant: {}", executionId, tenantId);

        // Get tenant information
        Tenant tenant = tenantRepository.findByTenantIdWithEnvironments(tenantId)
                .orElseThrow(() -> new IllegalArgumentException("Tenant not found: " + tenantId));

        // Create execution log
        ExecutionLog executionLog = new ExecutionLog(
            executionId, tenant, clientId, 
            request.getEnvironment(), request.getMode(), request.getArtifactUrl()
        );
        executionLog = executionLogRepository.save(executionLog);

        try {
            // Download and extract artifact
            File artifactDir = artifactService.downloadAndExtractArtifact(
                request.getArtifactUrl(), executionId);

            // Get tenant environment configuration
            TenantEnvironment environment = getTenantEnvironment(tenant, request.getEnvironment());
            
            // Execute changesets
            ChangesetExecutionResponse response = executeChangesetsInternal(
                request, executionLog, environment, artifactDir);

            // Update execution log with results
            updateExecutionLogSuccess(executionLog, response);

            // Send success notification
            sendNotification(request, response, true);

            logger.info("Changeset execution completed successfully: {}", executionId);
            return CompletableFuture.completedFuture(response);

        } catch (Exception e) {
            logger.error("Changeset execution failed: {}", executionId, e);
            
            // Update execution log with failure
            executionLog.markFailed(e.getMessage());
            executionLogRepository.save(executionLog);

            // Create error response
            ChangesetExecutionResponse errorResponse = createErrorResponse(
                executionId, tenantId, request, e.getMessage());

            // Send failure notification
            sendNotification(request, errorResponse, false);

            // Log audit event
            auditService.logChangesetExecutionFailed(tenantId, clientId, executionId, e.getMessage());

            return CompletableFuture.completedFuture(errorResponse);
        }
    }

    /**
     * Internal method to execute changesets
     */
    private ChangesetExecutionResponse executeChangesetsInternal(
            ChangesetExecutionRequest request, ExecutionLog executionLog, 
            TenantEnvironment environment, File artifactDir) throws Exception {

        logger.info("Executing changesets for execution: {}", executionLog.getExecutionId());

        // Update status to running
        executionLog.setStatus("RUNNING");
        executionLogRepository.save(executionLog);

        // Find changelog file
        File changelogFile = findChangelogFile(artifactDir);
        if (changelogFile == null) {
            throw new IllegalStateException("Changelog file not found in artifact");
        }

        // Create database connection
        String jdbcUrl = environment.getJdbcUrl();
        String username = environment.getUsername();
        String password = request.getDatabasePassword();

        Connection connection = null;
        Liquibase liquibase = null;
        StringWriter outputWriter = new StringWriter();

        try {
            // Establish database connection
            connection = DriverManager.getConnection(jdbcUrl, username, password);
            Database database = DatabaseFactory.getInstance()
                    .findCorrectDatabaseImplementation(new JdbcConnection(connection));

            // Set default schema if specified
            if (environment.getSchemaName() != null) {
                database.setDefaultSchemaName(environment.getSchemaName());
            }

            // Create resource accessor
            ResourceAccessor resourceAccessor = new FileSystemResourceAccessor(artifactDir);

            // Create Liquibase instance
            liquibase = new Liquibase(changelogFile.getName(), resourceAccessor, database);

            // Prepare contexts and labels
            Contexts contexts = prepareContexts(request, environment);
            LabelExpression labels = prepareLabels(request, environment);

            // Execute based on mode
            ChangesetExecutionResponse response;
            if ("dry-run".equals(request.getMode())) {
                response = executeDryRun(liquibase, contexts, labels, executionLog, outputWriter);
            } else {
                response = executeUpdate(liquibase, contexts, labels, executionLog, outputWriter, request);
            }

            // Set execution metadata
            response.setExecutionId(executionLog.getExecutionId());
            response.setTenantId(executionLog.getTenant().getTenantId());
            response.setEnvironment(request.getEnvironment());
            response.setMode(request.getMode());
            response.setArtifactUrl(request.getArtifactUrl());
            response.setStartedAt(executionLog.getStartedAt());

            return response;

        } finally {
            // Clean up resources
            if (liquibase != null) {
                try {
                    liquibase.close();
                } catch (Exception e) {
                    logger.warn("Error closing Liquibase: {}", e.getMessage());
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    logger.warn("Error closing database connection: {}", e.getMessage());
                }
            }
        }
    }

    /**
     * Execute dry run (generate SQL without executing)
     */
    private ChangesetExecutionResponse executeDryRun(Liquibase liquibase, Contexts contexts, 
                                                   LabelExpression labels, ExecutionLog executionLog,
                                                   StringWriter outputWriter) throws LiquibaseException {
        
        logger.info("Executing dry run for execution: {}", executionLog.getExecutionId());

        // Generate update SQL
        liquibase.update(contexts, labels, outputWriter);
        String generatedSql = outputWriter.toString();

        // Create response
        ChangesetExecutionResponse response = new ChangesetExecutionResponse();
        response.setStatus("SUCCESS");
        response.setMessage("Dry run completed successfully");
        response.setCompletedAt(LocalDateTime.now());
        
        // Set logs with generated SQL
        response.setLogs(Arrays.asList(generatedSql.split("\n")));

        // Create summary
        ChangesetExecutionResponse.ExecutionSummary summary = new ChangesetExecutionResponse.ExecutionSummary();
        summary.setChangesetsExecuted(0); // Dry run doesn't execute
        summary.setLiquibaseVersion(liquibase.getDatabase().getDatabaseProductVersion());
        response.setSummary(summary);

        return response;
    }

    /**
     * Execute actual database update
     */
    private ChangesetExecutionResponse executeUpdate(Liquibase liquibase, Contexts contexts, 
                                                    LabelExpression labels, ExecutionLog executionLog,
                                                    StringWriter outputWriter, ChangesetExecutionRequest request) 
                                                    throws LiquibaseException {
        
        logger.info("Executing database update for execution: {}", executionLog.getExecutionId());

        boolean rollbackOnFailure = request.getExecutionOptions() != null && 
                                   request.getExecutionOptions().getRollbackOnFailure();

        try {
            // Execute update
            liquibase.update(contexts, labels);

            // Create success response
            ChangesetExecutionResponse response = new ChangesetExecutionResponse();
            response.setStatus("SUCCESS");
            response.setMessage("Changesets executed successfully");
            response.setCompletedAt(LocalDateTime.now());

            // Get execution statistics
            ChangesetExecutionResponse.ExecutionSummary summary = new ChangesetExecutionResponse.ExecutionSummary();
            // TODO: Get actual statistics from Liquibase execution
            summary.setChangesetsExecuted(1); // Placeholder
            summary.setChangesetsSkipped(0);
            summary.setChangesetsFailed(0);
            summary.setLiquibaseVersion(liquibase.getDatabase().getDatabaseProductVersion());
            summary.setDatabaseVersion(liquibase.getDatabase().getDatabaseProductVersion());
            response.setSummary(summary);

            return response;

        } catch (LiquibaseException e) {
            logger.error("Liquibase execution failed for execution: {}", executionLog.getExecutionId(), e);

            // Attempt rollback if enabled
            if (rollbackOnFailure) {
                try {
                    logger.info("Attempting rollback for execution: {}", executionLog.getExecutionId());
                    // TODO: Implement rollback logic based on changeset count or tag
                    executionLog.setRollbackExecuted(true);
                } catch (Exception rollbackException) {
                    logger.error("Rollback failed for execution: {}", executionLog.getExecutionId(), rollbackException);
                }
            }

            throw e;
        }
    }

    /**
     * Prepare Liquibase contexts
     */
    private Contexts prepareContexts(ChangesetExecutionRequest request, TenantEnvironment environment) {
        Set<String> contextSet = new HashSet<>();
        
        // Add environment contexts
        if (environment.getContexts() != null) {
            contextSet.addAll(environment.getContexts());
        }
        
        // Add request contexts
        if (request.getExecutionOptions() != null && 
            request.getExecutionOptions().getContexts() != null) {
            contextSet.addAll(Arrays.asList(request.getExecutionOptions().getContexts().split(",")));
        }
        
        return new Contexts(contextSet);
    }

    /**
     * Prepare Liquibase labels
     */
    private LabelExpression prepareLabels(ChangesetExecutionRequest request, TenantEnvironment environment) {
        Set<String> labelSet = new HashSet<>();
        
        // Add environment labels
        if (environment.getLabels() != null) {
            labelSet.addAll(environment.getLabels());
        }
        
        // Add request labels
        if (request.getExecutionOptions() != null && 
            request.getExecutionOptions().getLabels() != null) {
            labelSet.addAll(Arrays.asList(request.getExecutionOptions().getLabels().split(",")));
        }
        
        return new LabelExpression(String.join(",", labelSet));
    }

    /**
     * Find changelog file in artifact directory
     */
    private File findChangelogFile(File artifactDir) {
        // Look for common changelog file names
        String[] possibleNames = {
            "db/changelog/db.changelog-master.sql",
            "db.changelog-master.sql",
            "changelog-master.sql",
            "master.sql"
        };
        
        for (String name : possibleNames) {
            File file = new File(artifactDir, name);
            if (file.exists()) {
                return file;
            }
        }
        
        return null;
    }

    /**
     * Get tenant environment configuration
     */
    private TenantEnvironment getTenantEnvironment(Tenant tenant, String environmentName) {
        return tenant.getEnvironments().stream()
                .filter(env -> env.getEnvironmentName().equals(environmentName))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                    "Environment not found: " + environmentName + " for tenant: " + tenant.getTenantId()));
    }

    /**
     * Update execution log with success results
     */
    private void updateExecutionLogSuccess(ExecutionLog executionLog, ChangesetExecutionResponse response) {
        executionLog.markCompleted("SUCCESS", response.getMessage());
        
        if (response.getSummary() != null) {
            executionLog.setChangesetsExecuted(response.getSummary().getChangesetsExecuted());
            executionLog.setChangesetsSkipped(response.getSummary().getChangesetsSkipped());
            executionLog.setChangesetsFailed(response.getSummary().getChangesetsFailed());
            executionLog.setSqlStatementsExecuted(response.getSummary().getSqlStatementsExecuted());
            executionLog.setDatabaseVersion(response.getSummary().getDatabaseVersion());
            executionLog.setLiquibaseVersion(response.getSummary().getLiquibaseVersion());
        }
        
        executionLogRepository.save(executionLog);
    }

    /**
     * Create error response
     */
    private ChangesetExecutionResponse createErrorResponse(String executionId, String tenantId, 
                                                         ChangesetExecutionRequest request, String errorMessage) {
        ChangesetExecutionResponse response = new ChangesetExecutionResponse();
        response.setExecutionId(executionId);
        response.setTenantId(tenantId);
        response.setEnvironment(request.getEnvironment());
        response.setMode(request.getMode());
        response.setArtifactUrl(request.getArtifactUrl());
        response.setStatus("FAILED");
        response.setMessage(errorMessage);
        response.setCompletedAt(LocalDateTime.now());
        
        return response;
    }

    /**
     * Send notification
     */
    private void sendNotification(ChangesetExecutionRequest request, ChangesetExecutionResponse response, boolean success) {
        try {
            if (request.getExecutionOptions() != null && 
                request.getExecutionOptions().getNotificationEmail() != null) {
                
                notificationService.sendExecutionNotification(
                    request.getExecutionOptions().getNotificationEmail(),
                    response,
                    success
                );
            }
        } catch (Exception e) {
            logger.warn("Failed to send notification for execution: {}", response.getExecutionId(), e);
        }
    }

    /**
     * Generate unique execution ID
     */
    private String generateExecutionId() {
        return "exec-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 8);
    }

    /**
     * Get execution status
     */
    @Transactional(readOnly = true)
    public ChangesetExecutionResponse getExecutionStatus(String executionId) {
        ExecutionLog executionLog = executionLogRepository.findByExecutionId(executionId)
                .orElseThrow(() -> new IllegalArgumentException("Execution not found: " + executionId));

        return convertToResponse(executionLog);
    }

    /**
     * Convert execution log to response
     */
    private ChangesetExecutionResponse convertToResponse(ExecutionLog executionLog) {
        ChangesetExecutionResponse response = new ChangesetExecutionResponse();
        response.setExecutionId(executionLog.getExecutionId());
        response.setTenantId(executionLog.getTenant().getTenantId());
        response.setEnvironment(executionLog.getEnvironment());
        response.setMode(executionLog.getMode());
        response.setArtifactUrl(executionLog.getArtifactUrl());
        response.setStatus(executionLog.getStatus());
        response.setStartedAt(executionLog.getStartedAt());
        response.setCompletedAt(executionLog.getCompletedAt());
        response.setDurationMs(executionLog.getDurationMs());
        response.setMessage(executionLog.getMessage());

        // Create summary if execution is completed
        if (executionLog.isCompleted()) {
            ChangesetExecutionResponse.ExecutionSummary summary = new ChangesetExecutionResponse.ExecutionSummary();
            summary.setChangesetsExecuted(executionLog.getChangesetsExecuted());
            summary.setChangesetsSkipped(executionLog.getChangesetsSkipped());
            summary.setChangesetsFailed(executionLog.getChangesetsFailed());
            summary.setSqlStatementsExecuted(executionLog.getSqlStatementsExecuted());
            summary.setDatabaseVersion(executionLog.getDatabaseVersion());
            summary.setLiquibaseVersion(executionLog.getLiquibaseVersion());
            response.setSummary(summary);
        }

        return response;
    }
}

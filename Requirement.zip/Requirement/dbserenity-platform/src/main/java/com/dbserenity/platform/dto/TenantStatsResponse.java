package com.dbserenity.platform.dto;

/**
 * DTO for tenant statistics response
 */
public class TenantStatsResponse {

    private long totalTenants;
    private long activeTenants;
    private long inactiveTenants;
    private long tenantsWithGitHubRepo;

    // Constructors
    public TenantStatsResponse() {}

    public TenantStatsResponse(long totalTenants, long activeTenants, long inactiveTenants, long tenantsWithGitHubRepo) {
        this.totalTenants = totalTenants;
        this.activeTenants = activeTenants;
        this.inactiveTenants = inactiveTenants;
        this.tenantsWithGitHubRepo = tenantsWithGitHubRepo;
    }

    // Getters and Setters
    public long getTotalTenants() {
        return totalTenants;
    }

    public void setTotalTenants(long totalTenants) {
        this.totalTenants = totalTenants;
    }

    public long getActiveTenants() {
        return activeTenants;
    }

    public void setActiveTenants(long activeTenants) {
        this.activeTenants = activeTenants;
    }

    public long getInactiveTenants() {
        return inactiveTenants;
    }

    public void setInactiveTenants(long inactiveTenants) {
        this.inactiveTenants = inactiveTenants;
    }

    public long getTenantsWithGitHubRepo() {
        return tenantsWithGitHubRepo;
    }

    public void setTenantsWithGitHubRepo(long tenantsWithGitHubRepo) {
        this.tenantsWithGitHubRepo = tenantsWithGitHubRepo;
    }

    @Override
    public String toString() {
        return "TenantStatsResponse{" +
                "totalTenants=" + totalTenants +
                ", activeTenants=" + activeTenants +
                ", inactiveTenants=" + inactiveTenants +
                ", tenantsWithGitHubRepo=" + tenantsWithGitHubRepo +
                '}';
    }
}

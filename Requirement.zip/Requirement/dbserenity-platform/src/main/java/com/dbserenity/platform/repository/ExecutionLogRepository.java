package com.dbserenity.platform.repository;

import com.dbserenity.platform.entity.ExecutionLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ExecutionLog entity operations
 */
@Repository
public interface ExecutionLogRepository extends JpaRepository<ExecutionLog, Long> {

    /**
     * Find execution log by execution ID
     */
    Optional<ExecutionLog> findByExecutionId(String executionId);

    /**
     * Find execution logs by tenant ID
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.tenant.tenantId = :tenantId ORDER BY el.startedAt DESC")
    List<ExecutionLog> findByTenantId(@Param("tenantId") String tenantId);

    /**
     * Find execution logs by tenant ID with pagination
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.tenant.tenantId = :tenantId ORDER BY el.startedAt DESC")
    Page<ExecutionLog> findByTenantId(@Param("tenantId") String tenantId, Pageable pageable);

    /**
     * Find execution logs by client ID
     */
    List<ExecutionLog> findByClientIdOrderByStartedAtDesc(String clientId);

    /**
     * Find execution logs by status
     */
    List<ExecutionLog> findByStatusOrderByStartedAtDesc(String status);

    /**
     * Find running executions
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.status IN ('STARTED', 'RUNNING') ORDER BY el.startedAt")
    List<ExecutionLog> findRunningExecutions();

    /**
     * Find execution logs by environment
     */
    List<ExecutionLog> findByEnvironmentOrderByStartedAtDesc(String environment);

    /**
     * Find execution logs by mode
     */
    List<ExecutionLog> findByModeOrderByStartedAtDesc(String mode);

    /**
     * Find execution logs by date range
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.startedAt BETWEEN :startDate AND :endDate ORDER BY el.startedAt DESC")
    List<ExecutionLog> findByDateRange(@Param("startDate") LocalDateTime startDate, 
                                      @Param("endDate") LocalDateTime endDate);

    /**
     * Find execution logs by tenant and environment
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.tenant.tenantId = :tenantId AND el.environment = :environment ORDER BY el.startedAt DESC")
    List<ExecutionLog> findByTenantIdAndEnvironment(@Param("tenantId") String tenantId, 
                                                   @Param("environment") String environment);

    /**
     * Find failed executions
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.status = 'FAILED' ORDER BY el.startedAt DESC")
    List<ExecutionLog> findFailedExecutions();

    /**
     * Find successful executions
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.status = 'SUCCESS' ORDER BY el.startedAt DESC")
    List<ExecutionLog> findSuccessfulExecutions();

    /**
     * Find executions that took longer than specified duration
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.durationMs > :durationMs ORDER BY el.durationMs DESC")
    List<ExecutionLog> findLongRunningExecutions(@Param("durationMs") Long durationMs);

    /**
     * Find executions with rollback
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.rollbackExecuted = true ORDER BY el.startedAt DESC")
    List<ExecutionLog> findExecutionsWithRollback();

    /**
     * Count executions by status
     */
    @Query("SELECT COUNT(el) FROM ExecutionLog el WHERE el.status = :status")
    long countByStatus(@Param("status") String status);

    /**
     * Count executions by tenant
     */
    @Query("SELECT COUNT(el) FROM ExecutionLog el WHERE el.tenant.tenantId = :tenantId")
    long countByTenantId(@Param("tenantId") String tenantId);

    /**
     * Find recent executions (last N days)
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.startedAt >= :cutoffDate ORDER BY el.startedAt DESC")
    List<ExecutionLog> findRecentExecutions(@Param("cutoffDate") LocalDateTime cutoffDate);

    /**
     * Find executions by artifact URL
     */
    List<ExecutionLog> findByArtifactUrlOrderByStartedAtDesc(String artifactUrl);

    /**
     * Search executions by multiple criteria
     */
    @Query("SELECT el FROM ExecutionLog el WHERE " +
           "(:tenantId IS NULL OR el.tenant.tenantId = :tenantId) AND " +
           "(:clientId IS NULL OR el.clientId = :clientId) AND " +
           "(:environment IS NULL OR el.environment = :environment) AND " +
           "(:status IS NULL OR el.status = :status) AND " +
           "(:mode IS NULL OR el.mode = :mode) " +
           "ORDER BY el.startedAt DESC")
    Page<ExecutionLog> searchExecutions(@Param("tenantId") String tenantId,
                                       @Param("clientId") String clientId,
                                       @Param("environment") String environment,
                                       @Param("status") String status,
                                       @Param("mode") String mode,
                                       Pageable pageable);

    /**
     * Find executions that need notification
     */
    @Query("SELECT el FROM ExecutionLog el WHERE el.notificationSent = false AND el.status IN ('SUCCESS', 'FAILED')")
    List<ExecutionLog> findExecutionsNeedingNotification();

    /**
     * Get execution statistics for a tenant
     */
    @Query("SELECT " +
           "COUNT(el) as total, " +
           "SUM(CASE WHEN el.status = 'SUCCESS' THEN 1 ELSE 0 END) as successful, " +
           "SUM(CASE WHEN el.status = 'FAILED' THEN 1 ELSE 0 END) as failed, " +
           "AVG(el.durationMs) as avgDuration " +
           "FROM ExecutionLog el WHERE el.tenant.tenantId = :tenantId")
    Object[] getExecutionStatsByTenantId(@Param("tenantId") String tenantId);

    /**
     * Delete old execution logs (cleanup)
     */
    @Query("DELETE FROM ExecutionLog el WHERE el.startedAt < :cutoffDate")
    void deleteOldExecutionLogs(@Param("cutoffDate") LocalDateTime cutoffDate);
}

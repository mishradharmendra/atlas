package com.dbserenity.platform.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

/**
 * DTO for updating tenant information
 */
public class TenantUpdateRequest {

    @Size(max = 255, message = "Tenant name must not exceed 255 characters")
    private String tenantName;

    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;

    @Email(message = "Contact email must be valid")
    private String contactEmail;

    @Size(max = 100, message = "GitHub organization must not exceed 100 characters")
    private String githubOrg;

    @Size(max = 100, message = "GitHub repository must not exceed 100 characters")
    private String githubRepo;

    // Constructors
    public TenantUpdateRequest() {}

    // Getters and Setters
    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getGithubOrg() {
        return githubOrg;
    }

    public void setGithubOrg(String githubOrg) {
        this.githubOrg = githubOrg;
    }

    public String getGithubRepo() {
        return githubRepo;
    }

    public void setGithubRepo(String githubRepo) {
        this.githubRepo = githubRepo;
    }

    @Override
    public String toString() {
        return "TenantUpdateRequest{" +
                "tenantName='" + tenantName + '\'' +
                ", description='" + description + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", githubOrg='" + githubOrg + '\'' +
                ", githubRepo='" + githubRepo + '\'' +
                '}';
    }
}

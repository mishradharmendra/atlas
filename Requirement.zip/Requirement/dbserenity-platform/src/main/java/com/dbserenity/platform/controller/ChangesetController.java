package com.dbserenity.platform.controller;

import com.dbserenity.platform.dto.ChangesetExecutionRequest;
import com.dbserenity.platform.dto.ChangesetExecutionResponse;
import com.dbserenity.platform.security.JwtTokenProvider;
import com.dbserenity.platform.service.LiquibaseExecutionService;
import com.dbserenity.platform.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

/**
 * REST controller for changeset execution operations
 */
@RestController
@RequestMapping("/v1/changesets")
@Tag(name = "Changeset Execution", description = "APIs for executing database changesets")
@SecurityRequirement(name = "bearerAuth")
public class ChangesetController {

    private static final Logger logger = LoggerFactory.getLogger(ChangesetController.class);

    private final LiquibaseExecutionService liquibaseExecutionService;
    private final TenantService tenantService;

    @Autowired
    public ChangesetController(LiquibaseExecutionService liquibaseExecutionService,
                             TenantService tenantService) {
        this.liquibaseExecutionService = liquibaseExecutionService;
        this.tenantService = tenantService;
    }

    @Operation(summary = "Execute changesets", 
               description = "Execute database changesets for a tenant environment")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "202", description = "Execution started successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid request"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "403", description = "Insufficient permissions"),
        @ApiResponse(responseCode = "404", description = "Tenant not found")
    })
    @PostMapping("/execute")
    @PreAuthorize("hasAuthority('SCOPE_changeset:execute')")
    public ResponseEntity<ChangesetExecutionResponse> executeChangesets(
            @Valid @RequestBody ChangesetExecutionRequest request,
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes (set by JWT filter)
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        String tenantId = tokenInfo.getTenantId();
        String clientId = tokenInfo.getClientId();

        logger.info("Changeset execution request from client: {} for tenant: {}", clientId, tenantId);

        // Validate tenant is active
        tenantService.validateTenantActive(tenantId);

        // Start asynchronous execution
        CompletableFuture<ChangesetExecutionResponse> executionFuture = 
            liquibaseExecutionService.executeChangesets(request, tenantId, clientId);

        // Return immediate response with execution ID
        try {
            ChangesetExecutionResponse response = executionFuture.get();
            
            // For async execution, we would return 202 Accepted with execution ID
            // For now, we'll return the completed response
            return ResponseEntity.accepted().body(response);
            
        } catch (Exception e) {
            logger.error("Failed to start changeset execution", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @Operation(summary = "Get execution status", 
               description = "Get the status of a changeset execution")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Status retrieved successfully"),
        @ApiResponse(responseCode = "404", description = "Execution not found"),
        @ApiResponse(responseCode = "401", description = "Unauthorized")
    })
    @GetMapping("/status/{executionId}")
    @PreAuthorize("hasAuthority('SCOPE_changeset:status')")
    public ResponseEntity<ChangesetExecutionResponse> getExecutionStatus(
            @Parameter(description = "Execution ID") 
            @PathVariable String executionId,
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        logger.debug("Getting execution status: {} for client: {}", executionId, tokenInfo.getClientId());

        try {
            ChangesetExecutionResponse response = liquibaseExecutionService.getExecutionStatus(executionId);
            
            // Verify the execution belongs to the same tenant
            if (!tokenInfo.getTenantId().equals(response.getTenantId())) {
                logger.warn("Client {} attempted to access execution {} from different tenant", 
                           tokenInfo.getClientId(), executionId);
                return ResponseEntity.notFound().build();
            }
            
            return ResponseEntity.ok(response);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Validate changeset", 
               description = "Validate changesets without executing them (dry run)")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Validation completed"),
        @ApiResponse(responseCode = "400", description = "Invalid request"),
        @ApiResponse(responseCode = "401", description = "Unauthorized")
    })
    @PostMapping("/validate")
    @PreAuthorize("hasAuthority('SCOPE_changeset:execute')")
    public ResponseEntity<ChangesetExecutionResponse> validateChangesets(
            @Valid @RequestBody ChangesetExecutionRequest request,
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        String tenantId = tokenInfo.getTenantId();
        String clientId = tokenInfo.getClientId();

        logger.info("Changeset validation request from client: {} for tenant: {}", clientId, tenantId);

        // Force dry-run mode for validation
        request.setMode("dry-run");

        // Validate tenant is active
        tenantService.validateTenantActive(tenantId);

        // Execute validation
        try {
            CompletableFuture<ChangesetExecutionResponse> validationFuture = 
                liquibaseExecutionService.executeChangesets(request, tenantId, clientId);
            
            ChangesetExecutionResponse response = validationFuture.get();
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Failed to validate changesets", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @Operation(summary = "Get execution history", 
               description = "Get execution history for the authenticated tenant")
    @ApiResponse(responseCode = "200", description = "History retrieved successfully")
    @GetMapping("/history")
    @PreAuthorize("hasAuthority('SCOPE_changeset:status')")
    public ResponseEntity<ExecutionHistoryResponse> getExecutionHistory(
            @Parameter(description = "Page number (0-based)") 
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") 
            @RequestParam(defaultValue = "20") int size,
            @Parameter(description = "Environment filter") 
            @RequestParam(required = false) String environment,
            @Parameter(description = "Status filter") 
            @RequestParam(required = false) String status,
            HttpServletRequest httpRequest) {
        
        // Get token info from request attributes
        JwtTokenProvider.JwtTokenInfo tokenInfo = 
            (JwtTokenProvider.JwtTokenInfo) httpRequest.getAttribute("tokenInfo");
        
        if (tokenInfo == null) {
            return ResponseEntity.status(401).build();
        }

        String tenantId = tokenInfo.getTenantId();
        logger.debug("Getting execution history for tenant: {}", tenantId);

        // TODO: Implement execution history retrieval
        ExecutionHistoryResponse response = new ExecutionHistoryResponse();
        response.setTenantId(tenantId);
        response.setPage(page);
        response.setSize(size);
        response.setTotalElements(0L);
        response.setExecutions(java.util.Collections.emptyList());

        return ResponseEntity.ok(response);
    }

    /**
     * Response DTO for execution history
     */
    public static class ExecutionHistoryResponse {
        private String tenantId;
        private int page;
        private int size;
        private long totalElements;
        private java.util.List<ChangesetExecutionResponse> executions;

        // Getters and Setters
        public String getTenantId() { return tenantId; }
        public void setTenantId(String tenantId) { this.tenantId = tenantId; }

        public int getPage() { return page; }
        public void setPage(int page) { this.page = page; }

        public int getSize() { return size; }
        public void setSize(int size) { this.size = size; }

        public long getTotalElements() { return totalElements; }
        public void setTotalElements(long totalElements) { this.totalElements = totalElements; }

        public java.util.List<ChangesetExecutionResponse> getExecutions() { return executions; }
        public void setExecutions(java.util.List<ChangesetExecutionResponse> executions) { this.executions = executions; }
    }
}

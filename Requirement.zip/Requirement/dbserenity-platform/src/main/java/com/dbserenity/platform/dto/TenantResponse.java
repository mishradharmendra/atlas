package com.dbserenity.platform.dto;

import com.dbserenity.platform.entity.Tenant;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * DTO for tenant response
 */
public class TenantResponse {

    private Long id;
    private UUID uuid;
    private String tenantId;
    private String tenantName;
    private String description;
    private String contactEmail;
    private String githubOrg;
    private String githubRepo;
    private Boolean isActive;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime updatedAt;

    private String createdBy;
    private List<TenantEnvironmentResponse> environments;
    private List<ClientCredentialsResponse> clientCredentials;
    private java.util.Map<String, Object> metadata;

    // Constructors
    public TenantResponse() {}

    public TenantResponse(Tenant tenant) {
        this.id = tenant.getId();
        this.uuid = tenant.getUuid();
        this.tenantId = tenant.getTenantId();
        this.tenantName = tenant.getTenantName();
        this.description = tenant.getDescription();
        this.contactEmail = tenant.getContactEmail();
        this.githubOrg = tenant.getGithubOrg();
        this.githubRepo = tenant.getGithubRepo();
        this.isActive = tenant.getIsActive();
        this.createdAt = tenant.getCreatedAt();
        this.updatedAt = tenant.getUpdatedAt();
        this.createdBy = tenant.getCreatedBy();
        
        // Convert environments if loaded
        if (tenant.getEnvironments() != null) {
            this.environments = tenant.getEnvironments().stream()
                    .map(TenantEnvironmentResponse::new)
                    .collect(Collectors.toList());
        }
        
        // Convert client credentials if loaded (without sensitive data)
        if (tenant.getClientCredentials() != null) {
            this.clientCredentials = tenant.getClientCredentials().stream()
                    .map(ClientCredentialsResponse::new)
                    .collect(Collectors.toList());
        }
    }

    // Static factory methods
    public static TenantResponse from(Tenant tenant) {
        return new TenantResponse(tenant);
    }

    public static TenantResponse fromBasic(Tenant tenant) {
        TenantResponse response = new TenantResponse();
        response.id = tenant.getId();
        response.uuid = tenant.getUuid();
        response.tenantId = tenant.getTenantId();
        response.tenantName = tenant.getTenantName();
        response.description = tenant.getDescription();
        response.contactEmail = tenant.getContactEmail();
        response.githubOrg = tenant.getGithubOrg();
        response.githubRepo = tenant.getGithubRepo();
        response.isActive = tenant.getIsActive();
        response.createdAt = tenant.getCreatedAt();
        response.updatedAt = tenant.getUpdatedAt();
        response.createdBy = tenant.getCreatedBy();
        return response;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getGithubOrg() {
        return githubOrg;
    }

    public void setGithubOrg(String githubOrg) {
        this.githubOrg = githubOrg;
    }

    public String getGithubRepo() {
        return githubRepo;
    }

    public void setGithubRepo(String githubRepo) {
        this.githubRepo = githubRepo;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public List<TenantEnvironmentResponse> getEnvironments() {
        return environments;
    }

    public void setEnvironments(List<TenantEnvironmentResponse> environments) {
        this.environments = environments;
    }

    public List<ClientCredentialsResponse> getClientCredentials() {
        return clientCredentials;
    }

    public void setClientCredentials(List<ClientCredentialsResponse> clientCredentials) {
        this.clientCredentials = clientCredentials;
    }

    public java.util.Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(java.util.Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    @Override
    public String toString() {
        return "TenantResponse{" +
                "id=" + id +
                ", uuid=" + uuid +
                ", tenantId='" + tenantId + '\'' +
                ", tenantName='" + tenantName + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}';
    }
}

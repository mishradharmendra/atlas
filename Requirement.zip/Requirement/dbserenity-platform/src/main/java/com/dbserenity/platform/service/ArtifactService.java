package com.dbserenity.platform.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Service for managing changeset artifacts
 */
@Service
public class ArtifactService {

    private static final Logger logger = LoggerFactory.getLogger(ArtifactService.class);

    private final WebClient webClient;
    private final String workingDirectory;

    public ArtifactService(@Value("${dbserenity.artifact.working-dir:./work}") String workingDirectory) {
        this.webClient = WebClient.builder().build();
        this.workingDirectory = workingDirectory;
        
        // Ensure working directory exists
        try {
            Files.createDirectories(Paths.get(workingDirectory));
        } catch (IOException e) {
            logger.error("Failed to create working directory: {}", workingDirectory, e);
        }
    }

    /**
     * Download and extract artifact
     */
    public File downloadAndExtractArtifact(String artifactUrl, String executionId) throws IOException {
        logger.info("Downloading artifact from: {} for execution: {}", artifactUrl, executionId);

        // Create execution-specific directory
        Path executionDir = Paths.get(workingDirectory, executionId);
        Files.createDirectories(executionDir);

        // Download artifact
        File artifactFile = downloadArtifact(artifactUrl, executionDir);
        
        // Extract artifact
        File extractedDir = extractArtifact(artifactFile, executionDir);
        
        // Clean up downloaded file
        if (artifactFile.exists()) {
            artifactFile.delete();
        }
        
        logger.info("Artifact extracted successfully to: {}", extractedDir.getAbsolutePath());
        return extractedDir;
    }

    /**
     * Download artifact from URL
     */
    private File downloadArtifact(String artifactUrl, Path executionDir) throws IOException {
        logger.debug("Downloading artifact from: {}", artifactUrl);

        File artifactFile = executionDir.resolve("artifact.zip").toFile();
        
        try {
            // Download using WebClient
            byte[] artifactData = webClient.get()
                    .uri(artifactUrl)
                    .retrieve()
                    .bodyToMono(byte[].class)
                    .block();

            if (artifactData == null) {
                throw new IOException("Failed to download artifact: empty response");
            }

            // Write to file
            try (FileOutputStream fos = new FileOutputStream(artifactFile)) {
                fos.write(artifactData);
            }

            logger.debug("Artifact downloaded successfully: {} bytes", artifactData.length);
            return artifactFile;

        } catch (Exception e) {
            logger.error("Failed to download artifact from: {}", artifactUrl, e);
            throw new IOException("Failed to download artifact: " + e.getMessage(), e);
        }
    }

    /**
     * Extract ZIP artifact
     */
    private File extractArtifact(File artifactFile, Path executionDir) throws IOException {
        logger.debug("Extracting artifact: {}", artifactFile.getAbsolutePath());

        File extractDir = executionDir.resolve("extracted").toFile();
        extractDir.mkdirs();

        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(artifactFile))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            while ((entry = zis.getNextEntry()) != null) {
                File entryFile = new File(extractDir, entry.getName());
                
                // Security check: prevent directory traversal
                if (!entryFile.getCanonicalPath().startsWith(extractDir.getCanonicalPath())) {
                    throw new IOException("Entry is outside of the target directory: " + entry.getName());
                }

                if (entry.isDirectory()) {
                    entryFile.mkdirs();
                } else {
                    // Ensure parent directories exist
                    entryFile.getParentFile().mkdirs();
                    
                    // Extract file
                    try (FileOutputStream fos = new FileOutputStream(entryFile)) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }
                }
                zis.closeEntry();
            }
        }

        logger.debug("Artifact extracted successfully to: {}", extractDir.getAbsolutePath());
        return extractDir;
    }

    /**
     * Validate artifact structure
     */
    public boolean validateArtifactStructure(File artifactDir) {
        logger.debug("Validating artifact structure: {}", artifactDir.getAbsolutePath());

        // Check for required files/directories
        String[] requiredPaths = {
            "db/changelog",
            "config/tenant-config.json"
        };

        for (String path : requiredPaths) {
            File requiredFile = new File(artifactDir, path);
            if (!requiredFile.exists()) {
                logger.warn("Required path not found in artifact: {}", path);
                return false;
            }
        }

        // Check for changelog master file
        String[] possibleMasterFiles = {
            "db/changelog/db.changelog-master.sql",
            "db/changelog/master.sql",
            "db/changelog/changelog-master.sql"
        };

        boolean masterFileFound = false;
        for (String masterFile : possibleMasterFiles) {
            if (new File(artifactDir, masterFile).exists()) {
                masterFileFound = true;
                break;
            }
        }

        if (!masterFileFound) {
            logger.warn("No master changelog file found in artifact");
            return false;
        }

        logger.debug("Artifact structure validation passed");
        return true;
    }

    /**
     * Clean up execution directory
     */
    public void cleanupExecution(String executionId) {
        try {
            Path executionDir = Paths.get(workingDirectory, executionId);
            if (Files.exists(executionDir)) {
                deleteDirectory(executionDir.toFile());
                logger.debug("Cleaned up execution directory: {}", executionId);
            }
        } catch (Exception e) {
            logger.warn("Failed to cleanup execution directory: {}", executionId, e);
        }
    }

    /**
     * Clean up old execution directories
     */
    public void cleanupOldExecutions(long maxAgeHours) {
        try {
            Path workingPath = Paths.get(workingDirectory);
            if (!Files.exists(workingPath)) {
                return;
            }

            long cutoffTime = System.currentTimeMillis() - (maxAgeHours * 60 * 60 * 1000);

            Files.list(workingPath)
                    .filter(Files::isDirectory)
                    .filter(path -> {
                        try {
                            return Files.getLastModifiedTime(path).toMillis() < cutoffTime;
                        } catch (IOException e) {
                            return false;
                        }
                    })
                    .forEach(path -> {
                        try {
                            deleteDirectory(path.toFile());
                            logger.debug("Cleaned up old execution directory: {}", path.getFileName());
                        } catch (Exception e) {
                            logger.warn("Failed to cleanup old execution directory: {}", path.getFileName(), e);
                        }
                    });

        } catch (Exception e) {
            logger.error("Failed to cleanup old execution directories", e);
        }
    }

    /**
     * Recursively delete directory
     */
    private void deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file);
                }
            }
        }
        directory.delete();
    }

    /**
     * Get artifact metadata
     */
    public ArtifactMetadata getArtifactMetadata(File artifactDir) {
        ArtifactMetadata metadata = new ArtifactMetadata();
        
        try {
            // Read tenant config
            File configFile = new File(artifactDir, "config/tenant-config.json");
            if (configFile.exists()) {
                // TODO: Parse tenant config JSON
                metadata.setHasTenantConfig(true);
            }

            // Count changelog files
            File changelogDir = new File(artifactDir, "db/changelog");
            if (changelogDir.exists()) {
                metadata.setChangelogFileCount(countSqlFiles(changelogDir));
            }

            // Check for build info
            File buildInfoFile = new File(artifactDir, "build-info.properties");
            if (buildInfoFile.exists()) {
                metadata.setHasBuildInfo(true);
            }

        } catch (Exception e) {
            logger.warn("Failed to read artifact metadata", e);
        }

        return metadata;
    }

    /**
     * Count SQL files recursively
     */
    private int countSqlFiles(File directory) {
        int count = 0;
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    count += countSqlFiles(file);
                } else if (file.getName().toLowerCase().endsWith(".sql")) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Artifact metadata holder
     */
    public static class ArtifactMetadata {
        private boolean hasTenantConfig;
        private boolean hasBuildInfo;
        private int changelogFileCount;

        // Getters and Setters
        public boolean isHasTenantConfig() { return hasTenantConfig; }
        public void setHasTenantConfig(boolean hasTenantConfig) { this.hasTenantConfig = hasTenantConfig; }

        public boolean isHasBuildInfo() { return hasBuildInfo; }
        public void setHasBuildInfo(boolean hasBuildInfo) { this.hasBuildInfo = hasBuildInfo; }

        public int getChangelogFileCount() { return changelogFileCount; }
        public void setChangelogFileCount(int changelogFileCount) { this.changelogFileCount = changelogFileCount; }

        @Override
        public String toString() {
            return "ArtifactMetadata{" +
                    "hasTenantConfig=" + hasTenantConfig +
                    ", hasBuildInfo=" + hasBuildInfo +
                    ", changelogFileCount=" + changelogFileCount +
                    '}';
        }
    }
}

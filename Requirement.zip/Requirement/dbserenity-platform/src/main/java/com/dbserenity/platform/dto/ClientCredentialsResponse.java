package com.dbserenity.platform.dto;

import com.dbserenity.platform.entity.ClientCredentials;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for client credentials response (without sensitive data)
 */
public class ClientCredentialsResponse {

    private Long id;
    private String clientId;
    private List<String> scopes;
    private Boolean isActive;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime expiresAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime lastUsedAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    // Constructors
    public ClientCredentialsResponse() {}

    public ClientCredentialsResponse(ClientCredentials credentials) {
        this.id = credentials.getId();
        this.clientId = credentials.getClientId();
        this.scopes = credentials.getScopes();
        this.isActive = credentials.getIsActive();
        this.expiresAt = credentials.getExpiresAt();
        this.lastUsedAt = credentials.getLastUsedAt();
        this.createdAt = credentials.getCreatedAt();
    }

    // Static factory method
    public static ClientCredentialsResponse from(ClientCredentials credentials) {
        return new ClientCredentialsResponse(credentials);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public List<String> getScopes() {
        return scopes;
    }

    public void setScopes(List<String> scopes) {
        this.scopes = scopes;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public LocalDateTime getLastUsedAt() {
        return lastUsedAt;
    }

    public void setLastUsedAt(LocalDateTime lastUsedAt) {
        this.lastUsedAt = lastUsedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ClientCredentialsResponse{" +
                "id=" + id +
                ", clientId='" + clientId + '\'' +
                ", scopes=" + scopes +
                ", isActive=" + isActive +
                ", expiresAt=" + expiresAt +
                ", createdAt=" + createdAt +
                '}';
    }
}

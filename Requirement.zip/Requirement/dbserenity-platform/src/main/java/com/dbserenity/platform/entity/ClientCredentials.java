package com.dbserenity.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity representing client credentials for tenant authentication
 */
@Entity
@Table(name = "client_credentials")
public class ClientCredentials {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tenant_id", nullable = false)
    @NotNull(message = "Tenant is required")
    private Tenant tenant;

    @Column(name = "client_id", nullable = false, unique = true, length = 100)
    @NotBlank(message = "Client ID is required")
    @Pattern(regexp = "^[a-z0-9-]+$", message = "Client ID must contain only lowercase letters, numbers, and hyphens")
    @Size(max = 100, message = "Client ID must not exceed 100 characters")
    private String clientId;

    @Column(name = "client_secret_hash", nullable = false)
    @NotBlank(message = "Client secret hash is required")
    private String clientSecretHash;

    @Column(name = "client_secret_salt", nullable = false, length = 100)
    @NotBlank(message = "Client secret salt is required")
    private String clientSecretSalt;

    @ElementCollection
    @CollectionTable(name = "client_credential_scopes", 
                    joinColumns = @JoinColumn(name = "client_credentials_id"))
    @Column(name = "scope")
    private List<String> scopes = new ArrayList<>();

    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @Column(name = "last_used_at")
    private LocalDateTime lastUsedAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @OneToMany(mappedBy = "clientCredentials", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ApiToken> apiTokens = new ArrayList<>();

    // Constructors
    public ClientCredentials() {
        // Initialize default scopes
        this.scopes.add("changeset:execute");
        this.scopes.add("changeset:status");
    }

    public ClientCredentials(Tenant tenant, String clientId, String clientSecretHash, String clientSecretSalt) {
        this();
        this.tenant = tenant;
        this.clientId = clientId;
        this.clientSecretHash = clientSecretHash;
        this.clientSecretSalt = clientSecretSalt;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecretHash() {
        return clientSecretHash;
    }

    public void setClientSecretHash(String clientSecretHash) {
        this.clientSecretHash = clientSecretHash;
    }

    public String getClientSecretSalt() {
        return clientSecretSalt;
    }

    public void setClientSecretSalt(String clientSecretSalt) {
        this.clientSecretSalt = clientSecretSalt;
    }

    public List<String> getScopes() {
        return scopes;
    }

    public void setScopes(List<String> scopes) {
        this.scopes = scopes;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public LocalDateTime getLastUsedAt() {
        return lastUsedAt;
    }

    public void setLastUsedAt(LocalDateTime lastUsedAt) {
        this.lastUsedAt = lastUsedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public List<ApiToken> getApiTokens() {
        return apiTokens;
    }

    public void setApiTokens(List<ApiToken> apiTokens) {
        this.apiTokens = apiTokens;
    }

    // Helper methods
    public void addScope(String scope) {
        if (!scopes.contains(scope)) {
            scopes.add(scope);
        }
    }

    public void removeScope(String scope) {
        scopes.remove(scope);
    }

    public boolean hasScope(String scope) {
        return scopes.contains(scope);
    }

    public String getScopesAsString() {
        return String.join(" ", scopes);
    }

    public boolean isExpired() {
        return expiresAt != null && LocalDateTime.now().isAfter(expiresAt);
    }

    public boolean isValid() {
        return isActive && !isExpired();
    }

    public void updateLastUsed() {
        this.lastUsedAt = LocalDateTime.now();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClientCredentials)) return false;
        ClientCredentials that = (ClientCredentials) o;
        return clientId.equals(that.clientId);
    }

    @Override
    public int hashCode() {
        return clientId.hashCode();
    }

    @Override
    public String toString() {
        return "ClientCredentials{" +
                "id=" + id +
                ", clientId='" + clientId + '\'' +
                ", scopes=" + scopes +
                ", isActive=" + isActive +
                ", expiresAt=" + expiresAt +
                ", createdAt=" + createdAt +
                '}';
    }
}

package com.dbserenity.platform.service;

import com.dbserenity.platform.dto.*;
import com.dbserenity.platform.entity.Tenant;
import com.dbserenity.platform.entity.TenantEnvironment;
import com.dbserenity.platform.exception.TenantAlreadyExistsException;
import com.dbserenity.platform.exception.TenantNotFoundException;
import com.dbserenity.platform.repository.TenantRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Service class for tenant management operations
 */
@Service
@Transactional
public class TenantService {

    private static final Logger logger = LoggerFactory.getLogger(TenantService.class);

    private final TenantRepository tenantRepository;
    private final ClientCredentialsService clientCredentialsService;
    private final GitHubService gitHubService;
    private final RepositoryTemplateService repositoryTemplateService;
    private final AuditService auditService;

    @Autowired
    public TenantService(TenantRepository tenantRepository,
                        ClientCredentialsService clientCredentialsService,
                        GitHubService gitHubService,
                        RepositoryTemplateService repositoryTemplateService,
                        AuditService auditService) {
        this.tenantRepository = tenantRepository;
        this.clientCredentialsService = clientCredentialsService;
        this.gitHubService = gitHubService;
        this.repositoryTemplateService = repositoryTemplateService;
        this.auditService = auditService;
    }

    /**
     * Create a new tenant
     */
    public TenantCreateResponse createTenant(TenantCreateRequest request, String createdBy) {
        logger.info("Creating new tenant: {}", request.getTenantId());

        // Validate tenant doesn't already exist
        if (tenantRepository.existsByTenantId(request.getTenantId())) {
            throw new TenantAlreadyExistsException("Tenant with ID '" + request.getTenantId() + "' already exists");
        }

        if (tenantRepository.existsByContactEmail(request.getContactEmail())) {
            throw new TenantAlreadyExistsException("Tenant with email '" + request.getContactEmail() + "' already exists");
        }

        // Create tenant entity
        Tenant tenant = new Tenant();
        tenant.setTenantId(request.getTenantId());
        tenant.setTenantName(request.getTenantName());
        tenant.setDescription(request.getDescription());
        tenant.setContactEmail(request.getContactEmail());
        tenant.setGithubOrg(request.getGithubOrg());
        tenant.setGithubRepo(request.getGithubRepo());
        tenant.setCreatedBy(createdBy);

        // Add environments if provided
        if (request.getEnvironments() != null && !request.getEnvironments().isEmpty()) {
            for (TenantEnvironmentRequest envRequest : request.getEnvironments()) {
                TenantEnvironment environment = new TenantEnvironment();
                environment.setEnvironmentName(envRequest.getEnvironmentName());
                environment.setJdbcUrl(envRequest.getJdbcUrl());
                environment.setUsername(envRequest.getUsername());
                environment.setSchemaName(envRequest.getSchemaName());
                environment.setContexts(envRequest.getContexts());
                environment.setLabels(envRequest.getLabels());
                tenant.addEnvironment(environment);
            }
        }

        // Save tenant
        tenant = tenantRepository.save(tenant);
        logger.info("Tenant created successfully: {}", tenant.getTenantId());

        // Create response object
        TenantCreateResponse response = new TenantCreateResponse();
        response.setTenant(TenantResponse.from(tenant));

        // Generate client credentials if requested
        if (request.getGenerateClientCredentials()) {
            try {
                ClientCredentialsCreateResponse credentialsResponse = 
                    clientCredentialsService.generateCredentials(tenant, createdBy);
                response.setClientCredentials(credentialsResponse);
                logger.info("Client credentials generated for tenant: {}", tenant.getTenantId());
            } catch (Exception e) {
                logger.error("Failed to generate client credentials for tenant: {}", tenant.getTenantId(), e);
                // Don't fail the entire operation, just log the error
            }
        }

        // Generate repository template
        try {
            RepositoryTemplateService.RepositoryGenerationResult templateResult = 
                repositoryTemplateService.generateTenantRepository(tenant, request);
            
            if (templateResult.isSuccess()) {
                logger.info("Repository template generated for tenant: {}", tenant.getTenantId());
                // Add template info to response metadata
                if (response.getTenant().getMetadata() == null) {
                    response.getTenant().setMetadata(new java.util.HashMap<>());
                }
                response.getTenant().getMetadata().put("repositoryTemplatePath", templateResult.getRepositoryPath());
            } else {
                logger.warn("Failed to generate repository template for tenant: {} - {}", 
                           tenant.getTenantId(), templateResult.getMessage());
            }
        } catch (Exception e) {
            logger.error("Failed to generate repository template for tenant: {}", tenant.getTenantId(), e);
            // Don't fail the entire operation, just log the error
        }

        // Create GitHub repository if requested
        if (request.getCreateGitHubRepo() && request.getGithubOrg() != null && request.getGithubRepo() != null) {
            try {
                GitHubRepoCreateResponse repoResponse = 
                    gitHubService.createTenantRepository(tenant, request);
                response.setGitHubRepo(repoResponse);
                logger.info("GitHub repository created for tenant: {}", tenant.getTenantId());
            } catch (Exception e) {
                logger.error("Failed to create GitHub repository for tenant: {}", tenant.getTenantId(), e);
                // Don't fail the entire operation, just log the error
            }
        }

        // Log audit event
        auditService.logTenantCreated(tenant, createdBy);

        return response;
    }

    /**
     * Get tenant by ID
     */
    @Transactional(readOnly = true)
    public TenantResponse getTenant(String tenantId) {
        logger.debug("Retrieving tenant: {}", tenantId);
        
        Tenant tenant = tenantRepository.findByTenantIdWithEnvironments(tenantId)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + tenantId));
        
        return TenantResponse.from(tenant);
    }

    /**
     * Get tenant by UUID
     */
    @Transactional(readOnly = true)
    public TenantResponse getTenantByUuid(UUID uuid) {
        logger.debug("Retrieving tenant by UUID: {}", uuid);
        
        Tenant tenant = tenantRepository.findByUuid(uuid)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + uuid));
        
        return TenantResponse.from(tenant);
    }

    /**
     * Get all tenants with pagination
     */
    @Transactional(readOnly = true)
    public Page<TenantResponse> getAllTenants(Pageable pageable) {
        logger.debug("Retrieving all tenants with pagination");
        
        return tenantRepository.findAll(pageable)
                .map(TenantResponse::fromBasic);
    }

    /**
     * Get active tenants
     */
    @Transactional(readOnly = true)
    public List<TenantResponse> getActiveTenants() {
        logger.debug("Retrieving active tenants");
        
        return tenantRepository.findByIsActiveTrue().stream()
                .map(TenantResponse::fromBasic)
                .collect(Collectors.toList());
    }

    /**
     * Search tenants
     */
    @Transactional(readOnly = true)
    public Page<TenantResponse> searchTenants(String tenantId, String tenantName, 
                                            String contactEmail, Boolean isActive, 
                                            Pageable pageable) {
        logger.debug("Searching tenants with criteria - tenantId: {}, tenantName: {}, contactEmail: {}, isActive: {}", 
                    tenantId, tenantName, contactEmail, isActive);
        
        return tenantRepository.searchTenants(tenantId, tenantName, contactEmail, isActive, pageable)
                .map(TenantResponse::fromBasic);
    }

    /**
     * Update tenant
     */
    public TenantResponse updateTenant(String tenantId, TenantUpdateRequest request, String updatedBy) {
        logger.info("Updating tenant: {}", tenantId);
        
        Tenant tenant = tenantRepository.findByTenantId(tenantId)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + tenantId));

        // Store original values for audit
        Tenant originalTenant = new Tenant();
        originalTenant.setTenantName(tenant.getTenantName());
        originalTenant.setDescription(tenant.getDescription());
        originalTenant.setContactEmail(tenant.getContactEmail());
        originalTenant.setGithubOrg(tenant.getGithubOrg());
        originalTenant.setGithubRepo(tenant.getGithubRepo());

        // Update fields
        if (request.getTenantName() != null) {
            tenant.setTenantName(request.getTenantName());
        }
        if (request.getDescription() != null) {
            tenant.setDescription(request.getDescription());
        }
        if (request.getContactEmail() != null) {
            // Check if email is already used by another tenant
            Optional<Tenant> existingTenant = tenantRepository.findByContactEmail(request.getContactEmail());
            if (existingTenant.isPresent() && !existingTenant.get().getId().equals(tenant.getId())) {
                throw new TenantAlreadyExistsException("Email already used by another tenant: " + request.getContactEmail());
            }
            tenant.setContactEmail(request.getContactEmail());
        }
        if (request.getGithubOrg() != null) {
            tenant.setGithubOrg(request.getGithubOrg());
        }
        if (request.getGithubRepo() != null) {
            tenant.setGithubRepo(request.getGithubRepo());
        }

        tenant = tenantRepository.save(tenant);
        logger.info("Tenant updated successfully: {}", tenant.getTenantId());

        // Log audit event
        auditService.logTenantUpdated(originalTenant, tenant, updatedBy);

        return TenantResponse.from(tenant);
    }

    /**
     * Activate/Deactivate tenant
     */
    public TenantResponse updateTenantStatus(String tenantId, boolean isActive, String updatedBy) {
        logger.info("Updating tenant status: {} to {}", tenantId, isActive);
        
        Tenant tenant = tenantRepository.findByTenantId(tenantId)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + tenantId));

        boolean previousStatus = tenant.getIsActive();
        tenant.setIsActive(isActive);
        tenant = tenantRepository.save(tenant);

        logger.info("Tenant status updated: {} from {} to {}", tenantId, previousStatus, isActive);

        // Log audit event
        auditService.logTenantStatusChanged(tenant, previousStatus, isActive, updatedBy);

        return TenantResponse.from(tenant);
    }

    /**
     * Delete tenant (soft delete by deactivating)
     */
    public void deleteTenant(String tenantId, String deletedBy) {
        logger.info("Deleting tenant: {}", tenantId);
        
        Tenant tenant = tenantRepository.findByTenantId(tenantId)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + tenantId));

        // Soft delete by deactivating
        tenant.setIsActive(false);
        tenantRepository.save(tenant);

        logger.info("Tenant deleted (deactivated): {}", tenantId);

        // Log audit event
        auditService.logTenantDeleted(tenant, deletedBy);
    }

    /**
     * Get tenant statistics
     */
    @Transactional(readOnly = true)
    public TenantStatsResponse getTenantStats() {
        logger.debug("Retrieving tenant statistics");
        
        long totalTenants = tenantRepository.count();
        long activeTenants = tenantRepository.countActiveTenants();
        long inactiveTenants = totalTenants - activeTenants;
        long tenantsWithGitHub = tenantRepository.findTenantsWithGitHubRepo().size();

        TenantStatsResponse stats = new TenantStatsResponse();
        stats.setTotalTenants(totalTenants);
        stats.setActiveTenants(activeTenants);
        stats.setInactiveTenants(inactiveTenants);
        stats.setTenantsWithGitHubRepo(tenantsWithGitHub);

        return stats;
    }

    /**
     * Check if tenant exists
     */
    @Transactional(readOnly = true)
    public boolean tenantExists(String tenantId) {
        return tenantRepository.existsByTenantId(tenantId);
    }

    /**
     * Validate tenant is active
     */
    @Transactional(readOnly = true)
    public void validateTenantActive(String tenantId) {
        Tenant tenant = tenantRepository.findByTenantId(tenantId)
                .orElseThrow(() -> new TenantNotFoundException("Tenant not found: " + tenantId));
        
        if (!tenant.getIsActive()) {
            throw new IllegalStateException("Tenant is not active: " + tenantId);
        }
    }
}

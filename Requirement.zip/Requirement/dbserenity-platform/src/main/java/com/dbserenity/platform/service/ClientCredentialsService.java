package com.dbserenity.platform.service;

import com.dbserenity.platform.dto.ClientCredentialsCreateResponse;
import com.dbserenity.platform.entity.ClientCredentials;
import com.dbserenity.platform.entity.Tenant;
import com.dbserenity.platform.repository.ClientCredentialsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * Service for managing client credentials
 */
@Service
@Transactional
public class ClientCredentialsService {

    private static final Logger logger = LoggerFactory.getLogger(ClientCredentialsService.class);
    private static final SecureRandom secureRandom = new SecureRandom();

    private final ClientCredentialsRepository clientCredentialsRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public ClientCredentialsService(ClientCredentialsRepository clientCredentialsRepository,
                                  PasswordEncoder passwordEncoder) {
        this.clientCredentialsRepository = clientCredentialsRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Generate client credentials for a tenant
     */
    public ClientCredentialsCreateResponse generateCredentials(Tenant tenant, String createdBy) {
        logger.info("Generating client credentials for tenant: {}", tenant.getTenantId());
        
        // Generate client ID
        String clientId = generateClientId(tenant.getTenantId());
        
        // Ensure client ID is unique
        while (clientCredentialsRepository.existsByClientId(clientId)) {
            clientId = generateClientId(tenant.getTenantId());
        }
        
        // Generate client secret and salt
        String clientSecret = generateClientSecret();
        String salt = generateSalt();
        String hashedSecret = passwordEncoder.encode(clientSecret + salt);
        
        // Create client credentials entity
        ClientCredentials credentials = new ClientCredentials();
        credentials.setTenant(tenant);
        credentials.setClientId(clientId);
        credentials.setClientSecretHash(hashedSecret);
        credentials.setClientSecretSalt(salt);
        credentials.setCreatedBy(createdBy);
        
        // Set default scopes
        credentials.setScopes(Arrays.asList("changeset:execute", "changeset:status"));
        
        // Save credentials
        credentials = clientCredentialsRepository.save(credentials);
        
        logger.info("Client credentials generated successfully for tenant: {} with client ID: {}", 
                   tenant.getTenantId(), clientId);
        
        // Create response (client secret is only returned once)
        ClientCredentialsCreateResponse response = new ClientCredentialsCreateResponse();
        response.setClientId(clientId);
        response.setClientSecret(clientSecret);
        response.setScopes(credentials.getScopes());
        response.setCreatedAt(credentials.getCreatedAt());
        
        return response;
    }

    /**
     * Generate a unique client ID
     */
    private String generateClientId(String tenantId) {
        // Format: tenant-id-random8chars
        String randomSuffix = generateRandomString(8);
        return tenantId + "-" + randomSuffix;
    }

    /**
     * Generate a secure client secret
     */
    private String generateClientSecret() {
        // Generate 32 random bytes and encode as base64
        byte[] randomBytes = new byte[32];
        secureRandom.nextBytes(randomBytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
    }

    /**
     * Generate a salt for password hashing
     */
    private String generateSalt() {
        byte[] salt = new byte[16];
        secureRandom.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Generate a random string of specified length
     */
    private String generateRandomString(int length) {
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(secureRandom.nextInt(chars.length())));
        }
        return sb.toString();
    }

    /**
     * Get client credentials for a tenant
     */
    @Transactional(readOnly = true)
    public List<ClientCredentials> getCredentialsForTenant(String tenantId) {
        return clientCredentialsRepository.findByTenantTenantId(tenantId);
    }

    /**
     * Deactivate client credentials
     */
    public void deactivateCredentials(String clientId, String deactivatedBy) {
        logger.info("Deactivating client credentials: {}", clientId);
        
        ClientCredentials credentials = clientCredentialsRepository.findByClientId(clientId)
                .orElseThrow(() -> new IllegalArgumentException("Client credentials not found: " + clientId));
        
        credentials.setIsActive(false);
        clientCredentialsRepository.save(credentials);
        
        logger.info("Client credentials deactivated: {}", clientId);
    }
}

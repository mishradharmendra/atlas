package com.dbserenity.platform.dto;

import com.dbserenity.platform.entity.TenantEnvironment;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for tenant environment response
 */
public class TenantEnvironmentResponse {

    private Long id;
    private String environmentName;
    private String jdbcUrl;
    private String username;
    private String schemaName;
    private List<String> contexts;
    private List<String> labels;
    private Boolean isActive;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime updatedAt;

    // Constructors
    public TenantEnvironmentResponse() {}

    public TenantEnvironmentResponse(TenantEnvironment environment) {
        this.id = environment.getId();
        this.environmentName = environment.getEnvironmentName();
        this.jdbcUrl = environment.getJdbcUrl();
        this.username = environment.getUsername();
        this.schemaName = environment.getSchemaName();
        this.contexts = environment.getContexts();
        this.labels = environment.getLabels();
        this.isActive = environment.getIsActive();
        this.createdAt = environment.getCreatedAt();
        this.updatedAt = environment.getUpdatedAt();
    }

    // Static factory method
    public static TenantEnvironmentResponse from(TenantEnvironment environment) {
        return new TenantEnvironmentResponse(environment);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEnvironmentName() {
        return environmentName;
    }

    public void setEnvironmentName(String environmentName) {
        this.environmentName = environmentName;
    }

    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public List<String> getContexts() {
        return contexts;
    }

    public void setContexts(List<String> contexts) {
        this.contexts = contexts;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "TenantEnvironmentResponse{" +
                "id=" + id +
                ", environmentName='" + environmentName + '\'' +
                ", jdbcUrl='" + jdbcUrl + '\'' +
                ", username='" + username + '\'' +
                ", schemaName='" + schemaName + '\'' +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}';
    }
}

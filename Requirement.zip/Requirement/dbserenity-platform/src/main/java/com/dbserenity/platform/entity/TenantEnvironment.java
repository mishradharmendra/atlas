package com.dbserenity.platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Entity representing a tenant environment configuration
 */
@Entity
@Table(name = "tenant_environments", 
       uniqueConstraints = @UniqueConstraint(columnNames = {"tenant_id", "environment_name"}))
public class TenantEnvironment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tenant_id", nullable = false)
    @NotNull(message = "Tenant is required")
    private Tenant tenant;

    @Column(name = "environment_name", nullable = false, length = 50)
    @NotBlank(message = "Environment name is required")
    @Pattern(regexp = "^(dev|staging|prod)$", message = "Environment name must be dev, staging, or prod")
    private String environmentName;

    @Column(name = "jdbc_url", nullable = false, length = 500)
    @NotBlank(message = "JDBC URL is required")
    @Size(max = 500, message = "JDBC URL must not exceed 500 characters")
    private String jdbcUrl;

    @Column(name = "username", nullable = false, length = 100)
    @NotBlank(message = "Username is required")
    @Size(max = 100, message = "Username must not exceed 100 characters")
    private String username;

    @Column(name = "schema_name", length = 100)
    @Size(max = 100, message = "Schema name must not exceed 100 characters")
    private String schemaName;

    @ElementCollection
    @CollectionTable(name = "tenant_environment_contexts", 
                    joinColumns = @JoinColumn(name = "tenant_environment_id"))
    @Column(name = "context")
    private List<String> contexts;

    @ElementCollection
    @CollectionTable(name = "tenant_environment_labels", 
                    joinColumns = @JoinColumn(name = "tenant_environment_id"))
    @Column(name = "label")
    private List<String> labels;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    // Constructors
    public TenantEnvironment() {}

    public TenantEnvironment(Tenant tenant, String environmentName, String jdbcUrl, String username) {
        this.tenant = tenant;
        this.environmentName = environmentName;
        this.jdbcUrl = jdbcUrl;
        this.username = username;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public String getEnvironmentName() {
        return environmentName;
    }

    public void setEnvironmentName(String environmentName) {
        this.environmentName = environmentName;
    }

    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public List<String> getContexts() {
        return contexts;
    }

    public void setContexts(List<String> contexts) {
        this.contexts = contexts;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Helper methods
    public String getContextsAsString() {
        return contexts != null ? String.join(",", contexts) : "";
    }

    public String getLabelsAsString() {
        return labels != null ? String.join(",", labels) : "";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TenantEnvironment)) return false;
        TenantEnvironment that = (TenantEnvironment) o;
        return tenant.equals(that.tenant) && environmentName.equals(that.environmentName);
    }

    @Override
    public int hashCode() {
        return tenant.hashCode() + environmentName.hashCode();
    }

    @Override
    public String toString() {
        return "TenantEnvironment{" +
                "id=" + id +
                ", environmentName='" + environmentName + '\'' +
                ", jdbcUrl='" + jdbcUrl + '\'' +
                ", username='" + username + '\'' +
                ", schemaName='" + schemaName + '\'' +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}';
    }
}

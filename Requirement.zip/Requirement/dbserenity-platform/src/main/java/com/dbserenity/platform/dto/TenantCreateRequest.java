package com.dbserenity.platform.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * DTO for creating a new tenant
 */
public class TenantCreateRequest {

    @NotBlank(message = "Tenant ID is required")
    @Pattern(regexp = "^[a-z0-9-]+$", message = "Tenant ID must contain only lowercase letters, numbers, and hyphens")
    @Size(min = 3, max = 100, message = "Tenant ID must be between 3 and 100 characters")
    private String tenantId;

    @NotBlank(message = "Tenant name is required")
    @Size(max = 255, message = "Tenant name must not exceed 255 characters")
    private String tenantName;

    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;

    @NotBlank(message = "Contact email is required")
    @Email(message = "Contact email must be valid")
    private String contactEmail;

    @Size(max = 100, message = "GitHub organization must not exceed 100 characters")
    private String githubOrg;

    @Size(max = 100, message = "GitHub repository must not exceed 100 characters")
    private String githubRepo;

    @Valid
    private List<TenantEnvironmentRequest> environments;

    private Boolean createGitHubRepo = false;

    private Boolean generateClientCredentials = true;

    // Constructors
    public TenantCreateRequest() {}

    public TenantCreateRequest(String tenantId, String tenantName, String contactEmail) {
        this.tenantId = tenantId;
        this.tenantName = tenantName;
        this.contactEmail = contactEmail;
    }

    // Getters and Setters
    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getGithubOrg() {
        return githubOrg;
    }

    public void setGithubOrg(String githubOrg) {
        this.githubOrg = githubOrg;
    }

    public String getGithubRepo() {
        return githubRepo;
    }

    public void setGithubRepo(String githubRepo) {
        this.githubRepo = githubRepo;
    }

    public List<TenantEnvironmentRequest> getEnvironments() {
        return environments;
    }

    public void setEnvironments(List<TenantEnvironmentRequest> environments) {
        this.environments = environments;
    }

    public Boolean getCreateGitHubRepo() {
        return createGitHubRepo;
    }

    public void setCreateGitHubRepo(Boolean createGitHubRepo) {
        this.createGitHubRepo = createGitHubRepo;
    }

    public Boolean getGenerateClientCredentials() {
        return generateClientCredentials;
    }

    public void setGenerateClientCredentials(Boolean generateClientCredentials) {
        this.generateClientCredentials = generateClientCredentials;
    }

    @Override
    public String toString() {
        return "TenantCreateRequest{" +
                "tenantId='" + tenantId + '\'' +
                ", tenantName='" + tenantName + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", githubOrg='" + githubOrg + '\'' +
                ", githubRepo='" + githubRepo + '\'' +
                ", createGitHubRepo=" + createGitHubRepo +
                ", generateClientCredentials=" + generateClientCredentials +
                '}';
    }
}

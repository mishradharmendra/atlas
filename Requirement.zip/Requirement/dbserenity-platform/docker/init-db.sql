-- Initialize DBSerenity Platform Database
-- This script runs when the PostgreSQL container starts for the first time

-- Create additional databases if needed
-- CREATE DATABASE dbserenity_test;

-- Create additional users if needed
-- CREATE USER dbserenity_admin WITH PASSWORD 'admin_pass';
-- GRANT ALL PRIVILEGES ON DATABASE dbserenity TO dbserenity_admin;

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Log initialization
SELECT 'DBSerenity Platform database initialized' as message;

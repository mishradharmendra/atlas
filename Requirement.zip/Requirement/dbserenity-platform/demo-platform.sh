#!/bin/bash

# DBSerenity Platform Demo Script
# This script demonstrates the platform functionality

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

API_BASE="http://localhost:8080/api"

echo -e "${BLUE}🚀 DBSerenity Platform Demo${NC}"
echo "============================"
echo ""

# Check if application is running
echo -e "${BLUE}Checking Platform Status...${NC}"
if curl -s -f "$API_BASE/actuator/health" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Platform is running on http://localhost:8080${NC}"
else
    echo -e "${RED}❌ Platform is not running. Please start it first:${NC}"
    echo "   cd /Users/dmish2/Requirement/dbserenity-platform"
    echo "   java -jar target/dbserenity-platform-1.0.0.jar --spring.profiles.active=dev --spring.liquibase.enabled=false"
    exit 1
fi
echo ""

# Show available endpoints
echo -e "${BLUE}📋 Available API Endpoints:${NC}"
echo "• Authentication: $API_BASE/v1/auth/token"
echo "• Tenant Management: $API_BASE/v1/tenants"
echo "• Changeset Execution: $API_BASE/v1/changesets/execute"
echo "• Repository Templates: $API_BASE/v1/repository-templates/generate"
echo "• API Documentation: $API_BASE/swagger-ui.html"
echo "• OpenAPI Spec: $API_BASE/v3/api-docs"
echo ""

# Show platform capabilities
echo -e "${BLUE}🎯 Platform Capabilities Implemented:${NC}"
echo ""
echo -e "${GREEN}✅ Core Features:${NC}"
echo "  • Multi-tenant management with secure isolation"
echo "  • JWT-based authentication (OAuth2 client credentials)"
echo "  • Liquibase changeset execution engine"
echo "  • Repository template generation system"
echo "  • Artifact management and processing"
echo "  • Email notification system"
echo "  • Comprehensive audit logging"
echo "  • Real-time execution monitoring"
echo ""

echo -e "${GREEN}✅ Database Schema:${NC}"
echo "  • Tenants and tenant environments"
echo "  • Client credentials and API tokens"
echo "  • Execution logs and metadata"
echo "  • Audit trails and system events"
echo "  • Notification templates"
echo ""

echo -e "${GREEN}✅ Security Features:${NC}"
echo "  • JWT token generation and validation"
echo "  • Scope-based authorization"
echo "  • Secure credential management"
echo "  • Request authentication and authorization"
echo "  • Comprehensive error handling"
echo ""

echo -e "${GREEN}✅ Repository Template System:${NC}"
echo "  • Automated tenant repository generation"
echo "  • Maven project structure with Liquibase"
echo "  • SQL-based changesets (no XML)"
echo "  • GitHub Actions CI/CD workflows"
echo "  • Tenant-specific configuration files"
echo ""

# Show sample tenant repository
echo -e "${BLUE}📁 Sample Tenant Repository Generated:${NC}"
echo "Located at: /Users/dmish2/Requirement/sample-tenant-repository/"
echo ""
echo "Repository Structure:"
echo "├── pom.xml                    # Maven configuration"
echo "├── config/"
echo "│   └── tenant-config.json    # Tenant configuration"
echo "├── src/main/resources/"
echo "│   ├── liquibase.properties  # Liquibase config"
echo "│   └── db/changelog/"
echo "│       ├── db.changelog-master.sql"
echo "│       └── changesets/"
echo "│           ├── v1.0/         # Initial schema"
echo "│           ├── v1.1/         # Enhanced features"
echo "│           ├── v1.2/         # Audit & compliance"
echo "│           └── dev/          # Dev test data"
echo "└── .github/workflows/        # CI/CD pipelines"
echo ""

# Show usage examples
echo -e "${BLUE}💡 Usage Examples:${NC}"
echo ""
echo -e "${YELLOW}1. Create a Tenant:${NC}"
echo 'curl -X POST $API_BASE/v1/tenants \'
echo '  -H "Content-Type: application/json" \'
echo '  -H "Authorization: Bearer <token>" \'
echo '  -d '"'"'{'
echo '    "tenantId": "acme-corp",'
echo '    "tenantName": "ACME Corporation",'
echo '    "contactEmail": "admin@acme.com",'
echo '    "generateClientCredentials": true'
echo '  }'"'"
echo ""

echo -e "${YELLOW}2. Get Access Token:${NC}"
echo 'curl -X POST $API_BASE/v1/auth/token \'
echo '  -H "Content-Type: application/json" \'
echo '  -d '"'"'{'
echo '    "grant_type": "client_credentials",'
echo '    "client_id": "your-client-id",'
echo '    "client_secret": "your-client-secret"'
echo '  }'"'"
echo ""

echo -e "${YELLOW}3. Execute Changesets:${NC}"
echo 'curl -X POST $API_BASE/v1/changesets/execute \'
echo '  -H "Content-Type: application/json" \'
echo '  -H "Authorization: Bearer <token>" \'
echo '  -d '"'"'{'
echo '    "clientId": "your-client-id",'
echo '    "clientSecret": "your-client-secret",'
echo '    "artifactUrl": "https://artifacts.com/tenant/changesets.zip",'
echo '    "environment": "dev",'
echo '    "mode": "execute",'
echo '    "databasePassword": "db-password"'
echo '  }'"'"
echo ""

echo -e "${YELLOW}4. Generate Repository Template:${NC}"
echo 'curl -X POST $API_BASE/v1/repository-templates/generate \'
echo '  -H "Content-Type: application/json" \'
echo '  -H "Authorization: Bearer <token>" \'
echo '  -d '"'"'{"tenantId": "acme-corp"}'"'"
echo ""

# Show next steps
echo -e "${BLUE}🔄 Next Steps:${NC}"
echo "1. Access Swagger UI for interactive API testing:"
echo "   → http://localhost:8080/api/swagger-ui.html"
echo ""
echo "2. Set up PostgreSQL for production:"
echo "   → Update application.yml with PostgreSQL settings"
echo "   → Enable Liquibase for proper schema management"
echo ""
echo "3. Configure GitHub integration:"
echo "   → Set GitHub token and organization in configuration"
echo "   → Enable automated repository creation"
echo ""
echo "4. Set up email notifications:"
echo "   → Configure SMTP settings in application.yml"
echo "   → Test notification delivery"
echo ""

echo -e "${GREEN}🎉 DBSerenity Platform is ready for use!${NC}"
echo ""
echo -e "${BLUE}Platform Features Summary:${NC}"
echo "• ✅ Multi-tenant architecture with secure isolation"
echo "• ✅ JWT authentication with client credentials flow"
echo "• ✅ Liquibase integration for SQL-based changesets"
echo "• ✅ Repository template generation system"
echo "• ✅ Comprehensive REST API with OpenAPI documentation"
echo "• ✅ Real-time execution monitoring and status tracking"
echo "• ✅ Email notification system for execution results"
echo "• ✅ Comprehensive audit logging for compliance"
echo "• ✅ GitHub Actions integration for CI/CD"
echo "• ✅ Artifact management and secure processing"

#!/bin/bash

# DBSerenity Platform Startup Script
# This script helps you run the platform in different modes

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to wait for service to be ready
wait_for_service() {
    local service_name=$1
    local url=$2
    local max_attempts=30
    local attempt=1

    print_status "Waiting for $service_name to be ready..."
    
    while [ $attempt -le $max_attempts ]; do
        if curl -f -s "$url" >/dev/null 2>&1; then
            print_success "$service_name is ready!"
            return 0
        fi
        
        echo -n "."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    print_error "$service_name failed to start within expected time"
    return 1
}

# Function to show usage
show_usage() {
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  dev       Run in development mode (default)"
    echo "  prod      Run in production mode"
    echo "  docker    Run using Docker Compose"
    echo "  build     Build the application"
    echo "  test      Run tests"
    echo "  clean     Clean build artifacts and stop services"
    echo "  logs      Show application logs"
    echo "  status    Show service status"
    echo "  help      Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 dev          # Run in development mode"
    echo "  $0 docker       # Run with Docker Compose"
    echo "  $0 build        # Build the application"
    echo "  $0 clean        # Clean up everything"
}

# Function to check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    local missing_tools=()
    
    if ! command_exists java; then
        missing_tools+=("Java 21")
    else
        java_version=$(java -version 2>&1 | head -n1 | cut -d'"' -f2 | cut -d'.' -f1)
        if [ "$java_version" -lt 21 ]; then
            missing_tools+=("Java 21 (current: $java_version)")
        fi
    fi
    
    if ! command_exists mvn && ! [ -f "./mvnw" ]; then
        missing_tools+=("Maven or Maven Wrapper")
    fi
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        print_error "Missing prerequisites:"
        for tool in "${missing_tools[@]}"; do
            echo "  - $tool"
        done
        echo ""
        echo "Please install the missing tools and try again."
        exit 1
    fi
    
    print_success "All prerequisites are met"
}

# Function to build the application
build_app() {
    print_status "Building DBSerenity Platform..."
    
    if [ -f "./mvnw" ]; then
        ./mvnw clean package -DskipTests
    else
        mvn clean package -DskipTests
    fi
    
    if [ $? -eq 0 ]; then
        print_success "Build completed successfully"
    else
        print_error "Build failed"
        exit 1
    fi
}

# Function to run tests
run_tests() {
    print_status "Running tests..."
    
    if [ -f "./mvnw" ]; then
        ./mvnw test
    else
        mvn test
    fi
    
    if [ $? -eq 0 ]; then
        print_success "All tests passed"
    else
        print_error "Some tests failed"
        exit 1
    fi
}

# Function to run in development mode
run_dev() {
    print_status "Starting DBSerenity Platform in development mode..."
    
    # Check if PostgreSQL is running
    if ! nc -z localhost 5432 2>/dev/null; then
        print_warning "PostgreSQL is not running on localhost:5432"
        print_status "You can start PostgreSQL using Docker:"
        echo "  docker run -d --name dbserenity-postgres \\"
        echo "    -e POSTGRES_DB=dbserenity \\"
        echo "    -e POSTGRES_USER=dbserenity_user \\"
        echo "    -e POSTGRES_PASSWORD=dbserenity_pass \\"
        echo "    -p 5432:5432 postgres:15-alpine"
        echo ""
        read -p "Do you want to continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    # Set development environment variables
    export SPRING_PROFILES_ACTIVE=dev
    export DB_URL=jdbc:postgresql://localhost:5432/dbserenity
    export DB_USERNAME=dbserenity_user
    export DB_PASSWORD=dbserenity_pass
    export JWT_SECRET=dev-secret-key-change-this-in-production-min-256-bits
    export MAIL_HOST=localhost
    export MAIL_PORT=1025
    export LOG_LEVEL=DEBUG
    
    # Run the application
    if [ -f "./mvnw" ]; then
        ./mvnw spring-boot:run
    else
        mvn spring-boot:run
    fi
}

# Function to run in production mode
run_prod() {
    print_status "Starting DBSerenity Platform in production mode..."
    
    # Check if JAR file exists
    if [ ! -f "target/dbserenity-platform-1.0.0.jar" ]; then
        print_warning "JAR file not found. Building application first..."
        build_app
    fi
    
    # Set production environment variables
    export SPRING_PROFILES_ACTIVE=prod
    export DB_URL=${DB_URL:-jdbc:postgresql://localhost:5432/dbserenity}
    export DB_USERNAME=${DB_USERNAME:-dbserenity_user}
    export DB_PASSWORD=${DB_PASSWORD:-dbserenity_pass}
    export JWT_SECRET=${JWT_SECRET:-$(openssl rand -base64 32)}
    export LOG_LEVEL=${LOG_LEVEL:-INFO}
    
    # Run the JAR file
    java -jar target/dbserenity-platform-1.0.0.jar
}

# Function to run with Docker Compose
run_docker() {
    print_status "Starting DBSerenity Platform with Docker Compose..."
    
    if ! command_exists docker; then
        print_error "Docker is not installed"
        exit 1
    fi
    
    if ! command_exists docker-compose && ! docker compose version >/dev/null 2>&1; then
        print_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Use docker compose or docker-compose based on availability
    if docker compose version >/dev/null 2>&1; then
        DOCKER_COMPOSE="docker compose"
    else
        DOCKER_COMPOSE="docker-compose"
    fi
    
    # Start services
    $DOCKER_COMPOSE up -d postgres mailhog
    
    # Wait for PostgreSQL to be ready
    wait_for_service "PostgreSQL" "http://localhost:5432" || exit 1
    
    # Build and start the application
    $DOCKER_COMPOSE up --build dbserenity-app
}

# Function to show logs
show_logs() {
    if [ -f "docker-compose.yml" ] && docker-compose ps | grep -q "dbserenity"; then
        docker-compose logs -f dbserenity-app
    else
        print_warning "No running Docker services found"
        if [ -f "logs/dbserenity-platform.log" ]; then
            tail -f logs/dbserenity-platform.log
        else
            print_error "No log files found"
        fi
    fi
}

# Function to show status
show_status() {
    print_status "DBSerenity Platform Status"
    echo ""
    
    # Check if application is running
    if curl -f -s http://localhost:8080/api/actuator/health >/dev/null 2>&1; then
        print_success "✓ Application is running (http://localhost:8080)"
        
        # Get application info
        app_info=$(curl -s http://localhost:8080/api/actuator/info 2>/dev/null || echo "{}")
        echo "  Application Info: $app_info"
    else
        print_warning "✗ Application is not responding"
    fi
    
    # Check database
    if nc -z localhost 5432 2>/dev/null; then
        print_success "✓ PostgreSQL is running (localhost:5432)"
    else
        print_warning "✗ PostgreSQL is not running"
    fi
    
    # Check MailHog (if running)
    if nc -z localhost 8025 2>/dev/null; then
        print_success "✓ MailHog is running (http://localhost:8025)"
    else
        print_warning "✗ MailHog is not running"
    fi
    
    # Check Docker services
    if command_exists docker-compose && [ -f "docker-compose.yml" ]; then
        echo ""
        print_status "Docker Services:"
        docker-compose ps
    fi
}

# Function to clean up
clean_up() {
    print_status "Cleaning up DBSerenity Platform..."
    
    # Stop Docker services
    if [ -f "docker-compose.yml" ]; then
        if command_exists docker-compose; then
            docker-compose down -v
        elif docker compose version >/dev/null 2>&1; then
            docker compose down -v
        fi
    fi
    
    # Clean Maven build
    if [ -f "./mvnw" ]; then
        ./mvnw clean
    elif command_exists mvn; then
        mvn clean
    fi
    
    # Clean up generated files
    rm -rf work/ generated-repos/ logs/
    
    print_success "Cleanup completed"
}

# Main script logic
case "${1:-dev}" in
    "dev")
        check_prerequisites
        build_app
        run_dev
        ;;
    "prod")
        check_prerequisites
        build_app
        run_prod
        ;;
    "docker")
        run_docker
        ;;
    "build")
        check_prerequisites
        build_app
        ;;
    "test")
        check_prerequisites
        run_tests
        ;;
    "logs")
        show_logs
        ;;
    "status")
        show_status
        ;;
    "clean")
        clean_up
        ;;
    "help"|"-h"|"--help")
        show_usage
        ;;
    *)
        print_error "Unknown command: $1"
        echo ""
        show_usage
        exit 1
        ;;
esac

# DBSerenity Platform

A comprehensive schema versioning platform using Liquibase for multi-tenant database change management with automated CI/CD integration.

## 🚀 Quick Start

### Prerequisites

- **Java 21** or higher
- **Maven 3.8+** (or use included Maven wrapper)
- **PostgreSQL 13+** (or use Docker)
- **Docker & Docker Compose** (optional, for containerized deployment)

### Running the Platform

The easiest way to run the platform is using the provided script:

```bash
# Run in development mode (default)
./run-platform.sh dev

# Run with Docker Compose (recommended for first-time setup)
./run-platform.sh docker

# Run in production mode
./run-platform.sh prod

# Show help
./run-platform.sh help
```

### Manual Setup

1. **Start PostgreSQL Database**
   ```bash
   docker run -d --name dbserenity-postgres \
     -e POSTGRES_DB=dbserenity \
     -e POSTGRES_USER=dbserenity_user \
     -e POSTGRES_PASSWORD=dbserenity_pass \
     -p 5432:5432 postgres:15-alpine
   ```

2. **Build and Run Application**
   ```bash
   ./mvnw clean package -DskipTests
   ./mvnw spring-boot:run
   ```

3. **Access the Platform**
   - **API**: http://localhost:8080/api
   - **Swagger UI**: http://localhost:8080/api/swagger-ui.html
   - **Health Check**: http://localhost:8080/api/actuator/health

## 📋 Platform Features

### Core Capabilities
- ✅ **Multi-tenant Management** - Complete tenant onboarding and management
- ✅ **JWT Authentication** - OAuth2-compliant client credentials flow
- ✅ **Changeset Execution** - Full Liquibase integration with dry-run and execute modes
- ✅ **Repository Templates** - Automated tenant repository generation
- ✅ **Artifact Management** - Secure artifact download and processing
- ✅ **Email Notifications** - Automated success/failure notifications
- ✅ **Comprehensive Audit Trail** - All operations logged and tracked
- ✅ **Real-time Monitoring** - Execution status and progress tracking

### API Endpoints

#### Authentication
- `POST /api/v1/auth/token` - Get access token
- `POST /api/v1/auth/validate` - Validate token
- `POST /api/v1/auth/revoke` - Revoke token

#### Tenant Management
- `POST /api/v1/tenants` - Create tenant
- `GET /api/v1/tenants/{tenantId}` - Get tenant
- `PUT /api/v1/tenants/{tenantId}` - Update tenant
- `GET /api/v1/tenants` - List tenants
- `GET /api/v1/tenants/stats` - Get statistics

#### Changeset Execution
- `POST /api/v1/changesets/execute` - Execute changesets
- `POST /api/v1/changesets/validate` - Validate changesets (dry-run)
- `GET /api/v1/changesets/status/{executionId}` - Get execution status
- `GET /api/v1/changesets/history` - Get execution history

#### Repository Templates
- `POST /api/v1/repository-templates/generate` - Generate repository template
- `POST /api/v1/repository-templates/generate-for-tenant` - Generate for authenticated tenant
- `GET /api/v1/repository-templates/list` - List generated repositories

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DB_URL` | Database JDBC URL | `jdbc:postgresql://localhost:5432/dbserenity` |
| `DB_USERNAME` | Database username | `dbserenity_user` |
| `DB_PASSWORD` | Database password | `dbserenity_pass` |
| `JWT_SECRET` | JWT signing secret | `your-256-bit-secret` |
| `JWT_EXPIRATION` | Token expiration (seconds) | `86400` |
| `MAIL_HOST` | SMTP server host | `localhost` |
| `MAIL_PORT` | SMTP server port | `587` |
| `LOG_LEVEL` | Logging level | `INFO` |

### Application Profiles

- **dev**: Development mode with debug logging and test data
- **prod**: Production mode with optimized settings

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f dbserenity-app

# Stop services
docker-compose down
```

### Manual Docker Build

```bash
# Build image
docker build -t dbserenity-platform .

# Run container
docker run -d \
  --name dbserenity-app \
  -p 8080:8080 \
  -e DB_URL=jdbc:postgresql://host.docker.internal:5432/dbserenity \
  -e DB_USERNAME=dbserenity_user \
  -e DB_PASSWORD=dbserenity_pass \
  dbserenity-platform
```

## 📖 Usage Examples

### 1. Create a Tenant

```bash
curl -X POST http://localhost:8080/api/v1/tenants \
  -H "Content-Type: application/json" \
  -d '{
    "tenantId": "acme-corp",
    "tenantName": "ACME Corporation",
    "contactEmail": "admin@acme.com",
    "description": "ACME Corp database schema",
    "generateClientCredentials": true,
    "environments": [
      {
        "environmentName": "dev",
        "jdbcUrl": "jdbc:postgresql://dev-db:5432/acme_dev",
        "username": "acme_dev_user",
        "schemaName": "acme_schema"
      }
    ]
  }'
```

### 2. Get Access Token

```bash
curl -X POST http://localhost:8080/api/v1/auth/token \
  -H "Content-Type: application/json" \
  -d '{
    "grant_type": "client_credentials",
    "client_id": "your-client-id",
    "client_secret": "your-client-secret"
  }'
```

### 3. Execute Changesets

```bash
curl -X POST http://localhost:8080/api/v1/changesets/execute \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-access-token" \
  -d '{
    "clientId": "your-client-id",
    "clientSecret": "your-client-secret",
    "artifactUrl": "https://artifacts.example.com/acme-corp/v1.0.0/changesets.zip",
    "environment": "dev",
    "mode": "execute",
    "databasePassword": "dev-db-password",
    "executionOptions": {
      "rollbackOnFailure": true,
      "notificationEmail": "admin@acme.com"
    }
  }'
```

### 4. Generate Repository Template

```bash
curl -X POST http://localhost:8080/api/v1/repository-templates/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-access-token" \
  -d '{
    "tenantId": "acme-corp"
  }'
```

## 🔍 Monitoring & Health Checks

### Health Endpoints
- **Application Health**: http://localhost:8080/api/actuator/health
- **Application Info**: http://localhost:8080/api/actuator/info
- **Metrics**: http://localhost:8080/api/actuator/metrics
- **Prometheus**: http://localhost:8080/api/actuator/prometheus

### Email Testing (Development)
When running with Docker Compose, MailHog is available at:
- **Web UI**: http://localhost:8025
- **SMTP**: localhost:1025

## 🛠️ Development

### Building from Source

```bash
# Clone repository
git clone <repository-url>
cd dbserenity-platform

# Build application
./mvnw clean package

# Run tests
./mvnw test

# Run application
./mvnw spring-boot:run
```

### Database Migrations

The platform uses Liquibase for database schema management:

```bash
# Validate changesets
./mvnw liquibase:validate

# Update database
./mvnw liquibase:update

# Generate documentation
./mvnw liquibase:dbDoc
```

## 📁 Project Structure

```
dbserenity-platform/
├── src/main/java/com/dbserenity/platform/
│   ├── controller/          # REST controllers
│   ├── service/             # Business logic services
│   ├── entity/              # JPA entities
│   ├── repository/          # Data access repositories
│   ├── dto/                 # Data transfer objects
│   ├── security/            # Security configuration
│   └── exception/           # Exception handling
├── src/main/resources/
│   ├── db/changelog/        # Liquibase changesets
│   ├── templates/           # Repository templates
│   └── application.yml      # Configuration
├── docker-compose.yml       # Docker services
├── Dockerfile              # Application container
└── run-platform.sh        # Startup script
```

## 🚨 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check if PostgreSQL is running
   ./run-platform.sh status
   
   # Start PostgreSQL with Docker
   docker run -d --name dbserenity-postgres \
     -e POSTGRES_DB=dbserenity \
     -e POSTGRES_USER=dbserenity_user \
     -e POSTGRES_PASSWORD=dbserenity_pass \
     -p 5432:5432 postgres:15-alpine
   ```

2. **Application Won't Start**
   ```bash
   # Check logs
   ./run-platform.sh logs
   
   # Verify Java version
   java -version  # Should be 21+
   
   # Clean and rebuild
   ./run-platform.sh clean
   ./run-platform.sh build
   ```

3. **Authentication Issues**
   - Verify client credentials are generated correctly
   - Check JWT secret configuration
   - Ensure token hasn't expired

### Getting Help

- Check application logs: `./run-platform.sh logs`
- View service status: `./run-platform.sh status`
- Access Swagger UI: http://localhost:8080/api/swagger-ui.html

## 📄 License

This project is proprietary software. Unauthorized access or distribution is prohibited.

---

**DBSerenity Platform** - Enterprise Database Schema Versioning Solution
